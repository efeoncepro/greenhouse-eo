# High Frequency — release package

This folder contains nine release-ready JPEG assets: three messages across three formats.

| Folder | Use | Dimensions |
|---|---|---:|
| `4x5/` | Meta/LinkedIn feed creative | 1080×1350 |
| `9x16/` | Meta Stories/Reels creative | 1080×1920 |
| `3x1/` | Wide display/campaign banner | 1800×600 |

`asset-matrix.csv` contains filenames, dimensions, exact copy and alt text. All deliverables are sRGB JPEGs under 5 MB. The 9:16 composition protects the top 12% and bottom 20% interface zones.

These assets are **creative-ready**, not media-activated. Audience, objective, landing page, UTM convention, trafficking, conversion event, budget, legal approval and experiment cells must be completed before launch.

