repo: efeoncepro/greenhouse-eo
branch: main
path: docs/ui (task specs) · src/lib/artifact-composer/catalogs/deck-axis/assets/clients (logos)

## Last sync

date: 2026-08-28T00:56:00Z

### Updated in this project

- Logos de clientes (Berel, Aguas Andinas, ANAM) importados a `assets/clients/` para la franja de confianza de la landing.
- Logo de SKY importado desde `efeoncepro/sky-efeonce` (`public/assets/sky-logo.png`).
- Landing TASK-1598 construida sobre los contratos de wireframe, flow y motion entregados en chat.

## Screen map

| Pantalla | Archivos de origen |
|---|---|
| Landing Influencer Marketing.dc.html — franja de confianza | greenhouse-eo: src/lib/artifact-composer/catalogs/deck-axis/assets/clients/{berel,aguas-andinas}.svg · docs/commercial/trainings/anam-hubspot-2026-08-12/assets/anam-logo.svg · sky-efeonce: public/assets/sky-logo.png |
| Landing Influencer Marketing.dc.html — estructura y copy | TASK-1598 wireframe/flow/motion (uploads/) |
