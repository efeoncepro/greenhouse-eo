# AXIS — Efeonce / Greenhouse Design System

AXIS is the multi-brand design system behind **Efeonce** and its flagship platform **Greenhouse**. This project is an agent-ready recreation of that system: brand assets, color/type/spacing foundations, reusable UI primitives, and a high-fidelity recreation of the Greenhouse portal — so design agents can produce on-brand interfaces, decks, and mockups.

> **Default accent is Core Blue.** Greenhouse is built on bright neutral surfaces, deep structural blues, and **one strong accent at a time**. Blue is the product's energy; green, amber and crimson are controlled signals — never a rainbow palette.

---

## Brand architecture

Three coexisting brands — choose by context, they are **not** interchangeable:

| Brand | What it is | Where it appears |
|---|---|---|
| **Efeonce** | Umbrella / institutional brand (navy `#004070` wordmark + rocket mark) | PDFs, receipts, payroll, contracts, transactional emails, anything institutional/external |
| **Greenhouse** | The platform / app (green `#6EC207` + navy "Greenhouse" wordmark, leaf-G isotype) | Everything in-app: navigation, dashboards, product surfaces, portal mockups |
| **AXIS** | The design system itself (tokens, palette, components) | **Only** design-system surfaces — token docs, theme previews. Never product UI. |

Slogan: **"Empower your Growth"** — a brand-zone element (header/masthead), never the legal footer. Canonical color is grey `#848484` (= `--text-disabled`).

### The product — Greenhouse Portal

A multi-tenant enterprise portal built on **Vuexy + Next.js 16 + MUI 7**, in **Spanish (LatAm / Chile)**. It exposes executive read, operational context, and access governance over real sources of truth (BigQuery + PostgreSQL). Active surfaces: client **dashboard, proyectos, sprints**; internal **people, HR payroll, finance** (clients, income, expenses, suppliers, reconciliation); **agency** spaces & capacity; **admin** tenants/users/roles. It is operational and confident — executive enough for finance and payroll, fast enough for dense internal workflows; never an untouched admin template.

---

## Sources

This system was reconstructed from materials the user provided. You may not have access, but they are recorded here so you can go deeper if you do:

- **GitHub — `efeoncepro/greenhouse-eo`** (private) · https://github.com/efeoncepro/greenhouse-eo
  - `DESIGN.md` — the agent-facing design contract (color/type/spacing/elevation/motion tokens, component rules). **The source of truth for this rebuild.**
  - `UX_WRITING_RESEARCH.md` — exhaustive UX-writing & data-storytelling playbook (Spanish/LatAm B2B SaaS).
  - `README.md` — product surfaces, routes, stack, data model.
  - Related repos worth exploring: `efeoncepro/voice.md` (brand voice spec format), `efeoncepro/efeonce-public-site-runtime` (public site).
- **Upstream design SoT (Figma, read-only):** "Design System | Vuexy → AXIS", fileKey `yyMksCoijfMaIoYplXKZaR`, Theme Color node `11205:5341`. When AXIS Figma and the contract disagree, **AXIS is the north.**
- **Uploaded brand assets:** Efeonce + Greenhouse logos, isotypes, favicons (now color-corrected and living in `assets/logos/`).

> Explore the `greenhouse-eo` repo further to build higher-fidelity Greenhouse designs — `DESIGN.md` and the `docs/ui/*` catalog go deeper than this rebuild.

---

## Content fundamentals

How Greenhouse writes. Voice is **helpful, clear, professional, warm — never condescending, verbose, stiff, or cutesy.** (Full playbook: `greenhouse-eo/UX_WRITING_RESEARCH.md`.)

- **Language:** Spanish, **Latin-American neutral**, addressing the user as **tú** (informal, consistent everywhere — never *usted*, never *vosotros*). Anglicisms that are established in tech are fine ("dashboard", "email", "app", "sprint"); Spain-only vocab is not ("ordenador", "vale", "mola").
- **Casing:** **sentence case everywhere** — titles, headings, labels, buttons, menu items. Capitalize only the first word + proper nouns.
- **Numbers:** numerals always ("3 proyectos", not "tres"). Amounts, IDs and KPIs use **Geist tabular numerals**, never monospace.
- **Buttons = verb + object:** "Crear espacio", "Guardar cambios", "Exportar CSV". Destructive actions name the target: "Eliminar proyecto", not "Eliminar". Cancel is always "Cancelar".
- **Domain vocabulary:** use the product's own words — **Espacios** (not "clientes/cuentas"), **Pulse** (agency dashboard), **Capacidad** (not "asignación de recursos").
- **Errors:** `[qué pasó] + [por qué] + [cómo resolverlo]`, constructive not blaming. "No pudimos guardar tus cambios. Verifica tu conexión e intenta de nuevo." — never raw codes, never "Error 500".
- **Empty states teach:** heading (what belongs here) + body (why it matters) + a primary CTA. "Aún no tienes espacios / Los espacios organizan proyectos por cliente y rastrean sus KPIs. / Crear tu primer espacio".
- **Data needs context — never a naked number.** Always answer "¿vs. qué? ¿vs. cuándo?": "$ 84.2M (+12% vs. mes anterior)", "72% de meta del 85%".
- **No emoji** in product UI. Inclusive, gender-neutral Spanish ("el equipo", "personas", "responsable" — avoid "-e"/"@" endings).
- **Tone matches stakes:** matter-of-fact for routine, calm + reassuring for errors, lightly encouraging for first-use empty states. Reserve celebration for genuine milestones.

---

## Visual foundations

- **Color.** Bright neutral canvas (`--neutral #F8F7FA` body, `--surface #FFFFFF` cards), deep structural blues, **one accent at a time**. `--primary` Core Blue `#0375DB` is the single most-important-action color. `--secondary` is AXIS green `#4B8405` (crisp, AA — the bright lime `#6EC207` is **tint/accent only**, never white text on it). Feedback (`success/warning/error/info`) is **semantic only**, and defaults to a **tonal** treatment (soft surface + AA ink) — a saturated solid reads "admin template 2016". Dark mode uses dedicated dark surfaces (`#25293C` bg / `#2F3349` paper), never ad-hoc inversion. Chart series use a separate "deep-bright" categorical ramp so a series is never mistaken for a status.
- **Type.** Exactly **two families**: **Poppins** for controlled display moments only (`headline-*`, `page-title`, `surface-hero-title`) and **Geist** for everything else (body, tables, forms, chips, buttons, IDs, KPIs). Weight roles: 400 body · 600 labels/titles/buttons · 700 strong · 800 display/KPI (500 is loaded but unused). Sizes are `rem` (scale with user preference, WCAG 1.4.4). Never introduce a third family or monospace.
- **Spacing & layout.** 4px base step; rhythm of `4 · 8 · 16 · 24 · 32 · 40`. `24px` is the default card padding, `16px` the standard inner step, `8px` the compact gap. Predictable spacing and strong rhythm over visual tricks; dense surfaces (payroll, finance tables) still breathe.
- **Radius.** Moderate and systematic: `md 6px` default (cards, fields, chips), `lg 8px` for floating/high-emphasis (docks, dialogs), `xl 10px` larger panels, `full 9999px` pills only. Precise and modern, never playful.
- **Elevation.** Restrained and **semantic** — roles, not numbers. The recipe is two soft shadow layers + a 1px hairline; no role exceeds `0 8px 24px rgba(0,0,0,.1)`. `none` (flat/outlined — the default for operational cards & tables) · `raised` (hover/selection) · `floating` (popovers, menus) · `overlay` · `modal`. The **border** carries separation under forced-colors; the shadow is the enhancement. Don't add shadow just to look "designed".
- **Cards.** White surface, `1px var(--border-subtle)` hairline, `6px` radius, `24px` padding, **flat by default**. Optional header (section-title + subtitle) with a top-right action slot.
- **Borders.** `1px var(--border-subtle) #DBDBDB` hairlines for cards, dividers, inputs. Focus ring is a 2–3px Core-Blue glow (`rgba(3,117,219,.14)`), kept in `px` so it doesn't scale with font.
- **Motion.** Fixed duration scale (ms): `instant 75 · short 150 · standard 200 · medium 300 · long 400 · extended 600`. Default easing is **emphasized** `cubic-bezier(0.2,0,0,1)`; exits use accelerate. **Never** `ease-in-out` as a default. Compositor-only props (transform/opacity); `prefers-reduced-motion` always respected. No infinite decorative loops.
- **Imagery.** Proprietary 3D character illustrations (hoodie-blue, expressive — `greenhouse-404`, `greenhouse-401`, etc.) for empty/error states; treat as owned brand assets, not stock. Otherwise the product leans on data, type hierarchy and spacing rather than decorative photography or gradients.
- **Backgrounds.** Flat bright neutral. The only sanctioned "moment" backgrounds are the navy brand panel (login) with a subtle green radial glow. No busy textures, no purple gradients.

---

## Iconography

- **System: Tabler Icons** — used everywhere in the product ("Tabler en todo"). This rebuild loads the Tabler **webfont** from CDN: `https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.24.0/dist/tabler-icons.min.css`, used via `<i class="ti ti-<name>">`. Every component that takes an icon expects a Tabler class string (e.g. `"ti ti-plus"`, `"ti ti-dots-vertical"`).
- **Stroke style:** Tabler's default 2px outline. Don't mix in filled icon sets or a second icon family.
- **Brand isotypes** (Notion, Teams, future HubSpot/Slack) for integration surfaces also come from Tabler's brand glyphs (`ti ti-brand-notion`, `ti ti-brand-teams`) — never hand-transcribed SVG paths.
- **No emoji, no Unicode glyphs** as icons in product UI.
- **Logos** live in `assets/logos/` (see below). The leaf-**G** isotype / `arrow-greenhouse` is the app mark for tight spaces; the full lockup is for headers.
- ⚠️ The uploaded logo SVGs shipped with **undefined `cls-*` classes and empty `<defs>`** (no fills). They have been color-corrected here (green `#6EC207` + navy `#004070`). If the brand team has canonical single-file SVGs, swap them in.

---

## What's in this folder (index)

| Path | What |
|---|---|
| `styles.css` | **Global entry point** — link this one file. Only `@import`s. |
| `tokens/colors.css` | Brand, primary, secondary, semantic (solid + tonal), neutrals, dark, chart + semaphore tokens. |
| `tokens/typography.css` | Families, weight roles, full display + text + numeric scale, helper classes. |
| `tokens/spacing.css` | Spacing, radius, elevation roles, borders, motion durations + easing. |
| `tokens/fonts.css` | Poppins + Geist (Google Fonts). |
| `guidelines/foundations/*.html` | 18 specimen cards (Colors, Type, Spacing, Brand) — the Design System tab. |
| `components/` | 8 reusable primitives (below). Each: `.jsx` + `.d.ts` + `.prompt.md` + a `@dsCard` showcase. |
| `ui_kits/greenhouse/` | High-fidelity Greenhouse portal recreation — login → dashboard → finance. |
| `templates/greenhouse-dashboard/` | Starting-point template (`.dc.html`) — a branded Greenhouse dashboard page consuming projects can copy. |
| `assets/logos/` | Color-corrected Efeonce + Greenhouse logos, isotypes, favicons. |
| `SKILL.md` | Agent-Skill manifest for downloading into Claude Code. |

### Components (`window.AXISEfeonceGreenhouseDesignSystem_9781a6`)

| Component | Group | Use |
|---|---|---|
| `Button` | buttons | Canonical action — primary/secondary/tonal/outlined/ghost/danger; sentence case. |
| `IconButton` | buttons | Square icon-only control for toolbars/rows. |
| `Input` | forms | Quiet text field; label above, helper below, format-only placeholder. |
| `Select` | forms | Native dropdown matched to Input. |
| `StatusChip` | data | Semantic metadata chip — tonal/solid/outlined, with dot or icon. |
| `KpiCard` | data | Executive metric with mandatory signed trend + comparison. |
| `Card` | surfaces | Baseline operational surface; flat + hairline, optional header/action. |
| `Alert` | feedback | Tonal page/section banner — info/success/warning/error. |

### UI kit — Greenhouse Portal

`ui_kits/greenhouse/` recreates the real portal as an interactive click-through: **Login** (credentials + Microsoft/Google SSO) → **Dashboard** (KPI strip, cashflow chart, open-risks, projects table) → **Finanzas** (summary stats, tabs, income ledger). Built by composing the AXIS primitives above; light Vuexy-style sidebar + topbar shell. See `ui_kits/greenhouse/README.md`.

---

## Using this system

1. **Link the stylesheet:** `<link rel="stylesheet" href="styles.css">` and load Tabler icons from CDN.
2. **Consume tokens** via CSS custom properties — prefer the semantic aliases (`--app-bg`, `--surface-card`, `--text-body`, `--action-primary`) and the named roles. Don't paste hexes or invent accent colors/gradients.
3. **Mount components** from `window.AXISEfeonceGreenhouseDesignSystem_9781a6` after loading `_ds_bundle.js` (see any component's `*.card.html`).
4. **Write copy** in sentence-case LatAm Spanish, *tú*, verb+object buttons, numbers with context.
5. **Default to Core Blue.** One accent at a time. Flat cards. Tonal feedback. Tabler icons. No emoji.
