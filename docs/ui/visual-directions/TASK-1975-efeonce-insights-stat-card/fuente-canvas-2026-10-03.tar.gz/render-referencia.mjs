// Renderiza las hojas del canvas de la tarjeta de cifra (TASK-1975) a PNG en su tamaño nativo.
// Uso, desde la raíz del repo, tras extraer el paquete en un directorio temporal:
//   node <dir>/render-referencia.mjs <dir>/fuente <salida>
import { createRequire } from 'node:module'
import { readFileSync, writeFileSync, mkdirSync, readdirSync, rmSync } from 'node:fs'
import { join, resolve } from 'node:path'
const repo = process.cwd()
const require = createRequire(join(repo, 'package.json'))
const { chromium } = require('playwright')
const [src, out] = process.argv.slice(2).map(p => resolve(p))
mkdirSync(out, { recursive: true })
// Los /_blob/<id> del canvas son estos archivos del repo.
const blobs = {
  '1ded656c437976da04d6e310cde2440c': 'public/branding/logo-full.svg',
  c6cde117031afefee92d51441c5ff7bd: 'public/branding/logo-negative.svg',
  '871f91be5dc288658aceee2dbac158a6': 'src/lib/artifact-composer/catalogs/insights-report/assets/url-lum.svg'
}
const browser = await chromium.launch()
for (const f of readdirSync(src).filter(n => n.endsWith('.dc.html')).sort()) {
  const s = readFileSync(join(src, f), 'utf8')
  const helmet = s.match(/<helmet>([\s\S]*?)<\/helmet>/)[1]
  const body = s.match(/<\/helmet>([\s\S]*?)<\/x-dc>/)[1]
  const { width, height } = JSON.parse(s.match(/data-props='([^']*)'/)[1]).$preview
  let html = `<!doctype html><html><head><meta charset="utf-8">${helmet}</head><body style="margin:0">${body}</body></html>`
  html = html.replaceAll('{{filtro}}', 'none')
  for (const [id, file] of Object.entries(blobs)) html = html.replaceAll(`/_blob/${id}`, `file://${join(repo, file)}`)
  const tmp = join(out, '_tmp.html')
  writeFileSync(tmp, html)
  const page = await browser.newPage({ viewport: { width, height }, deviceScaleFactor: 1 })
  await page.goto(`file://${tmp}`)
  await page.evaluate(() => document.fonts.ready)
  await page.waitForTimeout(700)
  await page.screenshot({ path: join(out, f.replace('.dc.html', '.png')) })
  await page.close()
  console.log(f, `${width}x${height}`)
}
rmSync(join(out, '_tmp.html'), { force: true })
await browser.close()
