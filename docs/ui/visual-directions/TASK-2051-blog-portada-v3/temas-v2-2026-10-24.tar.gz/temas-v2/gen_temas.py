"""«Explora por tema» v2 — la órbita como puerta a las categorías del blog (propuesta 2026-10-24).

Datos reales: temas/topics.json (categorías y sus últimas entradas, leídas de efeoncepro.com el 2026-10-24).
Tableros: Temas-v2-1440 (HubSpot activo), Temas-v2-1440-aeo (AEO activo, estado al pasar el cursor) y Temas-v2-390.
"""
import html
import json
import math
import os

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(os.path.dirname(HERE), 'artifact-files', 'd0b47eaf-e9d9-406a-b453-d88c2ddd62fd', 'project')
e = lambda s: html.escape(s, quote=True)  # noqa: E731

DATA = json.load(open(os.path.join(os.path.dirname(HERE), 'temas', 'topics.json')))

# Orden en la órbita (en sentido horario desde arriba), promesa corta y color de su línea.
TOPICS = [
    # Orden, colores y posiciones implementados (2026-10-24): colores canónicos de cada categoría; los del mismo color, enfrentados.
    ('hubspot', 'HubSpot', 'Ventas y CRM en orden', '#e86bd0', 'left: 720px; top: 0px; width: 200px; align-items: center; text-align: center;', 'center', -90),
    ('aeo', 'AEO', 'Aparecer en la IA', '#0375db', 'left: 1078px; top: 96px; align-items: flex-start; text-align: left;', 'flex-start', -52),
    ('marketing-digital', 'Marketing digital', 'Decisiones con contexto', '#36c8bf', 'left: 1078px; top: 726px; align-items: flex-start; text-align: left;', 'flex-start', 50),
    ('inbound', 'Inbound', 'Que te encuentren', '#e86bd0', 'left: 690px; top: 816px; width: 260px; align-items: center; text-align: center;', 'center', 90),
    ('design', 'Diseño', 'Creatividad con sistema', '#ff6500', 'right: 690px; top: 726px; align-items: flex-end; text-align: right;', 'flex-end', 128),
    ('loop-marketing', 'Loop Marketing', 'Después del funnel', '#36c8bf', 'right: 690px; top: 96px; align-items: flex-end; text-align: right;', 'flex-end', -128),
]

# Descripción de cada tema: la de su categoría; Diseño no tiene y se propone una.
DESC_DISENO = 'Cómo trabajamos la creatividad: procesos, flujos y criterio para producir más y mejor sin perder la idea.'

TOTAL = 44
R, C = 330, 380


def arc(deg):
    a0, a1 = math.radians(deg - 16), math.radians(deg + 16)
    p = lambda a: (C + R * math.cos(a), C + R * math.sin(a))  # noqa: E731
    (x0, y0), (x1, y1) = p(a0), p(a1)
    sx, sy = p(math.radians(deg))
    return f'M {x0:.1f} {y0:.1f} A {R} {R} 0 0 1 {x1:.1f} {y1:.1f}', f'{sx:.1f}', f'{sy:.1f}'


def topics_js():
    items = []
    for key, name, promise, acc, pos, align, deg in TOPICS:
        d = DATA[key]
        desc = d['desc'] or DESC_DISENO
        reads = [{'t': p['t'], 'href': p['href']} for p in d['posts'][:3]]
        n = d['count'] if key != 'design' else 3
        path, sx, sy = arc(deg)
        items.append({'key': key, 'name': name, 'promise': promise, 'accent': acc, 'pos': pos, 'align': align, 'href': d['link'],
                      'n': n, 'ink': '#ffffff' if acc in ('#0375db',) else '#001a33', 'desc': desc, 'reads': reads, 'arc': path, 'sx': sx, 'sy': sy})
    return json.dumps(items, ensure_ascii=False)


ARROW = ('<svg class="ax" width="18" height="18" viewBox="0 0 24 24" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="2" '
         'stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="m13 6 6 6-6 6"/></g></svg>')

CSS = r"""
*,*::before,*::after{box-sizing:border-box}
body{margin:0}
.tv{font-family:'Poppins',system-ui,sans-serif;background:#001a33;color:#ffffff;-webkit-font-smoothing:antialiased}
.idea{font-family:'Bricolage Grotesque',sans-serif}
a{color:inherit;text-decoration:none}
:focus-visible{outline:2px solid #36c8bf;outline-offset:4px}
.sec{padding:120px 0 72px}
.stage{position:relative;width:1280px;height:900px;margin:0 auto}
.intro{position:absolute;left:0;top:176px;width:440px}
.eyebrow{margin:0;font-size:14px;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:#cfe4fa}
.h2{margin:20px 0 0;font-size:78px;line-height:.92;font-weight:760;letter-spacing:-.045em}
.sub{margin:28px 0 0;max-width:400px;font-size:18px;line-height:1.55;color:#cfe4fa}
.all{display:inline-flex;align-items:center;gap:10px;margin-top:32px;min-height:48px;padding:8px 18px;margin-left:-18px;border-radius:999px;font-size:16px;font-weight:500;transition:background-color 200ms}
.all:hover{background:rgba(207,228,250,.08)}
.n{display:inline-grid;place-items:center;min-width:28px;height:24px;padding:0 8px;border-radius:999px;background:rgba(207,228,250,.14);font-size:13px;font-variant-numeric:tabular-nums}
.ax{flex:none;transition:transform 340ms cubic-bezier(0.2,0,0,1)}
a:hover .ax{transform:translateX(4px)}
/* órbita */
.ring{position:absolute;left:440px;top:70px;width:760px;height:760px;overflow:visible}
.ring .arc{transition:d 600ms cubic-bezier(0.22,1,0.36,1)}
.lab{position:absolute;display:flex;flex-direction:column;gap:6px;padding:8px 4px;color:#ffffff}
.lab .nm{font-size:28px;line-height:1;font-weight:700;letter-spacing:-.02em;transition:color 250ms}
.lab .pr{font-size:13px;line-height:1.3;color:#cfe4fa;display:inline-flex;align-items:center;gap:6px}
.lab .pr .ax{opacity:0;transform:translateX(-4px);transition:opacity 250ms,transform 340ms cubic-bezier(0.2,0,0,1)}
.lab .bar{height:3px;border-radius:2px;transition:width 400ms cubic-bezier(0.2,0,0,1)}
.lab:hover .pr .ax,.lab:focus-visible .pr .ax{opacity:1;transform:none}
/* centro: guía de lectura del tema */
.core{position:absolute;left:610px;top:215px;width:420px;height:470px;display:flex;flex-direction:column;justify-content:center}
.core .swap{display:flex;flex-direction:column;align-items:center;text-align:center}
.core .reads{align-self:stretch;text-align:left}
.swap{animation:swap 500ms cubic-bezier(0.2,0,0,1) both}
@keyframes swap{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}
.tname{font-size:40px;line-height:1;font-weight:760;letter-spacing:-.035em}
.desc{margin:14px 0 0;font-size:15px;line-height:1.5;color:#cfe4fa;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
.start{margin:26px 0 8px;font-size:12px;font-weight:600;letter-spacing:.12em;text-transform:uppercase;color:#cfe4fa}
.reads{list-style:none;margin:0;padding:0;border-top:1px solid rgba(207,228,250,.16)}
.reads li{border-bottom:1px solid rgba(207,228,250,.16)}
.reads a{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:11px 0;font-size:15px;line-height:1.35;font-weight:500}
.reads a span{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.reads a .ax{opacity:.5}
.reads a:hover .ax{opacity:1}
.see{display:inline-flex;align-items:center;gap:10px;margin-top:22px;height:48px;padding:0 20px;border-radius:999px;color:#001a33;font-size:15px;font-weight:600;transition:transform 300ms cubic-bezier(0.2,0,0,1)}
.see .n{background:rgba(0,26,51,.16);color:inherit}
.see:hover{transform:translateY(-2px)}
/* móvil */
.m .sec{padding:64px 16px 56px}
.m .h2{font-size:48px;letter-spacing:-.045em;margin-top:14px}
.m .eyebrow{font-size:12px}
.m .sub{margin-top:18px;font-size:15px}
.m .orbit-m{display:block;margin:28px auto 8px;width:200px;height:200px}
.list{list-style:none;margin:20px 0 0;padding:0;border-top:1px solid rgba(207,228,250,.16)}
.list li{border-bottom:1px solid rgba(207,228,250,.16)}
.row{display:grid;grid-template-columns:4px minmax(0,1fr) auto auto;align-items:center;gap:14px;padding:18px 2px}
.row .dot{width:4px;height:36px;border-radius:2px}
.row .nm{font-size:24px;line-height:1.05;font-weight:740;letter-spacing:-.025em}
.row .pr{display:block;margin-top:4px;font-size:13px;color:#cfe4fa}
.m .all{margin-top:24px}
@media (prefers-reduced-motion:reduce){.swap{animation:none}.ring .arc,.lab .bar,.ax{transition:none}}
"""

FONTS = ('<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="anonymous">'
         '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,300..800&amp;family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&amp;display=swap">')

INTRO = f'''<p class="eyebrow">Explora por tema</p>
      <h2 class="idea h2">Elige por dónde empezar.</h2>
      <p class="sub">Seis temas para lo que hoy te ocupa: ventas, marketing, visibilidad en la IA y creatividad.</p>
      <a href="#archivo" class="all">Todo el archivo <span class="n">{TOTAL}</span>{ARROW}</a>'''

DESKTOP = f'''<section class="sec" aria-labelledby="tv-h">
  <div class="stage">
    <div class="intro">
      {INTRO.replace('<h2 class="idea h2">', '<h2 id="tv-h" class="idea h2">')}
    </div>
    <svg class="ring" viewBox="0 0 760 760" aria-hidden="true">
      <circle cx="380" cy="380" r="330" fill="none" stroke="#72ded8" stroke-opacity="0.16" stroke-width="1"></circle>
      <path class="arc" d="{{{{ act.arc }}}}" fill="none" stroke="{{{{ act.accent }}}}" stroke-width="2" stroke-linecap="round"></path>
      <circle cx="{{{{ act.sx }}}}" cy="{{{{ act.sy }}}}" r="4" fill="{{{{ act.accent }}}}"></circle>
    </svg>
    <nav aria-label="Temas del blog">
      <sc-for list="{{{{ labels }}}}" as="l" hint-placeholder-count="6">
        <a href="{{{{ l.href }}}}" class="lab" style="{{{{ l.pos }}}}" aria-current="{{{{ l.current }}}}" onMouseEnter="{{{{ l.pick }}}}" onFocus="{{{{ l.pick }}}}">
          <span class="idea nm" style="color: {{{{ l.color }}}};">{{{{ l.name }}}}</span>
          <span class="pr">{{{{ l.promise }}}}{ARROW}</span>
          <span class="bar" style="width: {{{{ l.barW }}}}; background: {{{{ l.accent }}}}; align-self: {{{{ l.align }}}};"></span>
        </a>
      </sc-for>
    </nav>
    <div class="core" aria-live="polite">
      <div class="swap" key="{{{{ act.key }}}}">
        <span class="idea tname" style="color: {{{{ act.accent }}}};">{{{{ act.name }}}}</span>
        <p class="desc">{{{{ act.desc }}}}</p>
        <p class="start">Para empezar</p>
        <ul class="reads">
          <sc-for list="{{{{ act.reads }}}}" as="r" hint-placeholder-count="3"><li><a href="{{{{ r.href }}}}"><span>{{{{ r.t }}}}</span>{ARROW}</a></li></sc-for>
        </ul>
        <a href="{{{{ act.href }}}}" class="see" style="background: {{{{ act.accent }}}}; color: {{{{ act.ink }}}};">Ver todo {{{{ act.name }}}} <span class="n">{{{{ act.n }}}}</span>{ARROW}</a>
      </div>
    </div>
  </div>
</section>'''

# Móvil: el selector por toque no es necesario: cada fila ES el enlace a la categoría (más útil con el pulgar).
MOBILE = f'''<section class="sec" aria-labelledby="tvm-h">
  {INTRO.replace('<h2 class="idea h2">', '<h2 id="tvm-h" class="idea h2">')}
  <ul class="list">
    <sc-for list="{{{{ rows }}}}" as="l" hint-placeholder-count="6">
      <li><a href="{{{{ l.href }}}}" class="row"><span class="dot" style="background: {{{{ l.accent }}}};"></span><span><span class="idea nm">{{{{ l.name }}}}</span><span class="pr">{{{{ l.promise }}}}</span></span><span class="n">{{{{ l.n }}}}</span>{ARROW}</a></li>
    </sc-for>
  </ul>
</section>'''


def page(title, body, w, h, active, mobile=False):
    return f'''<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>{e(title)}</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
<helmet>
{FONTS}
<style>{CSS}</style>
</helmet>
<div class="tv{' m' if mobile else ''}">
{body}
</div>
</x-dc>
<script type="text/x-dc" data-dc-script data-props='{{"$preview":{{"width":{w},"height":{h}}}}}'>
class Component extends DCLogic {{
  constructor(props) {{
    super(props);
    this.state = {{ topic: '{active}' }};
  }}
  renderVals() {{
    const T = {topics_js()};
    const cur = this.state.topic;
    const act = T.find((t) => t.key === cur) || T[0];
    const labels = T.map((t) => {{
      const on = t.key === cur;
      return {{ name: t.name, promise: t.promise, href: t.href, n: String(t.n), pos: t.pos, align: t.align, accent: t.accent, color: on ? t.accent : '#ffffff', barW: on ? '48px' : '0px', current: on ? 'true' : 'false', pick: () => {{ if (t.key !== this.state.topic) this.setState({{ topic: t.key }}); }} }};
    }});
    const rows = labels.slice().sort((a, b) => Number(b.n) - Number(a.n));
    return {{ labels, rows, act: {{ ...act, n: String(act.n) }} }};
  }}
}}
</script>
</body>
</html>
'''


if __name__ == '__main__':
    import sys
    hs = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    files = {
        'Temas-v2-1440.dc.html': page('Explora por tema · v2 · 1440', DESKTOP, 1440, hs.get('d', 1092), 'hubspot'),
        'Temas-v2-1440-aeo.dc.html': page('Explora por tema · v2 · 1440 · AEO activo', DESKTOP, 1440, hs.get('d', 1092), 'aeo'),
        'Temas-v2-390.dc.html': page('Explora por tema · v2 · 390', MOBILE, 390, hs.get('m', 1000), 'hubspot', True),
    }
    for name, src in files.items():
        with open(os.path.join(OUT, name), 'w', encoding='utf-8') as f:
            f.write(src)
        print(name, len(src))
