const fs = require('node:fs'), http = require('node:http'), path = require('node:path')
const REPO = '/Users/jreye/Documents/greenhouse-eo'
const { chromium } = require(REPO + '/node_modules/playwright')
const { renderBoard } = require(REPO + '/scripts/public-website/blog-v3/lib/render-node.cjs')
const S = '/private/tmp/claude-501/-Users-jreye-Documents-greenhouse-eo/e98f9610-cea6-420c-aea8-328cea0c9606/scratchpad'
const PROJ = S + '/artifact-files/d0b47eaf-e9d9-406a-b453-d88c2ddd62fd/project', OUT = process.argv[2]
const blobs = { 'edf2539c923a05844876117c08938329': S + '/railimg/249387.webp', '968a4da73d4e0720f7fe02107f8738ae': S + '/railimg/251432.webp', 'c9e0962156cc8176165da470673e8891': S + '/railimg/251397.webp', '6c145ab98627bc792dbffbf831153f89': S + '/railimg/251363.jpg', '9a8e2f558646ef115b46fdbc23b1ed5b': REPO + '/scripts/public-website/blog-archive/source/assets/9a8e2f558646ef115b46fdbc23b1ed5b.png' }
for (const f of fs.readdirSync(S + '/blobs')) blobs[f.split('.')[0]] = S + '/blobs/' + f
const T = { svg: 'image/svg+xml', webp: 'image/webp', png: 'image/png', jpg: 'image/jpeg' }
const boards = { d: ['Temas-v2-1440.dc.html', 1440], a: ['Temas-v2-1440-aeo.dc.html', 1440], m: ['Temas-v2-390.dc.html', 390] }
const pages = {}
for (const [k, [f]] of Object.entries(boards)) { const r = renderBoard(path.join(PROJ, f), {}); const fonts = r.fontLinks.filter(h => h.includes('/css2')).map(h => `<link rel="stylesheet" href="${h}">`).join(''); pages[k] = `<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">${fonts}<style>${r.css}</style></head><body style="margin:0">${r.html}</body></html>` }
const srv = http.createServer((q, s) => { const b = q.url.match(/^\/_blob\/([0-9a-f]{32})/); if (b && blobs[b[1]]) { s.writeHead(200, { 'content-type': T[blobs[b[1]].split('.').pop()] }); return fs.createReadStream(blobs[b[1]]).pipe(s) } const p = pages[q.url.replace(/\//g, '')]; if (p) { s.writeHead(200, { 'content-type': 'text/html; charset=utf-8' }); return s.end(p) } console.log('404', q.url); s.writeHead(404).end() })
srv.listen(0, '127.0.0.1', async () => {
  const port = srv.address().port, br = await chromium.launch(), hs = {}
  for (const [k, [f, w]] of Object.entries(boards)) {
    const ctx = await br.newContext({ viewport: { width: w, height: 900 }, deviceScaleFactor: 1 }), pg = await ctx.newPage()
    await pg.goto(`http://127.0.0.1:${port}/${k}`, { waitUntil: 'networkidle' }); await pg.evaluate(() => document.fonts.ready)
    hs[k] = Math.ceil(await pg.evaluate(() => document.querySelector('.tv').getBoundingClientRect().height))
    await pg.screenshot({ path: `${OUT}/${k}.png`, fullPage: true }); await ctx.close()
  }
  console.log(JSON.stringify(hs)); await br.close(); srv.close()
})
