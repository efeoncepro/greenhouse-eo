#!/usr/bin/env python3
"""«Para leer con calma» v2 — tarjetas de la portada del blog con firma, fecha, tema e imagen (2026-10-24).

Pedido del operador: mantener la grilla mezclada (artículo, caso, guía, diagnóstico, webinar, podcast: una sola familia)
y las tarjetas actuales, pero con los detalles que faltan —autor, fecha, categoría, imagen— más pro, más premium.
Un solo sistema de meta para todos los tipos: fila de tema arriba, título, bajada de dos líneas y pie con filete
(quién + cuándo a la izquierda, la cifra del formato a la derecha). Datos reales de /wp-json/eo/v1/home/rail y
/resources; webinar del canvas v3 y podcast marcados como ejemplo de formato.
"""
import html
import os

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'artifact-files',
                   'd0b47eaf-e9d9-406a-b453-d88c2ddd62fd', 'project')
B = lambda i: '/_blob/' + i  # noqa: E731
e = lambda s: html.escape(s, quote=True)  # noqa: E731

JULIO = B('9a8e2f558646ef115b46fdbc23b1ed5b')
LOGO_NEG = B('d37fcd08d600d957d6fe883d6b055d37')
AEO = B('fa4c472324f79c4861f97234d274662a')
GUIDE = B('63ee6a642d507c74c0ab82f6bc49a131')
THINK = B('77f2dd43cf9a0e0342a093d3a31603e2')

ICON = {
    'arrow': '<svg class="card__a" viewBox="0 0 24 24" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7 17L17 7"/><path d="M8 7h9v9"/></g></svg>',
    'clock': '<svg viewBox="0 0 24 24" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></g></svg>',
    'doc': '<svg viewBox="0 0 24 24" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M7 3.5h7l4 4V20a.5.5 0 0 1-.5.5h-10.5a.5.5 0 0 1-.5-.5V4a.5.5 0 0 1 .5-.5Z"/><path d="M14 3.5V8h4"/><path d="M12 11v6"/><path d="m9.5 14.5 2.5 2.5 2.5-2.5"/></g></svg>',
    'cal': '<svg viewBox="0 0 24 24" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="5.5" width="16" height="14.5" rx="2.5"/><path d="M4 10h16M8.5 3.5v4M15.5 3.5v4"/></g></svg>',
    'play': '<svg viewBox="0 0 24 24" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M8 5.5v13l10.5-6.5Z"/></g></svg>',
    'spark': '<svg viewBox="0 0 24 24" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3.5v4M12 16.5v4M3.5 12h4M16.5 12h4M6 6l2.6 2.6M15.4 15.4 18 18M18 6l-2.6 2.6M8.6 15.4 6 18"/></g></svg>',
}

FMT_ICON = {
    'Artículo': '<path d="M7 3.5h7l4 4V20a.5.5 0 0 1-.5.5h-10.5a.5.5 0 0 1-.5-.5V4a.5.5 0 0 1 .5-.5Z"/><path d="M14 3.5V8h4M9 12h6M9 15.5h6"/>',
    'Caso': '<rect x="3.5" y="7" width="17" height="12.5" rx="2"/><path d="M9 7V5.5a1.5 1.5 0 0 1 1.5-1.5h3A1.5 1.5 0 0 1 15 5.5V7M3.5 12.5h17"/>',
    'Guía descargable': '<path d="M4 5.5a1.5 1.5 0 0 1 1.5-1.5H11v16H5.5A1.5 1.5 0 0 1 4 18.5Z"/><path d="M11 4h7.5A1.5 1.5 0 0 1 20 5.5v13a1.5 1.5 0 0 1-1.5 1.5H11"/><path d="m13.5 12.5 2.5 2.5 2.5-2.5M16 8v7"/>',
    'Diagnóstico': '<path d="M4.5 16a7.5 7.5 0 1 1 15 0"/><path d="m12 16 3.5-4.5"/><circle cx="12" cy="16" r="1.2"/>',
    'Webinar': '<rect x="3.5" y="6" width="12" height="12" rx="2.5"/><path d="m15.5 10.5 5-3v9l-5-3"/>',
    'Podcast': '<rect x="9" y="3.5" width="6" height="11" rx="3"/><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v2.5"/>',
}

CSS = r"""
*,*::before,*::after{box-sizing:border-box}
body{margin:0}
.rv{font-family:'Poppins',system-ui,sans-serif;background:#f7f8f6;color:#023c70;-webkit-font-smoothing:antialiased}
.idea{font-family:'Bricolage Grotesque',sans-serif}
.w{width:min(1280px,calc(100% - 80px));margin:0 auto}
.sec{padding:128px 0 112px}
.sec__h{display:flex;align-items:flex-end;justify-content:space-between;gap:32px;margin-bottom:56px}
.sec__t{margin:0;font-size:96px;line-height:.88;font-weight:760;letter-spacing:-.05em;max-width:900px}
.icoc{display:grid;place-items:center;width:56px;height:56px;border-radius:999px;border:1px solid rgba(2,60,112,.24);background:#ffffff;color:#023c70}
.icoc svg{width:22px;height:22px}
.rail{display:flex;gap:20px;overflow:hidden;padding:16px 40px 24px calc((100% - 1280px)/2);margin-top:-16px}
/* ── La tarjeta: misma caja de siempre (440×600, radio 32), un solo sistema de meta para todos los formatos ── */
.card{position:relative;flex:none;width:440px;height:600px;border-radius:32px;overflow:hidden;display:flex;flex-direction:column;text-decoration:none;color:inherit;transition:transform 300ms cubic-bezier(0.2,0,0,1),box-shadow 300ms cubic-bezier(0.2,0,0,1)}
.card--navy{background:#001a33;color:#ffffff}
.card--blue{background:#023c70;color:#ffffff}
.card--ink{background:#091951;color:#ffffff}
.card--paper{background:#ffffff;color:#023c70;box-shadow:inset 0 0 0 1px rgba(2,60,112,.12)}
.card__a{position:absolute;top:22px;right:22px;width:22px;height:22px;z-index:3;opacity:0;transform:translate(-4px,4px);transition:opacity 200ms,transform 300ms cubic-bezier(0.2,0,0,1)}
.card__img{position:relative;flex:none;height:292px;overflow:hidden}
.card__img img{display:block;width:100%;height:100%;object-fit:cover;transition:transform 900ms cubic-bezier(0.2,0,0,1)}
.card__img::after{content:"";position:absolute;inset:auto 0 0;height:40%;background:linear-gradient(to top,rgba(0,26,51,.28),transparent);pointer-events:none}
.card__fmt{position:absolute;left:20px;top:20px;z-index:2;display:inline-flex;align-items:center;gap:8px;height:30px;padding:0 12px 0 10px;border-radius:999px;background:rgba(0,26,51,.62);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);color:#ffffff;font-size:12px;font-weight:600;letter-spacing:.08em;text-transform:uppercase}
.card__fmt i{width:6px;height:6px;border-radius:50%}
.card__b{display:flex;flex-direction:column;flex:1;min-height:0;padding:26px 30px 24px}
.card--type .card__b{padding:34px 34px 26px}
/* fila de tema */
.kick{display:flex;align-items:center;gap:10px;font-size:13px;font-weight:500;letter-spacing:.01em;opacity:.86}
.kick b{font-weight:600}
.kick__ic{display:grid;place-items:center;width:30px;height:30px;border-radius:50%;flex:none;background:color-mix(in srgb,var(--tc) 24%,transparent);color:color-mix(in srgb,var(--tc) 55%,#ffffff)}
.card--paper .kick__ic{background:color-mix(in srgb,var(--tc) 13%,transparent);color:var(--tc)}
.kick__ic svg{width:16px;height:16px}
.kick--glass{position:absolute;top:20px;left:20px;z-index:3;height:40px;padding:0 16px 0 5px;border-radius:999px;background:rgba(0,26,51,.5);backdrop-filter:blur(14px) saturate(140%);-webkit-backdrop-filter:blur(14px) saturate(140%);box-shadow:inset 0 0 0 1px rgba(255,255,255,.12);opacity:1;color:#ffffff}
/* foto a sangre: la imagen es la tarjeta; el texto se compone abajo sobre una degradé del color de la tarjeta */
.card--photo{justify-content:flex-end}
.card__bg{position:absolute;inset:0;z-index:0;overflow:hidden}
.card__bg img{display:block;width:100%;height:100%;object-fit:cover;transition:transform 900ms cubic-bezier(0.2,0,0,1)}
.card__scrim{position:absolute;inset:0;z-index:1;background:linear-gradient(to top,var(--bg) 0%,var(--bg) 30%,color-mix(in srgb,var(--bg) 82%,transparent) 46%,color-mix(in srgb,var(--bg) 30%,transparent) 64%,transparent 80%)}
.card--photo .card__b{position:relative;z-index:2;flex:none;padding:0 30px 24px}
.card--photo .ttl{margin-top:0;font-size:30px}
.card--photo .ft{margin-top:22px;border-top-color:rgba(255,255,255,.18)}
.kick__live{display:inline-flex;align-items:center;gap:6px;margin-left:auto;font-weight:600;font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:#6ec207}
.kick__live i{width:7px;height:7px;border-radius:50%;background:#6ec207;box-shadow:0 0 0 4px rgba(110,194,7,.22)}
.kick__logo{margin-left:auto;height:22px;width:auto;opacity:1}
/* título y bajada */
.ttl{margin:14px 0 0;font-size:28px;line-height:1.04;font-weight:740;letter-spacing:-.03em;text-wrap:balance;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
.dek{margin:12px 0 0;font-size:14.5px;line-height:1.5;opacity:.72;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
/* cifra protagonista de las tarjetas tipográficas (la identidad de la grilla) */
.big{margin:auto 0 0;font-size:176px;line-height:.8;font-weight:760;letter-spacing:-.07em;font-variant-numeric:tabular-nums}
.big small{margin-left:.18em;font-size:26px;letter-spacing:0;font-weight:500}
.big--date{font-size:150px}
.big--q{font-size:92px;line-height:.86;letter-spacing:-.055em}
/* caso: el cliente es el protagonista, no el tiempo de lectura */
.card--event{background:radial-gradient(130% 70% at 100% 0%,color-mix(in srgb,#36c8bf 26%,transparent),transparent 58%),radial-gradient(90% 60% at 0% 100%,color-mix(in srgb,#0375db 22%,transparent),transparent 60%),#001a33}
.ev{display:flex;align-items:stretch;gap:18px;margin:auto 0 0}
.ev .ev__d{margin:0;font-size:168px;line-height:.78}
.ev__side{display:flex;flex-direction:column;justify-content:space-between;gap:10px;padding:4px 0 6px 18px;border-left:1px solid rgba(207,228,250,.2)}
.ev__m{font-size:34px;line-height:.9;font-weight:760;letter-spacing:.01em;text-transform:uppercase}
.ev__t{display:flex;flex-direction:column;gap:3px;font-size:13px;line-height:1.35}
.ev__t b{font-weight:600}
.ev__t span{opacity:.66}
.ev__c{align-self:flex-start;display:inline-flex;align-items:center;height:26px;padding:0 10px;border-radius:999px;background:color-mix(in srgb,#36c8bf 18%,transparent);color:color-mix(in srgb,#36c8bf 55%,#ffffff);font-size:12px;font-weight:600;font-variant-numeric:tabular-nums}
.ev__cut{position:relative;display:block;flex:none;height:0;margin:22px -34px 0;border-top:1.5px dashed rgba(207,228,250,.24)}
.ev__cut::before,.ev__cut::after{content:"";position:absolute;top:-12px;width:24px;height:24px;border-radius:50%;background:#f7f8f6}
.ev__cut::before{left:-12px}
.ev__cut::after{right:-12px}
.card .ft.ft--stub{border-top:0;margin-top:0;padding-top:18px}
.client{display:flex;flex-direction:column;gap:12px;margin:auto 0 10px}
.client .big{margin:0}
.client__l{font-size:12px;font-weight:600;letter-spacing:.14em;text-transform:uppercase;opacity:.6}
.client__logo{display:block;width:300px;height:auto;transform-origin:left bottom;transition:transform 900ms var(--ease,cubic-bezier(0.22,1,0.36,1))}
/* pie: quién + cuándo | cifra del formato */
.ft{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-top:auto;padding-top:18px;border-top:1px solid rgba(207,228,250,.16)}
.card--paper .ft{border-top-color:rgba(2,60,112,.12)}
.card--type .ft{margin-top:22px}
.who{display:flex;align-items:center;gap:11px;min-width:0}
.who__av{display:flex}
.who__av img,.who__av span{width:34px;height:34px;border-radius:50%;object-fit:cover;flex:none;box-shadow:0 0 0 2px var(--ring,#001a33)}
.who__av span{display:grid;place-items:center;background:#e6edf3;color:#023c70;font:700 12px 'Bricolage Grotesque',sans-serif}
.who__av > * + *{margin-left:-10px}
.who__n{display:flex;flex-direction:column;align-items:flex-start;min-width:0;line-height:1.25}
.who__n b{font-size:14px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.who__n span{font-size:12.5px;opacity:.64;white-space:nowrap}
.who__logo{height:17px;width:auto;display:block}
.stat{display:inline-flex;align-items:center;gap:7px;flex:none;height:32px;padding:0 12px;border-radius:999px;background:rgba(207,228,250,.1);font-size:13px;font-weight:600;font-variant-numeric:tabular-nums;white-space:nowrap}
.card--paper .stat{background:rgba(2,60,112,.06)}
.stat svg{width:15px;height:15px;opacity:.8}
/* guía: la portada del PDF como objeto */
.cover{display:block;width:176px;aspect-ratio:3/4;object-fit:cover;border-radius:10px;margin:22px auto 0;transform:rotate(-3deg);box-shadow:0 24px 44px rgba(0,0,0,.38),0 0 0 1px rgba(255,255,255,.08)}
/* podcast: onda */
.wave{display:flex;align-items:center;gap:3px;height:104px;margin:auto -34px 0}
.wave i{flex:1 1 0;min-width:0}
.wave i{width:6px;border-radius:3px;background:currentColor;opacity:.9}
.wave i:nth-child(3n){opacity:.45}
.ex{position:absolute;right:22px;bottom:-1px;z-index:2;padding:4px 10px;border-radius:8px 8px 0 0;background:#ffcc00;color:#001a33;font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase}
.card:focus-visible{outline:2px solid #023c70;outline-offset:4px}
/* ── Hover líquido: una luz del tema sigue al cursor y la tarjeta se inclina hacia él, todo con la misma curva suave ── */
.card{--tc:#36c8bf;--tcl:color-mix(in srgb,var(--tc) 58%,#ffffff);--ease:cubic-bezier(0.22,1,0.36,1);--px:50%;--py:30%;--rx:0deg;--ry:0deg;transform:perspective(1100px) rotateX(var(--rx)) rotateY(var(--ry));transition:transform 900ms var(--ease),box-shadow 900ms var(--ease)}
.card--paper{--tcl:var(--tc)}
.card--type .kick{padding-right:54px}
.card::before{content:"";position:absolute;inset:0;z-index:2;border-radius:inherit;pointer-events:none;opacity:0;background:radial-gradient(520px circle at var(--px) var(--py),color-mix(in srgb,var(--tc) 34%,transparent),transparent 60%);mix-blend-mode:screen;transition:opacity 700ms var(--ease)}
.card--paper::before{mix-blend-mode:multiply;background:radial-gradient(520px circle at var(--px) var(--py),color-mix(in srgb,var(--tc) 12%,transparent),transparent 62%)}
.card::after{content:"";position:absolute;inset:0;z-index:5;border-radius:inherit;pointer-events:none;padding:1.5px;opacity:0;background:radial-gradient(360px circle at var(--px) var(--py),var(--tcl),transparent 70%);-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask-composite:exclude;transition:opacity 700ms var(--ease)}
.cta{position:absolute;top:20px;right:20px;z-index:6;display:inline-flex;align-items:center;height:42px;padding:0 13px;border-radius:999px;background:rgba(255,255,255,.14);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);color:#ffffff;font-size:14px;font-weight:600;white-space:nowrap;transition:background-color 700ms var(--ease),color 500ms var(--ease),padding 700ms var(--ease)}
.card--paper .cta{background:rgba(2,60,112,.07);color:#023c70}
.cta__l{display:grid;grid-template-columns:0fr;transition:grid-template-columns 700ms var(--ease)}
.cta__l > span{overflow:hidden;opacity:0;transition:opacity 400ms var(--ease)}
.cta svg{width:16px;height:16px;flex:none;transition:transform 700ms var(--ease)}
.kick__ic{position:relative;overflow:hidden;isolation:isolate;transition:color 500ms var(--ease)}
.kick__ic::before{content:"";position:absolute;inset:0;z-index:-1;border-radius:50%;background:var(--tcl);transform:scale(0);transition:transform 700ms var(--ease)}
.card--paper .kick__ic::before{background:var(--tc)}
.big{transition:color 700ms var(--ease),transform 900ms var(--ease);transform-origin:left bottom}
.ttl{transition:transform 900ms var(--ease)}
.who__av img{transition:box-shadow 600ms var(--ease)}
.stat{transition:background-color 600ms var(--ease),color 600ms var(--ease)}
.card__bg img{transition:transform 1400ms var(--ease),filter 900ms var(--ease)}
.wave i{transform-origin:center}
@keyframes rv-wave{0%,100%{transform:scaleY(.32)}50%{transform:scaleY(1.12)}}
/* retardo por barra: la onda viaja y la franja avanza (reglas planas, sin variables en el estilo en línea) */
.wave i:nth-child(1){animation-delay:0ms,-3000ms}
.wave i:nth-child(2){animation-delay:-60ms,-2960ms}
.wave i:nth-child(3){animation-delay:-120ms,-2920ms}
.wave i:nth-child(4){animation-delay:-180ms,-2880ms}
.wave i:nth-child(5){animation-delay:-240ms,-2840ms}
.wave i:nth-child(6){animation-delay:-300ms,-2800ms}
.wave i:nth-child(7){animation-delay:-360ms,-2760ms}
.wave i:nth-child(8){animation-delay:-420ms,-2720ms}
.wave i:nth-child(9){animation-delay:-480ms,-2680ms}
.wave i:nth-child(10){animation-delay:-540ms,-2640ms}
.wave i:nth-child(11){animation-delay:-600ms,-2600ms}
.wave i:nth-child(12){animation-delay:-660ms,-2560ms}
.wave i:nth-child(13){animation-delay:-720ms,-2520ms}
.wave i:nth-child(14){animation-delay:-780ms,-2480ms}
.wave i:nth-child(15){animation-delay:-840ms,-2440ms}
.wave i:nth-child(16){animation-delay:-900ms,-2400ms}
.wave i:nth-child(17){animation-delay:-960ms,-2360ms}
.wave i:nth-child(18){animation-delay:-1020ms,-2320ms}
.wave i:nth-child(19){animation-delay:-1080ms,-2280ms}
.wave i:nth-child(20){animation-delay:-1140ms,-2240ms}
.wave i:nth-child(21){animation-delay:-1200ms,-2200ms}
.wave i:nth-child(22){animation-delay:-1260ms,-2160ms}
.wave i:nth-child(23){animation-delay:-1320ms,-2120ms}
.wave i:nth-child(24){animation-delay:-1380ms,-2080ms}
.wave i:nth-child(25){animation-delay:-1440ms,-2040ms}
.wave i:nth-child(26){animation-delay:-1500ms,-2000ms}
.wave i:nth-child(27){animation-delay:-1560ms,-1960ms}
.wave i:nth-child(28){animation-delay:-1620ms,-1920ms}
.wave i:nth-child(29){animation-delay:-1680ms,-1880ms}
.wave i:nth-child(30){animation-delay:-1740ms,-1840ms}
.wave i:nth-child(31){animation-delay:-1800ms,-1800ms}
.wave i:nth-child(32){animation-delay:-1860ms,-1760ms}
.wave i:nth-child(33){animation-delay:-1920ms,-1720ms}
.wave i:nth-child(34){animation-delay:-1980ms,-1680ms}
.wave i:nth-child(35){animation-delay:-2040ms,-1640ms}
.wave i:nth-child(36){animation-delay:-2100ms,-1600ms}
.wave i:nth-child(37){animation-delay:-2160ms,-1560ms}
.wave i:nth-child(38){animation-delay:-2220ms,-1520ms}
.wave i:nth-child(39){animation-delay:-2280ms,-1480ms}
.wave i:nth-child(40){animation-delay:-2340ms,-1440ms}
.wave i:nth-child(41){animation-delay:-2400ms,-1400ms}
.wave i:nth-child(42){animation-delay:-2460ms,-1360ms}
.wave i:nth-child(43){animation-delay:-2520ms,-1320ms}
.wave i:nth-child(44){animation-delay:-2580ms,-1280ms}
.wave i:nth-child(45){animation-delay:-2640ms,-1240ms}
.wave i:nth-child(46){animation-delay:-2700ms,-1200ms}
.wave i:nth-child(47){animation-delay:-2760ms,-1160ms}
.wave i:nth-child(48){animation-delay:-2820ms,-1120ms}
.wave i:nth-child(49){animation-delay:-2880ms,-1080ms}
.wave i:nth-child(50){animation-delay:-2940ms,-1040ms}
.wave i:nth-child(51){animation-delay:-3000ms,-1000ms}
.wave i:nth-child(52){animation-delay:-3060ms,-960ms}
.wave i:nth-child(53){animation-delay:-3120ms,-920ms}
.wave i:nth-child(54){animation-delay:-3180ms,-880ms}
.wave i:nth-child(55){animation-delay:-3240ms,-840ms}
.wave i:nth-child(56){animation-delay:-3300ms,-800ms}
.wave i:nth-child(57){animation-delay:-3360ms,-760ms}
.wave i:nth-child(58){animation-delay:-3420ms,-720ms}
.wave i:nth-child(59){animation-delay:-3480ms,-680ms}
.wave i:nth-child(60){animation-delay:-3540ms,-640ms}
.wave i:nth-child(61){animation-delay:-3600ms,-600ms}
.wave i:nth-child(62){animation-delay:-3660ms,-560ms}
.wave i:nth-child(63){animation-delay:-3720ms,-520ms}
.wave i:nth-child(64){animation-delay:-3780ms,-480ms}
@keyframes rv-lit{0%,6%{background-color:var(--tc);opacity:1}30%,100%{background-color:currentColor}}
@keyframes rv-ping{0%{box-shadow:0 0 0 0 rgba(110,194,7,.55)}100%{box-shadow:0 0 0 12px rgba(110,194,7,0)}}
.kick__live i{animation:rv-ping 1.8s var(--ease) infinite}
.card.is-h{--px:72%;--py:22%;--rx:2deg;--ry:-3deg}
@media (hover:hover){
.card:hover{transform:perspective(1100px) rotateX(var(--rx)) rotateY(var(--ry)) translateY(-10px);transition:transform 260ms var(--ease),box-shadow 900ms var(--ease);box-shadow:0 40px 70px -24px color-mix(in srgb,var(--tc) 55%,transparent),0 18px 40px rgba(0,26,51,.18)}
.card:hover::before,.card:hover::after{opacity:1}
.card:hover .cta{background:var(--tcl);color:#001a33;padding:0 14px 0 18px}
.card:hover.card--paper .cta{background:var(--tc);color:#ffffff}
.card:hover .cta__l{grid-template-columns:1fr}
.card:hover .cta__l > span{opacity:1;transition-delay:120ms}
.card:hover .cta svg{transform:translateX(5px)}
.card:hover .kick__ic{color:#001a33}
.card:hover.card--paper .kick__ic{color:#ffffff}
.card:hover .kick__ic::before{transform:scale(1)}
.card:hover .big{color:var(--tcl);transform:translateY(-6px)}
.card:hover .client__logo{transform:translateY(-6px) scale(1.03)}
.card:hover .ttl{transform:translateY(-4px)}
.card:hover .who__av img{box-shadow:0 0 0 2px var(--tcl)}
.card:hover .stat{background:var(--tcl);color:#001a33}
.card:hover.card--paper .stat{background:var(--tc);color:#ffffff}
.card:hover .card__bg img{transform:scale(1.08);filter:saturate(1.12) brightness(1.04)}
.card:hover .wave i{animation-name:rv-wave,rv-lit;animation-duration:1.1s,3s;animation-timing-function:cubic-bezier(0.45,0,0.55,1),linear;animation-iteration-count:infinite,infinite}
}
.card.is-h{transform:perspective(1100px) rotateX(var(--rx)) rotateY(var(--ry)) translateY(-10px);transition:transform 260ms var(--ease),box-shadow 900ms var(--ease);box-shadow:0 40px 70px -24px color-mix(in srgb,var(--tc) 55%,transparent),0 18px 40px rgba(0,26,51,.18)}
.card.is-h::before,.card.is-h::after{opacity:1}
.card.is-h .cta{background:var(--tcl);color:#001a33;padding:0 14px 0 18px}
.card.is-h.card--paper .cta{background:var(--tc);color:#ffffff}
.card.is-h .cta__l{grid-template-columns:1fr}
.card.is-h .cta__l > span{opacity:1;transition-delay:120ms}
.card.is-h .cta svg{transform:translateX(5px)}
.card.is-h .kick__ic{color:#001a33}
.card.is-h.card--paper .kick__ic{color:#ffffff}
.card.is-h .kick__ic::before{transform:scale(1)}
.card.is-h .big{color:var(--tcl);transform:translateY(-6px)}
.card.is-h .client__logo{transform:translateY(-6px) scale(1.03)}
.card.is-h .ttl{transform:translateY(-4px)}
.card.is-h .who__av img{box-shadow:0 0 0 2px var(--tcl)}
.card.is-h .stat{background:var(--tcl);color:#001a33}
.card.is-h.card--paper .stat{background:var(--tc);color:#ffffff}
.card.is-h .card__bg img{transform:scale(1.08);filter:saturate(1.12) brightness(1.04)}
.card.is-h .wave i{animation-name:rv-wave,rv-lit;animation-duration:1.1s,3s;animation-timing-function:cubic-bezier(0.45,0,0.55,1),linear;animation-iteration-count:infinite,infinite}
@media (prefers-reduced-motion:reduce){.card,.card:hover,.card.is-h{transform:none!important}.card:hover .big,.card:hover .ttl,.card:hover .card__bg img,.card:hover .cta svg{transform:none!important}.wave i,.kick__live i{animation:none!important}}
/* hoja de la familia */
.sheet{padding:96px 0 112px}
.sheet__g{display:grid;grid-template-columns:repeat(4,440px);gap:28px 20px;justify-content:center}
.sheet__h{width:min(1820px,calc(100% - 80px));margin:0 auto 48px;display:flex;align-items:flex-end;justify-content:space-between;gap:24px}
.sheet__h p{margin:0;max-width:620px;font-size:16px;line-height:1.55;opacity:.8}
.lbl{display:block;margin:0 0 12px 6px;font-size:12px;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:#6d6777}
/* móvil */
.m .w{width:calc(100% - 32px)}
.m .sec{padding:64px 0 56px}
.m .sec__h{margin-bottom:28px}
.m .sec__t{font-size:48px;letter-spacing:-.045em}
.m .icoc{display:none}
.m .rail{padding:16px 16px 24px;gap:14px}
.m .card{width:304px;height:540px;border-radius:26px}
.m .card__img{height:204px}
.m .card__b{padding:22px 22px 20px}
.m .card--type .card__b{padding:26px 24px 20px}
.m .ttl{font-size:23px}
.m .dek{font-size:13.5px}
.m .big{font-size:124px}
.m .big--date{font-size:108px}
.m .big--q{font-size:66px}
.m .client__logo{width:208px}
.m .ev .ev__d{font-size:118px}
.m .ev__m{font-size:26px}
.m .ev__side{padding-left:14px}
.m .ev__t{font-size:12px}
.m .ev__cut{margin:18px -24px 0}
.m .cover{width:132px;margin-top:16px}
.m .who__av img,.m .who__av span{width:30px;height:30px}
.m .who__n b{font-size:13px}
.m .stat{height:30px;padding:0 10px;font-size:12px}
.m .wave{height:76px;margin-left:-24px;margin-right:-24px;gap:2px}
"""


def kick(bar, fmt, topic, extra='', glass=False):
    ic = f'<span class="kick__ic" style="--tc: {bar};"><svg viewBox="0 0 24 24" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">{FMT_ICON[fmt]}</g></svg></span>'
    return f'<span class="kick{" kick--glass" if glass else ""}">{ic}<span><b>{e(fmt)}</b> · {e(topic)}</span>{extra}</span>'


def who_person(name, sub, photo, ring):
    return (f'<span class="who" style="--ring: {ring};"><span class="who__av"><img src="{photo}" alt=""></span>'
            f'<span class="who__n"><b>{e(name)}</b><span>{e(sub)}</span></span></span>')


VERB = {'Artículo': 'Leer', 'Caso': 'Leer el caso', 'Guía descargable': 'Descargar', 'Diagnóstico': 'Medir mi marca', 'Webinar': 'Reservar', 'Podcast': 'Escuchar'}


def cta(fmt):
    return (f'<span class="cta"><span class="cta__l"><span>{e(VERB[fmt])}</span></span><svg viewBox="0 0 24 24" aria-hidden="true"><g fill="none" stroke="currentColor" '
            'stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="m13 6 6 6-6 6"/></g></svg></span>')


def stat(icon, text):
    return f'<span class="stat">{ICON[icon]}{e(text)}</span>'


def photo_card(cls, img, chip, chip_dot, bar, fmt, topic, title, dek, date, mins, ring, pos='center', hov='', foot=None):
    foot = foot or who_person('Julio Reyes', date, JULIO, ring) + stat('clock', f'{mins} min')
    return f'''<a href="#" class="card card--photo {cls}{hov}" style="--bg: {ring}; --tc: {bar};" onMouseMove="{{{{ spot }}}}" onMouseLeave="{{{{ unspot }}}}">{cta(fmt)}
      <span class="card__bg"><img src="{img}" alt="" style="object-position: {pos};"></span><span class="card__scrim"></span>
      {kick(bar, fmt, topic, glass=True)}
      <span class="card__b">
        <span class="idea ttl">{e(title)}</span>
        <span class="dek">{e(dek)}</span>
        <span class="ft">{foot}</span>
      </span>
    </a>'''


def type_card(cls, bar, fmt, topic, big, title, dek, foot, ring, extra_kick='', example=False, hov=''):
    ex = '<span class="ex">Ejemplo</span>' if example else ''
    return f'''<a href="#" class="card card--type {cls}{hov}" style="--tc: {bar};" onMouseMove="{{{{ spot }}}}" onMouseLeave="{{{{ unspot }}}}">{cta(fmt)}{ex}
      <span class="card__b">
        {kick(bar, fmt, topic, extra_kick)}
        {big}
        <span class="idea ttl">{e(title)}</span>
        <span class="dek">{e(dek)}</span>
        <span class="ft" style="--ring: {ring};">{foot}</span>
      </span>
    </a>'''


def cards(h=''):
    c = {}
    c['aeo'] = photo_card('card--navy', B('edf2539c923a05844876117c08938329'), 'Artículo', '#0375db', '#0375db', 'Artículo', 'AEO',
                          'El fin de la web «solo para humanos»',
                          'Qué es la web agéntica, cómo cambia el desarrollo de sitios y qué necesita una web para ser entendida y operada por personas y agentes de IA.',
                          '18 jul 2026', 21, '#001a33', pos='64% center', hov=h)
    c['anam'] = type_card('card--paper', '#8e1b82', 'Caso', 'HubSpot', '<span class="client"><span class="client__l">Cliente</span><img class="client__logo" src="/_blob/4363cbcdc487eb255e7256e4f3d60e19" alt="ANAM"></span>',
                          'Lo que aprendimos diseñando su Customer Agent',
                          'Qué necesita un Customer Agent de HubSpot para responder sin perder contexto, inventar compromisos ni reemplazar decisiones humanas.',
                          who_person('Julio Reyes', '17 jul 2026', JULIO, '#ffffff') + stat('clock', '18 min'), '#ffffff', hov=h)
    c['dash'] = photo_card('card--blue', B('c9e0962156cc8176165da470673e8891'), 'Caso', '#e86bd0', '#e86bd0', 'Caso', 'HubSpot',
                           'Un dashboard no arregla un proceso comercial',
                           'El trabajo real comenzó antes de los paneles: entender el proceso, contrastarlo con el CRM y separar KPI, diagnóstico y piloto.',
                           '17 jul 2026', 13, '#023c70', pos='24% center', hov=h)
    c['cw'] = photo_card('card--navy', B('6c145ab98627bc792dbffbf831153f89'), 'Artículo', '#ff6500', '#ff6500', 'Artículo', 'Diseño',
                         'Creative Workflows: escalar la creatividad sin automatizar el criterio',
                         'Un Creative Workflow convierte decisiones creativas humanas en un sistema que escala sin perder el criterio que las hace buenas.',
                         '15 jul 2026', 23, '#001a33', hov=h)
    c['guide'] = photo_card('card--blue', B('1f49ca13d751067e2dd3d2cec808e174'), '', '', '#0375db', 'Guía descargable', 'AEO',
                            'Web agéntica: tu sitio, listo para la IA',
                            'La guía para que tu web se pueda leer, usar y recomendar por un agente de IA.',
                            '', 0, '#023c70', pos='80% center', hov=h,
                            foot=f'<span class="who"><span class="who__n"><img class="who__logo" src="{THINK}" alt="Efeonce Think" style="height: 26px;"><span style="margin-top: 6px;">Una guía de Efeonce Think</span></span></span>' + stat('doc', 'PDF'))
    c['diag'] = type_card('card--ink', '#0375db', 'Diagnóstico', 'AEO', '<span class="idea big big--q">¿Te ve la IA?</span>',
                          'Efeonce AEO Assessment',
                          'Mide cómo aparece tu marca en ChatGPT, Gemini y Perplexity.',
                          f'<span class="who"><span class="who__n"><img class="who__logo" src="{AEO}" alt="Efeonce AEO" style="height: 20px;"><span style="margin-top: 5px;">Herramienta de Efeonce</span></span></span>' + stat('spark', '3 motores de IA'),
                          '#091951', hov=h)
    c['webinar'] = f'''<a href="#" class="card card--type card--navy card--event{h}" style="--tc: #36c8bf;" onMouseMove="{{{{ spot }}}}" onMouseLeave="{{{{ unspot }}}}">{cta('Webinar')}<span class="ex">Ejemplo</span>
      <span class="card__b">
        {kick('#36c8bf', 'Webinar', 'AEO', '<span class="kick__live"><i></i>En vivo</span>')}
        <span class="ev">
          <span class="idea big ev__d">12</span>
          <span class="ev__side">
            <span class="idea ev__m">Nov</span>
            <span class="ev__t"><b>Jueves · 10:00</b><span>Hora de Chile · En línea</span></span>
            <span class="ev__c">Faltan 19 días</span>
          </span>
        </span>
        <span class="idea ttl">Cómo aparecer en las respuestas de ChatGPT</span>
        <span class="dek">Qué miran los motores de respuesta, cómo medir tu visibilidad y qué cambiar en tu sitio esta misma semana.</span>
        <span class="ev__cut" aria-hidden="true"></span>
        <span class="ft ft--stub" style="--ring: #001a33;">{who_person('Julio Reyes', 'y el equipo de Efeonce', JULIO, '#001a33')}{stat('cal', '45 min · Gratis')}</span>
      </span>
    </a>'''
    import math
    # onda de punta a punta: 64 barras con una envolvente de voz (deterministas)
    bars = [round(14 + 78 * abs(math.sin(i * 0.47) * math.sin(i * 0.13 + 0.6)) ** 0.8) for i in range(64)]
    wave = '<span class="wave" aria-hidden="true">' + ''.join(f'<i style="height: {h}%;"></i>' for h in bars) + '</span>'
    c['pod'] = type_card('card--paper', '#36c8bf', 'Podcast', 'Loop Marketing', wave,
                         'Ep. 1 · Loop Marketing en una empresa real',
                         'Cómo se ve el marco Express, Tailor, Amplify y Evolve cuando lo aplicas en tu equipo.',
                         who_person('Julio Reyes', 'Conduce', JULIO, '#ffffff') + stat('play', '34 min'),
                         '#ffffff', example=True, hov=h)
    return c


FONTS = ('<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="anonymous">'
         '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,300..800&amp;family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&amp;display=swap">')


def page(title, body, w, h, mobile=False):
    return f'''<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>{e(title)}</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
<helmet>
{FONTS}
<style>{CSS}</style>
</helmet>
<div class="rv{' m' if mobile else ''}">
{body}
</div>
</x-dc>
<script type="text/x-dc" data-dc-script data-props='{{"$preview":{{"width":{w},"height":{h}}}}}'>
class Component extends DCLogic {{
  renderVals() {{
    const reduce = typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches;
    return {{
      spot: (e) => {{ const el = e.currentTarget; const r = el.getBoundingClientRect(); const x = (e.clientX - r.left) / r.width; const y = (e.clientY - r.top) / r.height; el.style.setProperty('--px', (x * 100).toFixed(1) + '%'); el.style.setProperty('--py', (y * 100).toFixed(1) + '%'); if (!reduce) {{ el.style.setProperty('--ry', ((x - 0.5) * 7).toFixed(2) + 'deg'); el.style.setProperty('--rx', ((0.5 - y) * 7).toFixed(2) + 'deg'); }} }},
      unspot: (e) => {{ const el = e.currentTarget; el.style.setProperty('--rx', '0deg'); el.style.setProperty('--ry', '0deg'); }},
    }};
  }}
}}
</script>
</body>
</html>
'''


def section(c, order, mobile=False):
    nav = '' if mobile else '''<div style="display: flex; gap: 12px;"><span class="icoc"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 6l-6 6l6 6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></span><span class="icoc"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 6l6 6l-6 6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></span></div>'''
    rail = '\n    '.join(c[k] for k in order)
    return f'''<section class="sec" aria-labelledby="pl-h">
  <div class="w sec__h"><h2 id="pl-h" class="idea sec__t">Para leer con calma.</h2>{nav}</div>
  <div class="rail" role="list">
    {rail}
  </div>
</section>'''


def sheet(c):
    labels = {'aeo': 'Artículo · con imagen', 'anam': 'Caso · tipográfica', 'dash': 'Caso · con imagen', 'cw': 'Artículo · con imagen',
              'guide': 'Guía descargable', 'diag': 'Diagnóstico', 'webinar': 'Webinar (ejemplo)', 'pod': 'Podcast (ejemplo)'}
    items = '\n  '.join(f'<div><span class="lbl">{e(labels[k])}</span>{c[k]}</div>' for k in ['aeo', 'anam', 'dash', 'cw', 'guide', 'diag', 'webinar', 'pod'])
    ch = cards(' is-h')
    hover_items = '\n  '.join(f'<div><span class="lbl">{e(labels[k])} · hover</span>{ch[k]}</div>' for k in ['aeo', 'anam', 'guide', 'pod'])
    return f'''<section class="sheet">
  <div class="sheet__h"><h2 class="idea sec__t" style="font-size: 72px;">Una familia, seis formatos.</h2>
  <p>Misma caja, mismos colores y una sola anatomía: arriba el ícono del formato en el color de su tema, luego título,
  bajada de dos líneas y un pie con filete —quién y cuándo a la izquierda, la cifra del formato a la derecha—. Con una
  buena portada, la foto ocupa toda la tarjeta y el texto se compone abajo; sin ella, manda la cifra grande.</p></div>
  <div class="sheet__g">
  {items}
  </div>
  <div class="sheet__h" style="margin-top: 72px;"><h2 class="idea sec__t" style="font-size: 56px;">Al pasar el cursor.</h2>
  <p>Una luz del color del tema sigue al cursor por dentro de la tarjeta y enciende el borde donde pasa; la tarjeta se
  inclina apenas hacia el cursor y sube, con una curva suave sin rebote. El botón crece de círculo a píldora con el verbo del
  formato, el ícono se llena desde el centro y la cifra grande toma el color del tema. La foto se acerca y la onda del
  podcast late. Con movimiento reducido no hay inclinación ni desplazamiento: sólo la luz y los colores.</p></div>
  <div class="sheet__g">
  {hover_items}
  </div>
</section>'''


if __name__ == '__main__':
    import json
    import sys
    hs = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    c = cards()
    order = ['aeo', 'anam', 'dash', 'cw', 'guide', 'diag', 'webinar']
    files = {
        'Rail-v2-1440.dc.html': page('Para leer con calma · v2 · 1440', section(c, order), 1440, hs.get('d', 900)),
        'Rail-v2-390.dc.html': page('Para leer con calma · v2 · 390', section(c, order, True), 390, hs.get('m', 760), True),
        'Rail-v2-familia.dc.html': page('Para leer con calma · v2 · la familia', sheet(c), 1920, hs.get('s', 1700)),
    }
    for name, src in files.items():
        with open(os.path.join(OUT, name), 'w', encoding='utf-8') as f:
            f.write(src)
        print(name, len(src))
