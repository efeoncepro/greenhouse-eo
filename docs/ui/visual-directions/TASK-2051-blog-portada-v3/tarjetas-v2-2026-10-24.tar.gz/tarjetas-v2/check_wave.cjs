const fs = require('node:fs'), http = require('node:http'), path = require('node:path')
const REPO = '/Users/jreye/Documents/greenhouse-eo'
const { chromium } = require(REPO + '/node_modules/playwright')
const { renderBoard } = require(REPO + '/scripts/public-website/blog-v3/lib/render-node.cjs')
const S = '/private/tmp/claude-501/-Users-jreye-Documents-greenhouse-eo/e98f9610-cea6-420c-aea8-328cea0c9606/scratchpad'
const r = renderBoard(S + '/artifact-files/d0b47eaf-e9d9-406a-b453-d88c2ddd62fd/project/Rail-v2-familia.dc.html', {})
const page = `<!doctype html><html><head><meta charset="utf-8"><style>${r.css}</style></head><body>${r.html}</body></html>`
;(async () => {
  const br = await chromium.launch(), pg = await br.newPage({ viewport: { width: 1920, height: 2600 } })
  await pg.setContent(page)
  const read = () => pg.evaluate(() => [...document.querySelectorAll('.card.is-h .wave i')].slice(0, 6).map(i => getComputedStyle(i).transform.slice(0, 26) + ' ' + getComputedStyle(i).backgroundColor))
  const a = await read(); await pg.waitForTimeout(350); const b = await read()
  console.log(JSON.stringify(a)); console.log(JSON.stringify(b)); console.log('moving:', JSON.stringify(a) !== JSON.stringify(b))
  // hover the first (non-forced) podcast card
  const cards = pg.locator('.sheet__g').first().locator('.card')
  const pod = cards.nth(7); await pod.hover(); await pg.waitForTimeout(200)
  const h1 = await pod.evaluate(c => getComputedStyle(c.querySelector('.wave i')).animationName); console.log('hover anim:', h1)
  await br.close()
})()
