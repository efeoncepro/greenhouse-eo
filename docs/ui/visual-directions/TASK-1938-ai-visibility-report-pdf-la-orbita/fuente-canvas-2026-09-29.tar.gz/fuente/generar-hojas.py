import json, math, subprocess
W,H=794,1123
SP='/private/tmp/claude-501/-Users-jreye-Documents-greenhouse-eo/6ed53333-d569-4a1f-8485-95c5db5a48a1/scratchpad'
LOGO_W='/_blob/b15a1c91f709a09e74d5187c50172973'
BUBBLE='/_blob/497ee58a78f487f09c0a815fb204d79f'
BR="font-family: 'Bricolage Grotesque', sans-serif"
INK='#001a33'; NAVY='#023c70'; MUTED='#5b6b7c'; LINE='#e3e7ec'; SURF='#f4f6f8'; TEAL_D='#0e8c82'; TEAL='#0375db'; SOFT='#cfe4fa'
GROUND='#091951'  # fondo de la línea Engine (efeonceGraphicLine.lines.engine.darkBg); acento Engine #0375db
AIVR_LOCKUP='/_blob/bc65c054fe8640fe32e2b21a484742e7'; AEO_LOCKUP='/_blob/bd0ac74ee422007885e2d3998f80989e'
ICONS=json.load(open(f'{SP}/icons.json'))
def ic(k,size=18): return ICONS[f"{k}_{size}"].replace('<svg ','<svg style="display: block; flex-shrink: 0" ',1)
PROV={'ChatGPT':'/_blob/fe3e3ea8078c559ae798a7977e74e1b9','Claude':'/_blob/41fc5051564fb300d477953b4fbcdad6','Gemini':'/_blob/ce13c2ac704d6b1aa25be898b2714316','Perplexity':'/_blob/5c26fa8747eee348543ecdbd33153c39','Google AI Overview':'/_blob/9167c07707a965fbfc365a2195ea703a'}
def disc(name, d=36, logo=20, border=True):
    b=f'border: 1px solid {LINE}; ' if border else ''
    return f'<span style="display: flex; width: {d}px; height: {d}px; flex-shrink: 0; align-items: center; justify-content: center; border-radius: 999px; {b}background: #ffffff"><img src="{PROV[name]}" alt="{name}" width="{logo}" height="{logo}" style="display: block; width: {logo}px; height: {logo}px; object-fit: contain"></span>'
SLOGAN_EM=11.263  # «Empower your Engine» (efeonceGraphicLine.slogan.widthEmByWord.Engine)
def brand_block(logo_w):
    fs=round(0.64*logo_w/SLOGAN_EM,2); gap=round(1.35*fs,1); word=TEAL if fs>=24 else '#ffffff'
    return f'''<div style="display: flex; flex-direction: column; align-items: center; gap: {gap}px">
<img src="{LOGO_W}" alt="Efeonce" width="{logo_w}" height="{round(logo_w*196.68/837.07)}" style="display: block; width: {logo_w}px; height: auto">
<span aria-label="Empower your Engine" style="display: block; font-size: {fs}px; line-height: 1; letter-spacing: 0; white-space: nowrap; color: #e2e2e2"><span style="font-style: italic; font-weight: 800">Empower</span> <span style="font-weight: 800">your</span> <span style="font-style: italic; font-weight: 900; color: {word}">Engine</span></span>
</div>'''

# Umbrales reales (src/lib/growth/ai-visibility/report/recommendations.ts): < 40 crítico, < 70 atención, resto óptimo.
def sev(score):
    if score is None: return 'sin_dato'
    return 'critico' if score < 40 else ('atencion' if score < 70 else 'optimo')
SEV={'critico':('#dc2e39','#c0222d','Crítico'),'atencion':('#ffb703','#8a6200','Atención'),'optimo':('#157f47','#157f47','Óptimo'),'sin_dato':('#c9d3de','#5b6b7c','Sin dato')}

def page(title, body, bg):
    return f'''<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>{title}</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
<helmet>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,300..800&amp;family=Poppins:wght@300;400;500;600;800;900&amp;display=swap" rel="stylesheet">
<style>
body{{margin:0;font-family:Poppins,-apple-system,sans-serif;background:{bg}}}
a{{color:#023c70}}a:hover{{color:#001a33}}
</style>
</helmet>
{body}
</x-dc>
<script type="text/x-dc" data-dc-script data-props='{{"$preview":{{"width":{W},"height":{H}}}}}'>
class Component extends DCLogic {{
renderVals() {{ return {{}}; }}
}}
</script>
</body>
</html>
'''

def chip_dark(s):
    fill,ink,label=SEV[s]; fill=SEV_DARK.get(s,fill)
    return f'<span style="display: inline-flex; align-items: center; gap: 8px; padding: 6px 12px; border: 1px solid rgba(207, 228, 250, 0.28); border-radius: 999px; font-size: 12px; font-weight: 600; color: #ffffff"><span style="width: 8px; height: 8px; border-radius: 999px; background: {fill}"></span>{label}</span>'
def chip(s):
    fill,ink,label=SEV[s]
    return f'<span style="display: inline-flex; align-items: center; gap: 6px; padding: 4px 10px; background: {SURF}; border-radius: 999px; font-size: 11px; font-weight: 600; color: {ink}; white-space: nowrap"><span style="width: 7px; height: 7px; border-radius: 999px; background: {fill}"></span>{label}</span>'
def pt(cx,cy,r,deg):
    a=math.radians(deg); return cx+r*math.sin(a), cy-r*math.cos(a)

# ---------- datos del ejemplo (fixtures.ts), recalculados con las reglas del modelo
DIMS=[('ai_visibility','ia','Visibilidad en IA',72,25),('entity_clarity','crm','Claridad de identidad',68,15),('category_ownership','objetivo','Dominio de la categoría',54,15),
      ('competitive_sov','medios','Participación de voz',63,15),('citation_quality','prensa','Calidad de las citas',32,15),('message_alignment','social','Alineación del mensaje',None,10),
      ('revenue_intent_coverage','revenue','Intención de compra',45,5)]
D={k:(sc,w) for k,_,_,sc,w in DIMS}
def wavg(keys):
    m=[(D[k][0],D[k][1]) for k in keys if D[k][0] is not None]
    return None if not m else math.floor(sum(s*w for s,w in m)/sum(w for _,w in m)+0.5)
LEVELS=[('01','busqueda','Que te encuentre','Be Found','¿Existes para la IA?','Percepción',wavg(['ai_visibility']),False),
        ('02','codigo','Que te entienda','Be Readable','¿Te puede leer sin adivinar?','Percepción',wavg(['entity_clarity','category_ownership','citation_quality']),False),
        ('03','checklist','Que te represente bien','Be Correct','¿Lo que dice de ti es verdad?','Percepción',wavg(['message_alignment']),False),
        ('04','integracion','Que pueda actuar','Be Actionable','¿Te pueden usar, no solo citar?','Operabilidad',None,True),
        ('05','objetivo','Que te prefiera','Be Intrinsic','¿Eres el default?','Percepción',wavg(['competitive_sov','revenue_intent_coverage']),False)]
ENGINES=[('Gemini',19),('ChatGPT',18),('Claude',17),('Perplexity',14),('Google AI Overview',11)]
SCORE=63

# ---------- portada (dos variantes)
# Sobre el fondo oscuro de la portada, la órbita toma el color de gravedad del puntaje (operador, 2026-09-29):
# paso 400 de la rampa AXIS para crítico y óptimo, 500 para atención (todos ≥ 4,5:1 contra #091951).
SEV_DARK={'critico':'#e25a61','atencion':'#ffb703','optimo':'#46a877'}
def orbit_svg(score, uid='o'):
    cx=cy=200; r=172
    ring=f'''<circle cx="{cx}" cy="{cy}" r="{r}" fill="none" stroke="{SOFT}" stroke-opacity=".16" stroke-width="2"></circle>
<line x1="{cx}" y1="{cy-r-9}" x2="{cx}" y2="{cy-r+9}" stroke="{SOFT}" stroke-opacity=".5" stroke-width="2" stroke-linecap="round"></line>'''
    if score is None:
        return f'<svg width="400" height="400" viewBox="0 0 400 400" aria-hidden="true" style="position: absolute; left: 0; top: 0">{ring}</svg>'
    col=SEV_DARK[sev(score)]
    end=score*3.6 if score<100 else 360; start=max(end-50,0)
    sx,sy=pt(cx,cy,r,start); ex,ey=pt(cx,cy,r,end)
    arc='' if score==0 else f'<path d="M {sx:.2f} {sy:.2f} A {r} {r} 0 0 1 {ex:.2f} {ey:.2f}" fill="none" stroke="{col}" stroke-width="4" stroke-linecap="round"></path>'
    return f'''<svg width="400" height="400" viewBox="0 0 400 400" aria-hidden="true" style="position: absolute; left: 0; top: 0">
<defs><radialGradient id="halo-{uid}"><stop offset="0" stop-color="{col}" stop-opacity=".5"></stop><stop offset="1" stop-color="{col}" stop-opacity="0"></stop></radialGradient></defs>
{ring}
{arc}
<circle cx="{ex:.2f}" cy="{ey:.2f}" r="30" fill="url(#halo-{uid})"></circle>
<circle cx="{ex:.2f}" cy="{ey:.2f}" r="10" fill="{col}"></circle>
</svg>'''

def cover(variant):
    orbit=orbit_svg(SCORE, variant)
    if variant=='cliente':
        kicker='Informe de visibilidad en IA'
        ident=f'''<div style="display: flex; align-items: center; gap: 18px; margin-top: 44px">
<div style="display: flex; width: 148px; height: 64px; box-sizing: border-box; align-items: center; justify-content: center; border: 2px dashed rgba(207, 228, 250, 0.45); border-radius: 16px; font-size: 10px; font-weight: 500; letter-spacing: 0.14em; text-transform: uppercase; color: {SOFT}">Logo del cliente</div>
<div style="display: flex; flex-direction: column; gap: 4px"><span style="font-size: 12px; color: {SOFT}">Preparado para</span><span style="{BR}; font-size: 34px; line-height: 1; font-weight: 740; letter-spacing: -0.03em; color: #ffffff">Marca de ejemplo</span></div>
</div>'''
        trend='<span style="font-size: 13px; font-weight: 600; color: #ffffff">▲ 5 puntos desde el 4 de mayo</span>'
    else:
        kicker='Diagnóstico de visibilidad en IA'
        ident=f'''<div style="display: flex; flex-direction: column; gap: 10px; margin-top: 44px">
<h1 style="margin: 0; {BR}; font-size: 64px; line-height: 0.98; font-weight: 760; letter-spacing: -0.04em; color: #ffffff">Marca de ejemplo</h1>
</div>'''
        trend=f'<span style="font-size: 13px; color: {SOFT}">Primera medición: tu punto de partida</span>'
    legend=''.join(f'<span style="display: flex; align-items: center; gap: 6px"><span style="width: 7px; height: 7px; border-radius: 999px; background: {SEV_DARK[k]}"></span>{t}</span>' for k,t in [('critico','0–39 Crítico'),('atencion','40–69 Atención'),('optimo','70–100 Óptimo')])
    return f'''<div style="width: {W}px; height: {H}px; box-sizing: border-box; padding: 64px 64px 56px; background: {GROUND}; display: flex; flex-direction: column; font-family: Poppins, sans-serif">
<div style="display: flex; justify-content: space-between; align-items: center; gap: 16px">
<img src="{AIVR_LOCKUP}" alt="Efeonce AI Visibility Report" style="display: block; height: 28px; width: auto">
<span style="font-size: 12px; font-weight: 500; color: {SOFT}; padding: 6px 12px; border: 1px solid rgba(207, 228, 250, 0.28); border-radius: 999px">Mayo 2026</span>
</div>
{ident}
<span style="margin-top: 10px; font-size: 13px; color: {SOFT}">Cifras ilustrativas · datos al 19 de mayo de 2026</span>
<div style="display: flex; flex-direction: column; align-items: center; gap: 14px; margin-top: 28px">
<div style="position: relative; width: 400px; height: 400px">
{orbit}
<div style="position: absolute; left: 0; top: 0; width: 400px; height: 400px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 4px">
<span style="{BR}; font-size: 128px; line-height: 0.9; font-weight: 760; letter-spacing: -0.05em; color: #ffffff">63</span>
<span style="font-size: 14px; color: {SOFT}">de 100</span>
<div style="margin-top: 12px">{chip_dark(sev(SCORE))}</div>
</div>
</div>
{trend}
<div style="display: flex; gap: 16px; font-size: 11px; color: {SOFT}">{legend}</div>
</div>
<div style="display: flex; flex-direction: column; gap: 12px; margin-top: 34px">
<span style="font-size: 12px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: {SOFT}">Veredicto</span>
<p style="margin: 0; {BR}; font-size: 40px; line-height: 1.02; font-weight: 740; letter-spacing: -0.035em; color: #ffffff">Te encuentran,<span style="font-weight: 320; color: {SOFT}"> pero casi no te citan.</span></p>
<div style="display: flex; align-items: center; gap: 16px; margin-top: 6px">
<div style="display: flex; gap: 8px">{''.join(disc(n, 36, 19, False) for n in PROV)}</div>
<div style="display: flex; flex-direction: column; gap: 4px; font-size: 12px; color: {SOFT}"><img src="{AEO_LOCKUP}" alt="Efeonce AEO" style="display: block; height: 20px; width: auto; align-self: flex-start"><span>Resultado del AEO Assessment · 5 motores · 24 preguntas</span></div>
</div>
</div>
<div style="flex-grow: 1"></div>
<div style="display: flex; justify-content: center"><img src="{LOGO_W}" alt="Efeonce" width="130" height="31" style="display: block; width: 130px; height: auto"></div>
</div>'''

# ---------- interiores compartidos
AIVR_LOCKUP_POS='/_blob/825f4fb837b9193b266b013a3babe24d'; BUBBLE_LIGHT='/_blob/7a9e2b86b0b77bf6eec6f97ef64fb713'
CHAPTERS=[('02','objetivo','Qué hacer'),('03','medicion','Por qué ocurre'),('04','ia','Dónde estás'),('05','medios','Mercado y fuentes')]
TOTAL_PAGES='06'
def header(no):
    idx=[c[0] for c in CHAPTERS].index(no); icon,name=CHAPTERS[idx][1],CHAPTERS[idx][2]
    segs=''.join(f'<span style="display: block; width: 22px; height: 4px; border-radius: 2px; background: {TEAL if i==idx else ("#9fb3c8" if i<idx else LINE)}"></span>' for i in range(len(CHAPTERS)))
    return f'''<div style="display: flex; justify-content: space-between; align-items: center; padding-bottom: 16px; border-bottom: 1px solid {LINE}">
<img src="{AIVR_LOCKUP_POS}" alt="Efeonce AI Visibility Report" style="display: block; height: 22px; width: auto">
<div style="display: flex; align-items: center; gap: 14px">
<span style="display: flex; align-items: center; gap: 8px; font-size: 11px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: {INK}">{ic(icon,18)}<span>{name}</span></span>
<div style="display: flex; gap: 4px" aria-label="Capítulo {idx+1} de {len(CHAPTERS)}">{segs}</div>
</div>
</div>'''
def footer(no):
    return f'''<div style="display: grid; grid-template-columns: minmax(0, 1fr) auto minmax(0, 1fr); gap: 16px; align-items: center; padding-top: 14px; border-top: 1px solid {LINE}">
<span style="font-size: 11px; line-height: 1.4; color: {MUTED}">Marca de ejemplo · Mayo 2026</span>
<img src="{BUBBLE_LIGHT}" alt="efeoncepro.com" style="display: block; height: 18px; width: auto">
<span style="justify-self: end; {BR}; font-size: 15px; font-weight: 700; color: {INK}">{no}<span style="font-weight: 400; color: {MUTED}"> / {TOTAL_PAGES}</span></span>
</div>'''
def eyebrow(text, icon=None):
    i = ic(icon, 18) if icon else ''
    return f'<span style="display: flex; align-items: center; gap: 8px; font-size: 11px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: {MUTED}">{i}{text}</span>'
def section(eb, title, helper=None, size=32, icon=None):
    h=f'<span style="font-size: 14px; line-height: 1.55; color: {MUTED}; max-width: 600px">{helper}</span>' if helper else ''
    e=eyebrow(eb, icon) if eb else ''
    return f'''<div style="display: flex; flex-direction: column; gap: 8px">{e}<h2 style="margin: 0; {BR}; font-size: {size}px; line-height: 1.04; font-weight: 720; letter-spacing: -0.03em; color: {INK}; text-wrap: balance">{title}</h2>{h}</div>'''
def interior(no, content):
    return f'''<div style="width: {W}px; height: {H}px; box-sizing: border-box; padding: 56px 64px 44px; background: #ffffff; display: flex; flex-direction: column; gap: 30px; font-family: Poppins, sans-serif">
{header(no)}
{content}
<div style="flex-grow: 1"></div>
{footer(no)}
</div>'''
def bar(name, pct, value, sub, fill=NAVY, bold=False, ink=INK, lead='', subnode=None):
    s = subnode if subnode is not None else f'<span style="font-size: 11px; color: {MUTED}">{sub}</span>'
    return f'''<div style="display: grid; grid-template-columns: 230px minmax(0, 1fr) 104px; gap: 18px; align-items: center">
<span style="display: flex; align-items: center; gap: 10px; font-size: 13px; font-weight: {600 if bold else 400}; color: {INK}">{lead}<span>{name}</span></span>
<div style="height: 10px; background: #eef1f4; border-radius: 999px"><div style="width: {pct}%; height: 10px; background: {fill}; border-radius: 999px"></div></div>
<div style="display: flex; flex-direction: column; align-items: flex-end; gap: 3px"><span style="font-size: 14px; font-weight: 600; color: {ink}">{value}</span>{s}</div>
</div>'''

# 02 · Qué hacer
recs=[('Gánate citas creíbles','citation_quality','Consigue menciones externas confiables con PR digital y actualiza la frescura de tus fuentes propias.'),
      ('Apropia tu categoría','category_ownership','Publica un explainer de categoría, una página comparativa y perfiles en directorios de terceros.'),
      ('Cubre la intención de compra','revenue_intent_coverage','Agrega contenido de precios, implementación y casos de uso con pruebas.')]
DLAB={k:l for k,_,l,_,_ in DIMS}
rrows=[]
for i,(t,k,a) in enumerate(recs):
    sc,w=D[k]
    rrows.append(f'''<div style="display: grid; grid-template-columns: 44px minmax(0, 1fr); gap: 16px; padding: 18px 0; border-bottom: 1px solid {LINE}">
<span style="{BR}; font-size: 32px; line-height: 1; font-weight: 720; color: {INK}">{i+1}</span>
<div style="display: flex; flex-direction: column; gap: 6px"><div style="display: flex; align-items: center; gap: 10px"><span style="font-size: 17px; font-weight: 600; color: {INK}">{t}</span>{chip(sev(sc))}</div>
<span style="font-size: 13px; line-height: 1.55; color: {MUTED}">{a}</span>
<span style="display: flex; align-items: center; gap: 8px; font-size: 12px; color: {INK}">{ic('medicion',18)}<span>Mueve <b style="font-weight: 600">{DLAB[k]}</b> · hoy {sc}/100 · peso {w} % del puntaje</span></span></div>
</div>''')
gapcard=f'''<div style="display: flex; flex-direction: column; gap: 14px; padding: 28px 30px; background: {NAVY}; border-radius: 18px">
<div style="display: flex; justify-content: space-between; align-items: center; gap: 12px"><span style="font-size: 11px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: {SOFT}">Brecha principal · Calidad de las citas 32/100</span>{chip_dark('critico')}</div>
<span style="{BR}; font-size: 38px; line-height: 1; font-weight: 720; letter-spacing: -0.03em; color: #ffffff">Te mencionan, pero no te citan.</span>
<span style="font-size: 14px; line-height: 1.6; color: {SOFT}">Solo <b style="font-weight: 600; color: #ffffff">32 de cada 100</b> respuestas con cita apuntan a tu sitio, y la fuente más citada sobre tu categoría es un tercero (g2.com, 18 de 45 citas).</span>
</div>'''
p2=interior('02', f'''<div style="display: flex; flex-direction: column; gap: 16px">
{section(None,'Lo que más pesa hoy')}
{gapcard}
</div>
<div style="display: flex; flex-direction: column; gap: 4px">
{section(None,'Plan prioritario','Tres movimientos, ordenados por lo que más mueve tu puntaje.', 26)}
<div style="display: flex; flex-direction: column">{''.join(rrows)}</div>
</div>''')

# 03 · Por qué
dbars=[]
for k,icon,l,sc,w in DIMS:
    s=sev(sc); fill,ink,label=SEV[s]
    subn=f'<span style="display: flex; align-items: center; gap: 6px; font-size: 11px; color: {MUTED}"><span style="width: 7px; height: 7px; border-radius: 999px; background: {fill}"></span>{label}</span>'
    dbars.append(bar(f'{l}<span style="font-size: 11px; color: {MUTED}"> · {w} %</span>', sc or 0, f'{sc}/100' if sc is not None else '—', None, NAVY, ink=INK if sc is not None else MUTED, lead=ic(icon,18), subnode=subn))
def kpi(icon, over, big, hint, extra=''):
    return f'''<div style="display: flex; flex-direction: column; gap: 8px; padding: 18px 20px; background: {SURF}; border-radius: 14px">
<span style="display: flex; align-items: center; gap: 8px; font-size: 11px; font-weight: 600; color: {MUTED}">{ic(icon,18)}{over}</span>
<span style="{BR}; font-size: 36px; line-height: 1; font-weight: 740; letter-spacing: -0.035em; color: {INK}">{big}</span>
{extra}<span style="font-size: 11px; line-height: 1.45; color: {MUTED}">{hint}</span>
</div>'''
senti=f'<div style="display: flex; height: 8px; border-radius: 999px; overflow: hidden"><div style="width: 38%; background: {NAVY}"></div><div style="width: 45%; background: #c9d3de"></div><div style="width: 17%; background: #dc2e39"></div></div>'
kpis=f'''<div style="display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 14px">
{kpi('prensa','Share de citas','32 %','de las respuestas con cita apuntan a tu sitio')}
{kpi('social','Sentimiento','Neutral','Positivo 38 % · neutral 45 % · negativo 17 %', senti)}
{kpi('medicion','Prominencia','#2','Tu mejor posición en la respuesta; promedio #3')}
</div>'''
p3=interior('03', f'''<div style="display: flex; flex-direction: column; gap: 16px">
{section(None,'Siete dimensiones, con su peso', 'Cada dimensión aporta al puntaje según su peso; la gravedad sale de la misma escala de la portada.')}
<div style="display: flex; flex-direction: column; gap: 12px">{''.join(dbars)}</div>
</div>
<div style="display: flex; flex-direction: column; gap: 16px">
{section(None,'Calidad de la presencia','No basta con aparecer: importa si te citan, cómo te describen y en qué lugar.', 26)}
{kpis}
</div>''')

# 04 · Dónde
rows=[]
for o,icon,l,en,q,axis,sc,cov in LEVELS:
    if cov: right=f'<span style="padding: 5px 10px; border: 1px solid {LINE}; border-radius: 999px; font-size: 11px; font-weight: 600; color: {MUTED}">En cobertura</span>'
    elif sc is None: right=f'<div style="display: flex; align-items: baseline; gap: 10px"><span style="{BR}; font-size: 28px; line-height: 1; font-weight: 720; color: {MUTED}">—</span>{chip("sin_dato")}</div>'
    else: right=f'<div style="display: flex; align-items: baseline; gap: 10px"><span style="{BR}; font-size: 28px; line-height: 1; font-weight: 720; letter-spacing: -0.03em; color: {INK}">{sc}</span>{chip(sev(sc))}</div>'
    rows.append(f'''<div style="display: grid; grid-template-columns: 42px minmax(0, 1fr) auto; gap: 16px; align-items: center; padding: 10px 0; border-bottom: 1px solid {LINE}">
<span style="display: flex; width: 42px; height: 42px; align-items: center; justify-content: center; border-radius: 999px; background: {SURF}">{ic(icon, 22)}</span>
<div style="display: flex; flex-direction: column; gap: 1px"><span style="font-size: 11px; font-weight: 600; color: {MUTED}">Nivel {o} · {axis}</span><span style="font-size: 15px; font-weight: 600; color: {INK}">{l} <span style="font-weight: 400; color: {MUTED}">· {en}</span></span><span style="font-size: 12px; color: {MUTED}">{q}</span></div>
{right}
</div>''')
axes=f'<div style="display: flex; gap: 24px; font-size: 12px; color: {MUTED}"><span><b style="font-weight: 600; color: {INK}">Percepción</b> · ¿te mencionan? (niveles 01, 02, 03 y 05)</span><span><b style="font-weight: 600; color: {INK}">Operabilidad</b> · ¿te pueden usar? (04)</span></div>'
ebars=[]
for n,p in ENGINES:
    pct=round(p/24*100); s=sev(pct); fill,ink,label=SEV[s]
    subn=f'<span style="display: flex; align-items: center; gap: 6px; font-size: 11px; color: {MUTED}"><span style="width: 7px; height: 7px; border-radius: 999px; background: {fill}"></span>{p} de 24</span>'
    ebars.append(bar(n, pct, f'{pct} %', None, NAVY, lead=disc(n, 30, 16), subnode=subn))
p4=interior('04', f'''<div style="display: flex; flex-direction: column; gap: 12px">
{section(None,'Niveles para existir en un internet de agentes')}
{axes}
<div style="display: flex; flex-direction: column">{''.join(rows)}</div>
</div>
<div style="display: flex; flex-direction: column; gap: 14px">
{section(None,'Motor por motor','Dónde más se pierde presencia: Google AI Overview (46 %) y Perplexity (58 %).', 26)}
<div style="display: flex; flex-direction: column; gap: 10px">{''.join(ebars)}</div>
</div>''')

# 05 · Mercado y fuentes
sov=[('Competidor A',48,False),('Competidor B',41,False),('Tu marca',32,True),('Competidor C',23,False)]
tot=sum(m for _,m,_ in sov)
sbars='\n'.join(bar(n, round(m/48*100), f'{round(m/tot*100)} %', f'{m} menciones', NAVY if b else '#c9d3de', bold=b) for n,m,b in sov)
CLS={'third_party':'Terceros','ugc':'Comunidad','own_domain':'Tu sitio','competitor':'Competidor'}
src=[('g2.com',18,'third_party'),('reddit.com',11,'ugc'),('[tu dominio]',9,'own_domain'),('competidor-a.com',7,'competitor')]
srows='\n'.join(bar(d, round(c/18*100), f'{c}', CLS[k], NAVY if k=='own_domain' else '#c9d3de', bold=(k=='own_domain')) for d,c,k in src)
prov=f'''<div style="display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 12px">
{''.join(f'<div style="display: flex; gap: 8px; align-items: flex-start">{ic(icon,18)}<div style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 11px; color: {MUTED}">{k}</span><span style="font-size: 13px; font-weight: 600; color: {INK}">{v}</span></div></div>' for icon,k,v in [('calendario','Datos al','19 may 2026'),('composer','Preguntas','24'),('medicion','Versión del puntaje','[versión]'),('contrato','Paquete de preguntas','2.3.1')])}
</div>'''
p5=interior('05', f'''<div style="display: flex; flex-direction: column; gap: 14px">
{section(None,'Participación de voz','Qué parte de las menciones ocupas frente a otras marcas (144 menciones en total).')}
<div style="display: flex; flex-direction: column; gap: 10px">{sbars}</div>
</div>
<div style="display: flex; flex-direction: column; gap: 14px">
{section(None,'Fuentes que sostienen la respuesta','Los dominios que los motores citan al hablar de tu categoría (45 citas).', 26)}
<div style="display: flex; flex-direction: column; gap: 10px">{srows}</div>
</div>
<div style="display: flex; flex-direction: column; gap: 14px; padding: 20px 22px; background: {SURF}; border-radius: 14px">
<span style="font-size: 13px; font-weight: 600; color: {INK}">Procedencia y metodología</span>
{prov}
<span style="font-size: 11px; line-height: 1.55; color: {MUTED}">[Aviso de alcance del informe: el texto vigente del informe actual]</span>
</div>''')

# ---------- contraportadas (dos variantes)
SOC = [('LinkedIn','<path d="M8 11v5m0-8v.01M12 16v-5m4 5v-3a2 2 0 1 0-4 0"/><path d="M3 7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4v10a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4z"/>'),
 ('Instagram','<path d="M4 8a4 4 0 0 1 4-4h8a4 4 0 0 1 4 4v8a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4z"/><path d="M9 12a3 3 0 1 0 6 0a3 3 0 0 0-6 0m7.5-4.5v.01"/>'),
 ('YouTube','<path d="M2 8a4 4 0 0 1 4-4h12a4 4 0 0 1 4 4v8a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4z"/><path d="m10 9l5 3l-5 3z"/>'),
 ('Threads','<path d="M19 7.5Q17 3 12 3c-5 0-8 2.5-8 9s3.5 9 8 9s7-3 7-5s-1-5-7-5c-2.5 0-3 1.25-3 2.5C9 15 10 16 11.5 16c2.5 0 3.5-1.5 3.5-5s-2-4-3-4s-1.833.333-2.5 1"/>')]
socials=''.join(f'<span aria-label="{l}" style="display: flex; width: 40px; height: 40px; align-items: center; justify-content: center; border-radius: 999px; border: 1px solid rgba(207, 228, 250, 0.22)"><svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true" style="display: block; opacity: 0.78"><g fill="none" stroke="#ffffff" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round">{b}</g></svg></span>' for l,b in SOC)
Q_PX=24; A_PX=78
ring=f'<span aria-hidden="true" style="display: inline-block; width: 0.42em; height: 0.42em; border: max(1px, 0.06em) solid {TEAL}; border-radius: 50%; margin-right: 0.35em; vertical-align: 0.08em; box-sizing: border-box"></span>'
sphere=f'<span aria-hidden="true" style="display: inline-block; width: 0.2em; height: 0.2em; border-radius: 50%; background: {TEAL}; margin-left: 0.03em"></span>'
def voice(q, a, evidence):
    return f'''<div style="display: flex; flex-direction: column; align-items: center; gap: 14px; text-align: center">
<p style="margin: 0; font-size: {Q_PX}px; line-height: 1.2; font-weight: 300; color: #ffffff">{ring}{q}</p>
<p style="margin: 0; {BR}; font-size: {A_PX}px; line-height: 0.95; font-weight: 760; letter-spacing: -0.035em; color: #ffffff">{a}{sphere}</p>
<p style="margin: 14px 0 0; max-width: 460px; font-size: 16px; line-height: 1.55; color: {SOFT}">{evidence}</p>
</div>'''
def back(variant):
    if variant=='prospecto':
        v=voice('¿Conversamos?','Cuando quieras','Te mostramos <b style="font-weight: 600; color: #ffffff">qué mover primero</b> para subir tu puntaje, y cómo medirlo mes a mes.')
        action=f'''<div style="display: flex; flex-direction: column; align-items: center; gap: 12px; margin-top: 34px">
<a href="https://efeoncepro.com/contacto/?utm_source=ai-visibility-grader&amp;utm_medium=pdf&amp;utm_campaign=grader-report&amp;utm_content=contraportada" style="display: inline-block; padding: 16px 30px; background: #ffffff; color: {INK}; border-radius: 999px; font-size: 16px; font-weight: 600; text-decoration: none">Agenda una reunión  →</a>
<span style="font-size: 13px; color: {SOFT}">Elige el horario en efeoncepro.com/contacto</span>
</div>
<div style="display: flex; align-items: center; justify-content: center; gap: 12px; margin-top: 30px">
<img src="{BUBBLE}" alt="efeoncepro.com" width="163" height="32" style="display: block; width: 163px; height: 32px">
<div style="width: 12px"></div>
{socials}
</div>'''
    else:
        v=voice('¿Lo revisamos juntos?','Cuando quieras','Tu equipo en Efeonce trae la lectura y el <b style="font-weight: 600; color: #ffffff">plan de los tres movimientos</b> a la próxima reunión.')
        action=f'''<div style="display: flex; align-items: stretch; justify-content: center; gap: 14px; margin-top: 34px">
<div style="display: flex; flex-direction: column; gap: 4px; padding: 18px 22px; border: 1px solid rgba(207, 228, 250, 0.22); border-radius: 16px; min-width: 250px">
<span style="font-size: 11px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: {SOFT}">Responsable de tu cuenta</span>
<span style="font-size: 16px; font-weight: 600; color: #ffffff">Julio Reyes</span>
<span style="font-size: 13px; color: {SOFT}">Managing Director &amp; GTM</span>
<span style="font-size: 13px; color: {SOFT}">jreyes@efeoncepro.com</span>
</div>
<div style="display: flex; flex-direction: column; gap: 4px; padding: 18px 22px; border: 1px solid rgba(207, 228, 250, 0.22); border-radius: 16px; min-width: 170px">
<span style="font-size: 11px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: {SOFT}">Próximo informe</span>
<span style="font-size: 16px; font-weight: 600; color: #ffffff">[fecha]</span>
<span style="font-size: 13px; color: {SOFT}">Medimos lo mismo, mes a mes</span>
</div>
</div>'''
    return f'''<div style="width: {W}px; height: {H}px; box-sizing: border-box; padding: 64px 64px 60px; background: {GROUND}; display: flex; flex-direction: column; align-items: center; font-family: Poppins, sans-serif">
<div style="flex-grow: 1"></div>
{v}
{action}
<div style="height: 112px"></div>
{brand_block(240)}
<div style="flex-grow: 1"></div>
<span style="font-size: 11px; color: #9fb3c8">Efeonce Group SpA · Santiago, Chile</span>
</div>'''

# ---------- lámina de estados de la órbita de portada (sólo diseño, en español)
SW,SH=1848,900
def states_board():
    cases=[(28,'critico','0–39 · Crítico','La esfera y su estela en rojo: la marca casi no existe para la IA.'),
           (63,'atencion','40–69 · Atención','En ámbar: aparece, pero hay brechas que pesan.'),
           (84,'optimo','70–100 · Óptimo','En verde: la IA la encuentra, la entiende y la cita.'),
           (None,'sin_dato','Sin dato','Sólo el anillo: sin medición no hay esfera ni cifra.')]
    cols=''
    for sc,k,title,cap in cases:
        num='—' if sc is None else str(sc)
        of='' if sc is None else f'<span style="font-size: 14px; color: {SOFT}">de 100</span>'
        cols+=f'''<div style="display: flex; flex-direction: column; align-items: center; gap: 18px; width: 400px">
<div style="position: relative; width: 400px; height: 400px">
{orbit_svg(sc, k)}
<div style="position: absolute; left: 0; top: 0; width: 400px; height: 400px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 4px">
<span style="{BR}; font-size: 128px; line-height: 0.9; font-weight: 760; letter-spacing: -0.05em; color: #ffffff">{num}</span>
{of}
<div style="margin-top: 12px">{chip_dark(k)}</div>
</div>
</div>
<span style="font-size: 15px; font-weight: 600; color: #ffffff">{title}</span>
<span style="max-width: 320px; font-size: 13px; line-height: 1.5; text-align: center; color: {SOFT}">{cap}</span>
</div>'''
    return f'''<div style="width: {SW}px; height: {SH}px; box-sizing: border-box; padding: 64px; background: {GROUND}; display: flex; flex-direction: column; gap: 48px; font-family: Poppins, sans-serif">
<div style="display: flex; flex-direction: column; gap: 10px">
<span style="font-size: 12px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: {SOFT}">Portada · la órbita que mide</span>
<p style="margin: 0; {BR}; font-size: 44px; line-height: 1.02; font-weight: 740; letter-spacing: -0.035em; color: #ffffff">El color de la órbita dice la gravedad del puntaje.</p>
<span style="max-width: 1100px; font-size: 14px; line-height: 1.55; color: {SOFT}">La esfera siempre está en el puntaje real (valor × 3,6°) con su estela de 50°. Estela, esfera, halo y el punto de la etiqueta toman el color de la gravedad, con los mismos umbrales del modelo. El anillo, la marca de partida y la cifra no cambian, y la etiqueta en texto siempre acompaña al color.</span>
</div>
<div style="display: flex; justify-content: space-between">{cols}</div>
</div>'''

files={
 'GraderPortadaProspecto.dc.html':('Grader · portada · no cliente',cover('prospecto'),GROUND,'Portada · no cliente'),
 'GraderPortadaCliente.dc.html':('Grader · portada · cliente',cover('cliente'),GROUND,'Portada · cliente'),
 'GraderQueHacer.dc.html':('Grader · qué hacer',p2,'#ffffff','02 · Qué hacer'),
 'GraderPorQue.dc.html':('Grader · por qué',p3,'#ffffff','03 · Por qué ocurre'),
 'GraderDonde.dc.html':('Grader · dónde',p4,'#ffffff','04 · Dónde estás'),
 'GraderMercado.dc.html':('Grader · mercado y fuentes',p5,'#ffffff','05 · Mercado y fuentes'),
 'GraderContraProspecto.dc.html':('Grader · contraportada · no cliente',back('prospecto'),GROUND,'Contraportada · no cliente'),
 'GraderContraCliente.dc.html':('Grader · contraportada · cliente',back('cliente'),GROUND,'Contraportada · cliente')}
for path,(t,b,bg,_) in files.items():
    open(path,'w').write(page(t,b,bg))
open('GraderPortadaEstados.dc.html','w').write(page('Grader · estados de la órbita', states_board(), GROUND).replace('"width":%d,"height":%d'%(W,H),'"width":%d,"height":%d'%(SW,SH)))
json.dump({k:v[3] for k,v in files.items()}, open(f'{SP}/grader_boards.json','w'), ensure_ascii=False)
print('ok', {l[0]:l[6] for l in LEVELS})
