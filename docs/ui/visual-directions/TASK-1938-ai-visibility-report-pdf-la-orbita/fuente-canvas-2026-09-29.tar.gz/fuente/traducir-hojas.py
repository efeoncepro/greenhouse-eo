import re, json
FILES=['GraderPortadaProspecto','GraderPortadaCliente','GraderQueHacer','GraderPorQue','GraderDonde','GraderMercado','GraderContraProspecto','GraderContraCliente']
# (es, en, pt-BR) — texto exacto de cada nodo
T=[
("Mayo 2026","May 2026","Maio de 2026"),
("Marca de ejemplo","Sample Brand","Marca de exemplo"),
("Cifras ilustrativas · datos al 19 de mayo de 2026","Illustrative figures · data as of May 19, 2026","Números ilustrativos · dados de 19 de maio de 2026"),
("de 100","out of 100","de 100"),
("Atención","Needs work","Atenção"),
("Primera medición: tu punto de partida","First measurement: your baseline","Primeira medição: seu ponto de partida"),
("0–39 Crítico","0–39 Critical","0–39 Crítico"),
("40–69 Atención","40–69 Needs work","40–69 Atenção"),
("70–100 Óptimo","70–100 Optimal","70–100 Ótimo"),
("Veredicto","Verdict","Veredito"),
("Te encuentran,","They find you,","Encontram você,"),
("pero casi no te citan.","but rarely cite you.","mas quase não citam você."),
("Resultado del AEO Assessment · 5 motores · 24 preguntas","AEO Assessment result · 5 engines · 24 questions","Resultado do AEO Assessment · 5 motores · 24 perguntas"),
("Logo del cliente","Client logo","Logo do cliente"),
("Preparado para","Prepared for","Preparado para"),
("▲ 5 puntos desde el 4 de mayo","▲ 5 points since May 4","▲ 5 pontos desde 4 de maio"),
("Qué hacer","What to do","O que fazer"),
("Lo que más pesa hoy","What matters most today","O que mais pesa hoje"),
("Brecha principal · Calidad de las citas 32/100","Main gap · Citation quality 32/100","Principal lacuna · Qualidade das citações 32/100"),
("Crítico","Critical","Crítico"),
("Te mencionan, pero no te citan.","They mention you, but don't cite you.","Mencionam você, mas não citam."),
("Solo","Only","Só"),
("32 de cada 100","32 out of 100","32 de cada 100"),
("respuestas con cita apuntan a tu sitio, y la fuente más citada sobre tu categoría es un tercero (g2.com, 18 de 45 citas).","answers with a citation point to your site, and the most cited source on your category is a third party (g2.com, 18 of 45 citations).","respostas com citação apontam para o seu site, e a fonte mais citada sobre a sua categoria é de terceiros (g2.com, 18 de 45 citações)."),
("Plan prioritario","Priority plan","Plano prioritário"),
("Tres movimientos, ordenados por lo que más mueve tu puntaje.","Three moves, ranked by how much they move your score.","Três movimentos, ordenados pelo quanto movem a sua pontuação."),
("Gánate citas creíbles","Earn credible citations","Conquiste citações confiáveis"),
("Consigue menciones externas confiables con PR digital y actualiza la frescura de tus fuentes propias.","Earn trustworthy third-party mentions through digital PR and keep your own sources fresh.","Conquiste menções externas confiáveis com PR digital e mantenha suas fontes próprias atualizadas."),
("Mueve","Moves","Move"),
("Calidad de las citas","Citation quality","Qualidade das citações"),
("· hoy 32/100 · peso 15 % del puntaje","· today 32/100 · 15% of the score","· hoje 32/100 · peso de 15% na pontuação"),
("Apropia tu categoría","Own your category","Domine sua categoria"),
("Publica un explainer de categoría, una página comparativa y perfiles en directorios de terceros.","Publish a category explainer, a comparison page and profiles on third-party directories.","Publique um explainer da categoria, uma página comparativa e perfis em diretórios de terceiros."),
("Dominio de la categoría","Category ownership","Domínio da categoria"),
("· hoy 54/100 · peso 15 % del puntaje","· today 54/100 · 15% of the score","· hoje 54/100 · peso de 15% na pontuação"),
("Cubre la intención de compra","Cover purchase intent","Cubra a intenção de compra"),
("Agrega contenido de precios, implementación y casos de uso con pruebas.","Add pricing, implementation and use-case content, with proof.","Adicione conteúdo de preços, implementação e casos de uso, com provas."),
("Intención de compra","Purchase intent","Intenção de compra"),
("· hoy 45/100 · peso 5 % del puntaje","· today 45/100 · 5% of the score","· hoje 45/100 · peso de 5% na pontuação"),
("Marca de ejemplo · Mayo 2026","Sample Brand · May 2026","Marca de exemplo · Maio de 2026"),
("Capítulo 1 de 4","Chapter 1 of 4","Capítulo 1 de 4"),("Capítulo 2 de 4","Chapter 2 of 4","Capítulo 2 de 4"),("Capítulo 3 de 4","Chapter 3 of 4","Capítulo 3 de 4"),("Capítulo 4 de 4","Chapter 4 of 4","Capítulo 4 de 4"),
("Por qué ocurre","Why it happens","Por que acontece"),
("Siete dimensiones, con su peso","Seven dimensions, weighted","Sete dimensões, com seu peso"),
("Cada dimensión aporta al puntaje según su peso; la gravedad sale de la misma escala de la portada.","Each dimension adds to the score by its weight; severity uses the same scale as the cover.","Cada dimensão soma à pontuação conforme seu peso; a gravidade usa a mesma escala da capa."),
("Visibilidad en IA","AI visibility","Visibilidade em IA"),
("Óptimo","Optimal","Ótimo"),
("Claridad de identidad","Identity clarity","Clareza de identidade"),
("Participación de voz","Share of voice","Participação de voz"),
("Alineación del mensaje","Message alignment","Alinhamento da mensagem"),
("Sin dato","No data","Sem dado"),
("Calidad de la presencia","Presence quality","Qualidade da presença"),
("No basta con aparecer: importa si te citan, cómo te describen y en qué lugar.","Showing up is not enough: what matters is whether they cite you, how they describe you and where.","Não basta aparecer: importa se citam você, como descrevem você e em que lugar."),
("Share de citas","Citation share","Share de citações"),
("de las respuestas con cita apuntan a tu sitio","of answers with a citation point to your site","das respostas com citação apontam para o seu site"),
("Sentimiento","Sentiment","Sentimento"),
("Neutral","Neutral","Neutro"),
("Positivo 38 % · neutral 45 % · negativo 17 %","Positive 38% · neutral 45% · negative 17%","Positivo 38% · neutro 45% · negativo 17%"),
("Prominencia","Prominence","Proeminência"),
("Tu mejor posición en la respuesta; promedio #3","Your best position in the answer; average #3","Sua melhor posição na resposta; média #3"),
("Dónde estás","Where you stand","Onde você está"),
("Niveles para existir en un internet de agentes","Levels to exist on an agentic web","Níveis para existir em uma internet de agentes"),
("Percepción","Perception","Percepção"),
("· ¿te mencionan? (niveles 01, 02, 03 y 05)","· do they mention you? (levels 01, 02, 03 and 05)","· mencionam você? (níveis 01, 02, 03 e 05)"),
("Operabilidad","Operability","Operabilidade"),
("· ¿te pueden usar? (04)","· can they use you? (04)","· podem usar você? (04)"),
("Nivel 01 · Percepción","Level 01 · Perception","Nível 01 · Percepção"),("Nivel 02 · Percepción","Level 02 · Perception","Nível 02 · Percepção"),("Nivel 03 · Percepción","Level 03 · Perception","Nível 03 · Percepção"),("Nivel 04 · Operabilidad","Level 04 · Operability","Nível 04 · Operabilidade"),("Nivel 05 · Percepción","Level 05 · Perception","Nível 05 · Percepção"),
("Que te encuentre","Be Found","Ser encontrado"),("· Be Found","","· Be Found"),
("¿Existes para la IA?","Do you exist for AI?","Você existe para a IA?"),
("Que te entienda","Be Readable","Ser entendido"),("· Be Readable","","· Be Readable"),
("¿Te puede leer sin adivinar?","Can it read you without guessing?","Ela consegue ler você sem adivinhar?"),
("Que te represente bien","Be Correct","Ser bem representado"),("· Be Correct","","· Be Correct"),
("¿Lo que dice de ti es verdad?","Is what it says about you true?","O que ela diz sobre você é verdade?"),
("Que pueda actuar","Be Actionable","Ser acionável"),("· Be Actionable","","· Be Actionable"),
("¿Te pueden usar, no solo citar?","Can they use you, not just cite you?","Podem usar você, não só citar?"),
("En cobertura","Not measured yet","Ainda não medido"),
("Que te prefiera","Be Intrinsic","Ser o preferido"),("· Be Intrinsic","","· Be Intrinsic"),
("¿Eres el default?","Are you the default?","Você é o padrão?"),
("Motor por motor","Engine by engine","Motor por motor"),
("Dónde más se pierde presencia: Google AI Overview (46 %) y Perplexity (58 %).","Where presence drops most: Google AI Overview (46%) and Perplexity (58%).","Onde mais se perde presença: Google AI Overview (46%) e Perplexity (58%)."),
("19 de 24","19 of 24","19 de 24"),("18 de 24","18 of 24","18 de 24"),("17 de 24","17 of 24","17 de 24"),("14 de 24","14 of 24","14 de 24"),("11 de 24","11 of 24","11 de 24"),
("Mercado y fuentes","Market and sources","Mercado e fontes"),
("Qué parte de las menciones ocupas frente a otras marcas (144 menciones en total).","Your share of mentions against other brands (144 mentions in total).","Quanto das menções você ocupa frente a outras marcas (144 menções no total)."),
("Competidor A","Competitor A","Concorrente A"),("Competidor B","Competitor B","Concorrente B"),("Competidor C","Competitor C","Concorrente C"),
("48 menciones","48 mentions","48 menções"),("41 menciones","41 mentions","41 menções"),("32 menciones","32 mentions","32 menções"),("23 menciones","23 mentions","23 menções"),
("Tu marca","Your brand","Sua marca"),
("Fuentes que sostienen la respuesta","Sources behind the answer","Fontes que sustentam a resposta"),
("Los dominios que los motores citan al hablar de tu categoría (45 citas).","The domains the engines cite when they talk about your category (45 citations).","Os domínios que os motores citam ao falar da sua categoria (45 citações)."),
("Terceros","Third party","Terceiros"),("Comunidad","Community","Comunidade"),
("[tu dominio]","[your domain]","[seu domínio]"),("Tu sitio","Your site","Seu site"),
("competidor-a.com","competitor-a.com","concorrente-a.com"),("Competidor","Competitor","Concorrente"),
("Procedencia y metodología","Provenance and methodology","Procedência e metodologia"),
("Datos al","Data as of","Dados de"),("19 may 2026","May 19, 2026","19 mai. 2026"),
("Preguntas","Questions","Perguntas"),("Versión del puntaje","Score version","Versão da pontuação"),("[versión]","[version]","[versão]"),
("Paquete de preguntas","Question pack","Pacote de perguntas"),
("[Aviso de alcance del informe: el texto vigente del informe actual]","[Report scope notice: the current text of the live report]","[Aviso de escopo do relatório: o texto vigente do relatório atual]"),
("¿Conversamos?","Shall we talk?","Vamos conversar?"),
("Cuando quieras","Whenever you like","Quando quiser"),
("Te mostramos","We'll show you","Mostramos"),
("qué mover primero","what to move first","o que mover primeiro"),
("para subir tu puntaje, y cómo medirlo mes a mes.","to raise your score, and how to measure it month by month.","para aumentar sua pontuação, e como medi-la mês a mês."),
("Agenda una reunión  →","Book a meeting  →","Agende uma reunião  →"),
("Elige el horario en efeoncepro.com/contacto","Pick a time at efeoncepro.com/contacto","Escolha o horário em efeoncepro.com/contacto"),
("¿Lo revisamos juntos?","Shall we review it together?","Vamos revisar juntos?"),
("Tu equipo en Efeonce trae la lectura y el","Your Efeonce team brings the reading and the","Sua equipe na Efeonce leva a leitura e o"),
("plan de los tres movimientos","plan for the three moves","plano dos três movimentos"),
("a la próxima reunión.","to the next meeting.","para a próxima reunião."),
("Responsable de tu cuenta","Your account lead","Responsável pela sua conta"),
("Próximo informe","Next report","Próximo relatório"),("[fecha]","[date]","[data]"),
("Medimos lo mismo, mes a mes","Same measurement, month after month","Medimos o mesmo, mês a mês"),
]
TITLES={'portada':('cover','capa'),'contraportada':('back cover','contracapa'),'no cliente':('prospect','não cliente'),'cliente':('client','cliente'),'qué hacer':('what to do','o que fazer'),'por qué':('why','por que'),'dónde':('where','onde'),'mercado y fuentes':('market and sources','mercado e fontes')}
T.sort(key=lambda r: -len(r[0]))
def translate(src, li):
    s=src
    for row in T:
        es,tr=row[0],row[li]
        esc=es.replace('&','&amp;') if False else es
        s=re.sub(r'>(\s*)'+re.escape(esc)+r'(\s*)<', lambda m: '>'+m.group(1)+tr+m.group(2)+'<', s)
        s=s.replace(f'aria-label="{es}"',f'aria-label="{tr}"').replace(f'alt="{es}"',f'alt="{tr}"')
    # porcentaje sin espacio (en y pt-BR), sólo en texto
    s=re.sub(r'>([^<]*)<', lambda m: '>'+re.sub(r'(\d) %',r'\1%',m.group(1))+'<', s)
    s=s.replace('<html lang="es">', '<html lang="en">' if li==1 else '<html lang="pt-BR">')
    def title(m):
        t=m.group(1)
        for k,v in sorted(TITLES.items(), key=lambda kv:-len(kv[0])): t=t.replace(k, v[li-1])
        return '<title>'+t+'</title>'
    return re.sub(r'<title>(.*?)</title>', title, s)
import sys
root=sys.argv[1]
for f in FILES:
    src=open(f'{root}/{f}.dc.html').read()
    for li,suf in ((1,'EN'),(2,'PT')):
        open(f'{root}/{f}{suf}.dc.html','w').write(translate(src,li))
print('ok')
