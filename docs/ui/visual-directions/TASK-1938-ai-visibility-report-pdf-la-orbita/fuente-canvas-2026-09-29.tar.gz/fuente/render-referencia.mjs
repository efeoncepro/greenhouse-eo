import { chromium } from '/Users/jreye/Documents/greenhouse-eo/node_modules/playwright/index.mjs'
import fs from 'node:fs'
const P = process.env.PROJ, OUT = process.env.OUT
const assets = { '/_blob/b15a1c91f709a09e74d5187c50172973': 'efeonce-logo-negative-inline.svg', '/_blob/497ee58a78f487f09c0a815fb204d79f': 'url-bubble-baked-dark.svg', '/_blob/6db72d83ae990514993b11bc40021389': null,
  '/_blob/fe3e3ea8078c559ae798a7977e74e1b9': 'provider-chatgpt.svg', '/_blob/41fc5051564fb300d477953b4fbcdad6': 'provider-claude.svg', '/_blob/ce13c2ac704d6b1aa25be898b2714316': 'provider-gemini.svg', '/_blob/5c26fa8747eee348543ecdbd33153c39': 'provider-perplexity.svg', '/_blob/9167c07707a965fbfc365a2195ea703a': 'provider-google-ai-mode.svg', '/_blob/bc65c054fe8640fe32e2b21a484742e7': 'ai-visibility-report-lockup-negative.svg', '/_blob/bd0ac74ee422007885e2d3998f80989e': 'aeo-lockup-negative.svg', '/_blob/825f4fb837b9193b266b013a3babe24d': 'ai-visibility-report-lockup-positive.svg', '/_blob/7a9e2b86b0b77bf6eec6f97ef64fb713': 'url-bubble-baked-light.svg' }
const files = process.argv.slice(2)
const browser = await chromium.launch()
for (const f of files) {
  let src = fs.readFileSync(`${P}/project/${f}`, 'utf8')
  let body = src.slice(src.indexOf('<x-dc>') + 6, src.indexOf('</x-dc>'))
  body = body.replace(/<\/?helmet>/g, '').replace(/<\/?sc-if[^>]*>/g, '')
  for (const [k, v] of Object.entries(assets)) if (v) body = body.split(k).join('file://' + P + '/assets/' + v)
  const html = `<!doctype html><html lang="es"><head><meta charset="utf-8"></head><body style="margin:0">${body}</body></html>`
  const tmp = `${OUT}/${f}.html`; fs.writeFileSync(tmp, html)
  const page = await browser.newPage({ viewport: { width: +(process.env.VW||794), height: +(process.env.VH||1123) }, deviceScaleFactor: +(process.env.DSF||1.5) })
  await page.goto('file://' + tmp); await page.waitForTimeout(1500)
  const over = await page.evaluate(() => { const r = document.body.firstElementChild; const o=[]; r.querySelectorAll('*').forEach(e=>{const b=e.getBoundingClientRect(); const rb=r.getBoundingClientRect(); if(b.right>rb.right+1||b.bottom>rb.bottom+1) o.push(e.tagName+':'+(e.textContent||'').trim().slice(0,30)+':'+Math.round(b.right)+','+Math.round(b.bottom))}); return o.slice(0,10) })
  console.log(f, 'overflow', JSON.stringify(over))
  await page.screenshot({ path: `${OUT}/${f.replace('.dc.html','')}.png` })
  await page.close()
}
await browser.close()
