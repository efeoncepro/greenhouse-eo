// Renderiza las páginas del canvas aprobado (TASK-1889) a PNG en su tamaño nativo.
// Uso, desde la raíz del repo, tras extraer el paquete en un directorio temporal:
//   node <dir>/render-referencia.mjs <dir>/fuente <salida>
import { createRequire } from 'node:module'
import { readFileSync, writeFileSync, mkdirSync, readdirSync } from 'node:fs'
import { join, resolve } from 'node:path'
const repo = process.cwd()
const require = createRequire(join(repo, 'package.json'))
const { chromium } = require('playwright')
const [src, out] = process.argv.slice(2).map(p => resolve(p))
mkdirSync(out, { recursive: true })
// Los /_blob/<id> del canvas son estos archivos del repo.
const blobs = {
  eb591669a86f7638b9fc48b055bac9af: 'public/branding/logo-full.svg',
  '45197b37668b746a41d2c939945a3179': 'public/branding/logo-negative.svg',
  '51098f8db0c7b4bd3382902bc43b5230': 'src/lib/artifact-composer/catalogs/insights-report/assets/url-lum.svg',
  af608ea1a56f36c3edd01bd8ada5b360: 'public/images/greenhouse/SVG/icon-google.svg',
  '08e0a96b40424f5a5502c3444468000b': 'public/images/logos/axis/gpt-isotype.svg',
  '9d17005df37fd474dabd1ce6f07269b8': 'public/images/logos/axis/gemini-isotype.svg',
  b1ada32f7ed104769485989494763af7: 'public/images/logos/axis/perplexity-icon.svg',
  e5570101739bb71fa2efd88b0fa7f700: 'public/images/logos/axis/claude-isologo.svg'
}
const browser = await chromium.launch()
for (const f of readdirSync(src).filter(n => n.endsWith('.dc.html')).sort()) {
  const s = readFileSync(join(src, f), 'utf8')
  const helmet = s.match(/<helmet>([\s\S]*?)<\/helmet>/)[1]
  const body = s.match(/<\/helmet>([\s\S]*?)<\/x-dc>/)[1]
  const { width, height } = JSON.parse(s.match(/data-props='([^']*)'/)[1]).$preview
  let html = `<!doctype html><html><head><meta charset="utf-8">${helmet}</head><body style="margin:0">${body}</body></html>`
  html = html.replaceAll('{{filtro}}', 'none')
  for (const [id, file] of Object.entries(blobs)) html = html.replaceAll(`/_blob/${id}`, `file://${join(repo, file)}`)
  const tmp = join(out, '_tmp.html')
  writeFileSync(tmp, html)
  const page = await browser.newPage({ viewport: { width, height }, deviceScaleFactor: 1 })
  await page.goto(`file://${tmp}`)
  await page.evaluate(() => document.fonts.ready)
  await page.waitForTimeout(700)
  await page.screenshot({ path: join(out, f.replace('.dc.html', '.png')) })
  await page.close()
  console.log(f, `${width}x${height}`)
}
await browser.close()
