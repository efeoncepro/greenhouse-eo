// Renders the Glitch variant boards with the production dc runtime, serves blobs, shoots full pages, reports height.
const fs = require('node:fs'), http = require('node:http'), path = require('node:path')
const REPO = '/Users/jreye/Documents/greenhouse-eo'
const { chromium } = require(REPO + '/node_modules/playwright')
const { renderBoard } = require(REPO + '/scripts/public-website/blog-v3/lib/render-node.cjs')
const PROJ = process.argv[2], OUT = process.argv[3]
const assets = JSON.parse(fs.readFileSync(REPO + '/scripts/public-website/blog-archive/source/assets.json', 'utf8'))
const blobs = Object.fromEntries(Object.values(assets).map(a => [a.id, REPO + '/scripts/public-website/blog-archive/source/assets/' + a.file]))
blobs['3b6e8663a0a14cda3ae78bca5e9226e7'] = REPO + '/src/lib/artifact-composer/catalogs/glitch/assets/flash-trail.svg'
blobs['37b72c0a4e1e0035ebc657f51be0d02a'] = REPO + '/src/lib/artifact-composer/catalogs/glitch/fonts/guttery-400.ttf'
const T = { svg: 'image/svg+xml', webp: 'image/webp', png: 'image/png', jpg: 'image/jpeg', ttf: 'font/ttf' }
const pages = {}
for (const w of ['1440', '390']) {
  const r = renderBoard(path.join(PROJ, `Archivo-D-tema-glitch-${w}.dc.html`), {})
  const fonts = r.fontLinks.filter(h => h.includes('/css2')).map(h => `<link rel="stylesheet" href="${h}">`).join('')
  pages[w] = `<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">${fonts}<style>${r.css}</style></head><body style="margin:0">${r.html}</body></html>`
}
const srv = http.createServer((q, s) => {
  const b = q.url.match(/^\/_blob\/([0-9a-f]{32})/)
  if (b && blobs[b[1]]) { s.writeHead(200, { 'content-type': T[blobs[b[1]].split('.').pop()] }); return fs.createReadStream(blobs[b[1]]).pipe(s) }
  const p = pages[q.url.replace(/\//g, '')]; if (p) { s.writeHead(200, { 'content-type': 'text/html; charset=utf-8' }); return s.end(p) }
  s.writeHead(404).end()
})
srv.listen(0, '127.0.0.1', async () => {
  const port = srv.address().port, br = await chromium.launch()
  for (const w of ['1440', '390']) {
    const ctx = await br.newContext({ viewport: { width: +w, height: 900 } }), pg = await ctx.newPage()
    await pg.goto(`http://127.0.0.1:${port}/${w}`, { waitUntil: 'networkidle' }); await pg.evaluate(() => document.fonts.ready)
    const m = await pg.evaluate(() => ({ h: document.querySelector('.v3.arc').getBoundingClientRect().height, sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth, guttery: document.fonts.check('40px Guttery'), h1: document.querySelectorAll('h1').length }))
    console.log(w, JSON.stringify(m))
    await pg.screenshot({ path: `${OUT}/glitch-${w}.png`, fullPage: true })
    await pg.screenshot({ path: `${OUT}/glitch-${w}-top.png`, clip: { x: 0, y: 0, width: +w, height: w === '1440' ? 1500 : 2000 } })
    await ctx.close()
  }
  await br.close(); srv.close()
})
