#!/usr/bin/env python3
"""Variante Glitch del tema (TASK-2055 follow-up), en el canvas «Portada Blog Efeonce», página archivo-d.

Misma estructura que la dirección D aprobada (cabecera, destacada montada, filas por año, otros temas) con la piel de
Glitch según GLITCH_GRAPHIC_LINE_V1, sólo en /category/glitch/ (= /glitch/). Seis puntos propuestos al operador el
2026-10-24:
  1. el título es el wordmark oficial (su manzana es la única esfera de la página);
  2. las cifras son la cabecera de Glitch: «EDICIÓN #17» y «NO ESPERA AL LUNES / estela + FLASH»;
  3. la muletilla «sin anestesia.» en Guttery, verde, rotada −4°;
  4. la falla en bytes en el borde inferior del bloque oscuro (uso nuevo de la falla: requiere visto bueno);
  5. cada fila dice qué es: edición «#N» o Flash (bloque navy, porque el verde nunca va sobre blanco) o nota;
  6. el banner de suscripción de Glitch después de la lista.
Datos reales de efeoncepro.com/category/glitch/ al 2026-10-24. Reutiliza gen_d.py (CSS, filas, mobile).
"""
import json
import os
import random
import re

import gen_d as D

e = D.e
WORDMARK_NEG = '/_blob/72025ed97a7ce0c610ec355f78efed74'   # Glitch negativo (wordmark blanco + manzana verde)
WORDMARK_POS = '/_blob/1063184040c6121be1f86602803b0f55'   # Glitch positivo (navy + manzana verde)
TRAIL = '/_blob/3b6e8663a0a14cda3ae78bca5e9226e7'          # estela de bytes del Flash (token, acento)
GUTTERY = '/_blob/37b72c0a4e1e0035ebc657f51be0d02a'        # Guttery 400, sólo muletillas de Glitch

ACC = '#6ec207'
NAVY = '#001a33'

GLITCH_CSS = rf"""
/* ── Variante Glitch del tema (GLITCH_GRAPHIC_LINE_V1). Sólo /category/glitch/. ── */
@font-face{{font-family:'Guttery';font-style:normal;font-weight:400;font-display:swap;src:url('{GUTTERY}') format('truetype')}}
.gl .gl-t{{margin:20px 0 0;line-height:0}}
.gl .gl-t img{{display:block;width:430px;max-width:100%;height:auto}}
.gl .gl-d{{margin-top:32px}}
.gl .gl-mul{{display:inline-block;margin-left:.2em;font-family:'Guttery',cursive;font-size:34px;line-height:1;font-weight:400;color:{ACC};transform:rotate(-4deg);transform-origin:left bottom;white-space:nowrap;vertical-align:-.12em}}
.gl .gl-mh{{display:flex;flex-wrap:wrap;gap:20px 0;margin-top:40px;max-width:520px}}
.gl .gl-mh__c{{display:flex;flex-direction:column;gap:10px;padding:20px 28px 20px 0;border-top:1px solid rgba(207,228,250,.18);border-bottom:1px solid rgba(207,228,250,.18)}}
.gl .gl-mh__c + .gl-mh__c{{padding-left:28px;border-left:1px solid rgba(207,228,250,.18);flex:1}}
.gl .gl-mh__l{{font-size:12px;font-weight:600;letter-spacing:.22em;text-transform:uppercase;color:#ffffff}}
.gl .gl-mh__n{{display:flex;align-items:center;gap:10px;font-family:'Bricolage Grotesque',sans-serif;font-size:52px;line-height:.86;letter-spacing:-.02em;white-space:nowrap}}
.gl .gl-hash{{font-weight:300;color:#ffffff;margin-right:-.06em}}
.gl .gl-mh__n--e{{gap:0}}
.gl .gl-num{{font-weight:800;font-stretch:78%;font-variation-settings:'wdth' 78;color:{ACC}}}
.gl .gl-trail{{display:block;width:74px;height:auto;flex:none}}
.gl .gl-mh__s{{font-size:13px;font-weight:500;color:#cfe4fa}}
.gl .ah--f{{z-index:auto}}
.gl .gl-bytes{{position:absolute;left:0;right:0;bottom:-60px;z-index:2;display:block;width:100%;height:60px;pointer-events:none}}
.gl .fb{{z-index:1}}
.gl .fb--f{{padding-top:100px}}
.gl .rw__d{{display:flex;flex-direction:column;align-items:flex-start;gap:8px}}
.gl .gl-b{{display:inline-flex;align-items:center;gap:1px;height:34px;padding:0 12px;border-radius:8px;background:{NAVY};font-family:'Bricolage Grotesque',sans-serif;font-size:24px;line-height:1;white-space:nowrap}}
.gl .gl-b .gl-hash{{font-size:24px}}
.gl .gl-b--f{{gap:8px;padding:0 12px 0 10px}}
.gl .gl-b--f img{{display:block;width:34px;height:auto}}
.gl .gl-b--f .gl-num{{font-size:20px;letter-spacing:.01em}}
.gl .rw__dt{{font-size:14px;color:#6d6777}}
.gl-sub{{background:#ffffff;padding:0 0 128px}}
.gl-sub__c{{position:relative;display:grid;grid-template-columns:minmax(0,7fr) minmax(0,5fr);gap:40px 64px;align-items:center;padding:56px 64px 56px 72px;border-radius:40px;overflow:hidden;background:{NAVY};color:#ffffff}}
.gl-sub__t{{margin:20px 0 0;font-family:'Bricolage Grotesque',sans-serif;font-size:46px;line-height:.98;letter-spacing:-.02em}}
.gl-sub__t .in{{display:block;font-weight:300;font-size:.72em;letter-spacing:.01em}}
.gl-sub__t .out{{display:block;font-weight:800;font-stretch:78%;font-variation-settings:'wdth' 78;color:{ACC}}}
.gl-sub__d{{margin:20px 0 0;max-width:520px;font-size:17px;line-height:1.55;color:#cfe4fa}}
.gl-sub__r{{position:relative;z-index:1;display:flex;flex-direction:column;align-items:flex-start;gap:20px}}
.gl-sub__r .gl-mul{{margin:0 0 4px 4px;font-size:30px}}
.gl-pill{{display:inline-flex;align-items:center;gap:12px;height:60px;padding:0 24px 0 28px;border-radius:999px;background:#ffffff;color:{NAVY};font-size:17px;font-weight:600;text-decoration:none;box-shadow:0 18px 40px rgba(0,0,0,.25);transition:transform 300ms cubic-bezier(0.2,0,0,1)}}
.gl-pill img{{display:block;height:21px;width:auto}}
.gl-pill:focus-visible{{outline:2px solid #36c8bf;outline-offset:4px}}
@media (hover:hover){{.gl-pill:hover{{transform:translateY(-3px)}}.gl-pill:hover .ax{{transform:translateX(3px)}}}}
@media (prefers-reduced-motion:reduce){{.gl-pill{{transition:none}}.gl-pill:hover{{transform:none}}}}
.gl-sub__n{{margin:0;font-size:14px;color:#9fb3c8}}
.gl-sub__bytes{{position:absolute;right:0;top:0;width:280px;height:auto;opacity:.9;pointer-events:none}}
"""

GLITCH_MOB = [
    ('.gl .gl-t img', 'width:230px'),
    ('.gl .gl-d', 'margin-top:24px'),
    ('.gl .gl-mul', 'font-size:28px'),
    ('.gl .gl-mh', 'margin-top:28px;max-width:none;flex-wrap:nowrap'),
    ('.gl .gl-mh__c', 'flex:1;padding:16px 12px 16px 0;gap:8px;min-width:0'),
    ('.gl .gl-mh__c + .gl-mh__c', 'padding-left:14px'),
    ('.gl .gl-mh__l', 'font-size:10px;letter-spacing:.18em;white-space:nowrap'),
    ('.gl .gl-mh__n', 'font-size:38px;gap:6px'),
    ('.gl .gl-trail', 'width:50px'),
    ('.gl .gl-mh__s', 'font-size:12px'),
    ('.gl .gl-bytes', 'bottom:-44px;height:44px'),
    ('.gl .fb--f', 'padding-top:68px'),
    ('.gl .rw__d', 'flex-direction:row;align-items:center;gap:10px'),
    ('.gl .gl-b', 'height:28px;padding:0 9px;font-size:19px;border-radius:7px'),
    ('.gl .gl-b .gl-hash', 'font-size:19px'),
    ('.gl .gl-b--f img', 'width:26px'),
    ('.gl .gl-b--f .gl-num', 'font-size:16px'),
    ('.gl .rw__dt', 'font-size:12px'),
    ('.gl-sub', 'padding:0 0 64px'),
    ('.gl-sub__c', 'grid-template-columns:minmax(0,1fr);gap:32px;padding:44px 24px 40px;border-radius:26px'),
    ('.gl-sub__t', 'font-size:34px'),
    ('.gl-sub__d', 'margin-top:16px;font-size:15px'),
    ('.gl-sub__r .gl-mul', 'font-size:30px'),
    ('.gl-pill', 'height:54px;padding:0 20px 0 22px;font-size:16px;gap:10px'),
    ('.gl-pill img', 'height:19px'),
    ('.gl-sub__n', 'font-size:12px'),
    ('.gl-sub__bytes', 'width:180px'),
]


def glitch_mob_css():
    plain = '\n'.join(f'{s}{{{d}}}' for s, d in GLITCH_MOB)
    scoped = '\n'.join(','.join(f'.mob{x.strip()[3:]}' if x.strip().startswith('.gl ') else f'.mob {x.strip()}'
                                for x in s.split(',')) + f'{{{d}}}' for s, d in GLITCH_MOB)
    return f'@media (max-width:767px){{\n{plain}\n}}\n{scoped}\n'


# ───────────────────────── la falla en bytes del borde (determinista) ─────────────────────────
def edge_bytes(width=1440, height=60, cell=8, step=12, seed=1755):
    """Celdas navy cuadradas que caen del borde del bloque oscuro: densidad y opacidad bajan hacia abajo."""
    rnd = random.Random(seed)
    rows, cols = height // step, width // step
    rects = []
    for r in range(rows):
        t = 1 - r / rows                        # 1 arriba (pegado al borde), → 0 abajo
        density = 0.04 + 0.66 * t ** 2.4
        for c in range(cols):
            if rnd.random() < density:
                op = round(0.25 + 0.75 * t ** 1.3, 2)
                rects.append(f'<rect x="{c * step + 2}" y="{r * step}" width="{cell}" height="{cell}" fill-opacity="{op}"/>')
    return (f'<svg class="gl-bytes" viewBox="0 0 {width} {height}" preserveAspectRatio="xMidYMin slice" aria-hidden="true" '
            f'focusable="false"><g fill="{NAVY}">{"".join(rects)}</g></svg>')


def corner_bytes(seed=17):
    """Textura de bytes en la esquina del banner: celdas en el acento sobre navy (nunca sobre blanco)."""
    rnd = random.Random(seed)
    cols, rows, step, cell = 20, 12, 17, 12
    rects = []
    for r in range(rows):
        for c in range(cols):
            # densidad que crece hacia la esquina superior derecha
            t = ((c / (cols - 1)) * 0.6 + (1 - r / (rows - 1)) * 0.4)
            if rnd.random() < 0.04 + 0.7 * t ** 2.4:
                op = round(0.12 + 0.6 * t ** 1.6, 2)
                rects.append(f'<rect x="{c * step}" y="{r * step}" width="{cell}" height="{cell}" fill-opacity="{op}"/>')
    w, h = cols * step - (step - cell), rows * step - (step - cell)
    return (f'<svg class="gl-sub__bytes" viewBox="0 0 {w} {h}" aria-hidden="true" focusable="false">'
            f'<g fill="{ACC}">{"".join(rects)}</g></svg>')


# ───────────────────────── datos reales (efeoncepro.com/category/glitch/, 2026-10-24) ─────────────────────────
def G(date, kind, mins, title, num=None):
    return {'date': date, 'kind': kind, 'min': mins, 'title': title, 'num': num}


HERO = D.P('28 sep 2026', 'Glitch', 'Flash', 8, 'Glitch Flash: Sonnet 5.5 roza a Opus, a mitad de precio',
           '08933b6eae580530405a3ebace493378', True)

ROWS = [
    G('28 jul', 'Edición', 10, 'Glitch #17: Agente rompe la jaula, la confianza reordena el frontier, la correa manda'),
    G('21 jul', 'Edición', 9, 'Glitch #16: Open-weight que descargas, precio que miente, canal sin dueño'),
    G('14 jul', 'Edición', 10, 'Glitch #15: Token barato, criterio caro, y las capas que no controlas.'),
    G('10 jul', 'Nota', 6, 'GPT-5.6 y ChatGPT Work: OpenAI ya no está lanzando modelos, está cambiando la forma de trabajar con IA'),
    G('9 jul', 'Nota', 8, 'Platform Properties para Search Console: Google admite que la búsqueda ya no ocurre en un solo lugar'),
    G('7 jul', 'Edición', 9, 'GLITCH #14: El modelo a centavos, el checkout en vivo, el acceso con dueño.'),
    G('30 jun', 'Edición', 11, 'Glitch #13: agentes, checkout y el criterio del marketing'),
    G('24 jun', 'Edición', 8, 'Glitch #12: la AI dejó de adoptarse, ahora opera tu marketing'),
    G('2 mar', 'Edición', 5, 'GLITCH #02: Tu semana en AI, marketing y tecnología — sin anestesia'),
]


def split_edition(title):
    """«Glitch #17: Algo» → (17, «Algo»). El número sale del título publicado; la fila lo muestra en la placa."""
    m = re.match(r'^\s*glitch\s*#\s*0*(\d+)\s*:\s*(.+)$', title, flags=re.I)
    if not m:
        return None, title
    rest = m.group(2).strip()
    return re.search(r'#\s*(\d+)', title).group(1), rest[:1].upper() + rest[1:]


def badge(p):
    if p['kind'] == 'Edición' and p['num'] is not None:
        return (f'<span class="gl-b" aria-label="Edición {p["num"]}"><span class="gl-hash">#</span>'
                f'<span class="gl-num">{p["num"]}</span></span>')
    if p['kind'] == 'Flash':
        return f'<span class="gl-b gl-b--f"><img src="{TRAIL}" alt=""><span class="gl-num">FLASH</span></span>'
    return ''


def g_row(p):
    return f'''<a href="#" class="lnk arch-row arch-row--x">
            <span class="rw__d">{badge(p)}<span class="rw__dt">{e(p['date'])}</span></span>
            <span class="idea u rw__t">{e(p['title'])}</span>
            <span class="arch-k rw__k"><span>{e(p['kind'])} <span class="rw__m">· {p['min']} min</span></span>{D.ICON['arrow']}</span>
          </a>'''


def v_glitch():
    rows = []
    for p in ROWS:
        num, title = split_edition(p['title']) if p['kind'] == 'Edición' else (None, p['title'])
        rows.append(g_row({**p, 'num': num, 'title': title}))
    rows_html = '\n          '.join(rows)
    head = f'''<header class="ah ah--f" data-site-nav-tone="dark">
  <div class="w">
    {D.crumbs(['Inicio', 'Blog', 'Temas', 'Glitch'])}
    <div class="ah__g ah__g--f">
      <div>
        <p class="eyb eyb--d"><span class="eyb__bar" style="background: {ACC};"></span>El newsletter de Efeonce</p>
        <h1 class="gl-t"><img src="{WORDMARK_NEG}" alt="Glitch" width="430" height="117"></h1>
        <p class="ah__d gl-d">El resumen semanal de Efeonce sobre IA, marketing y tecnología: lo que cambió, por qué importa y qué hacer con eso, <span class="gl-mul">sin anestesia.</span></p>
        <div class="gl-mh">
          <div class="gl-mh__c">
            <span class="gl-mh__l">Edición</span>
            <span class="gl-mh__n gl-mh__n--e" aria-label="Edición 17"><span class="gl-hash">#</span><span class="gl-num">17</span></span>
            <span class="gl-mh__s">la última, 28 jul 2026</span>
          </div>
          <div class="gl-mh__c">
            <span class="gl-mh__l">No espera al lunes</span>
            <span class="gl-mh__n"><img class="gl-trail" src="{TRAIL}" alt=""><span class="gl-num">FLASH</span></span>
            <span class="gl-mh__s">el último, 28 sep 2026</span>
          </div>
        </div>
      </div>
      {D.hero_card('Lo más reciente', HERO)}
    </div>
  </div>
  {edge_bytes()}
</header>'''
    lst = f'''<section class="al" aria-label="Todas las publicaciones de Glitch">
  <div class="w">
    <div class="yg">
      <div class="yg__y"><p class="idea yg__n">2026</p><p class="yg__c">10 publicaciones en Glitch</p></div>
      <div class="rows">
          {rows_html}
      </div>
    </div>
    <div class="pgw"><span class="pgw__n">Mostrando las 10 publicaciones</span></div>
  </div>
</section>'''
    sub = f'''<section class="gl-sub" aria-labelledby="gl-sub-h">
  <div class="w">
    <div class="gl-sub__c">
      {corner_bytes()}
      <div style="position: relative; z-index: 1;">
        <p class="eyb eyb--d"><span class="eyb__bar" style="background: {ACC};"></span>Suscríbete</p>
        <h2 id="gl-sub-h" class="gl-sub__t"><span class="in">Ocho noticias cada lunes,</span><span class="out">con punto de vista.</span></h2>
        <p class="gl-sub__d">Lo que cambió en IA, marketing y tecnología, y qué hacer con eso. Cada lunes en tu correo, gratis.</p>
      </div>
      <div class="gl-sub__r">
        <span class="gl-mul">nos vemos el lunes.</span>
        <a href="#" class="gl-pill live" aria-label="Suscríbete a Glitch">Suscríbete a <img src="{WORDMARK_POS}" alt="">{D.ICON['ax']}</a>
        <p class="gl-sub__n">Al suscribirte aceptas la <a href="#" style="color: inherit;">política de privacidad</a>. Te das de baja cuando quieras.</p>
      </div>
    </div>
  </div>
</section>'''
    return '\n'.join([head, D.filter_bar(10, [('Ediciones', 7), ('Flash', 1), ('Notas', 2)]), lst, sub,
                      D.other_topics('Otros temas del blog.', exclude='Glitch')])


FONTS = ('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wdth,wght@12..96,75..100,200..800'
         '&amp;family=Poppins:ital,wght@0,300;0,400;0,500;0,600;1,400&amp;display=swap')


def page(title, body, mobile, h):
    out = D.page(title, body, mobile, h)
    out = out.replace('class="v3 arc mob"', 'class="v3 arc gl mob"').replace('class="v3 arc"', 'class="v3 arc gl"')
    out = re.sub(r'https://fonts\.googleapis\.com/css2\?family=Bricolage[^"]+', FONTS, out, count=1)
    out = out.replace('</style>\n</helmet>', f'{GLITCH_CSS}\n{glitch_mob_css()}</style>\n</helmet>', 1)
    return out


if __name__ == '__main__':
    import sys
    heights = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {'1440': 4500, '390': 4900}
    body = v_glitch()
    for w in ('1440', '390'):
        name = f'Archivo-D-tema-glitch-{w}.dc.html'
        with open(os.path.join(D.OUT, name), 'w', encoding='utf-8') as f:
            f.write(page(f'Archivo D · Tema · Glitch (variante) · {w}', body, w == '390', heights[w]))
        print(name, os.path.getsize(os.path.join(D.OUT, name)))
