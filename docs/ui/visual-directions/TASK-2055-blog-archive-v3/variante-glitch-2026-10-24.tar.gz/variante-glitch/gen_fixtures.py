#!/usr/bin/env python3
"""TASK-2055 — Writes the canvas D literals as one data document per view (the template's data contract).

The documents are the example content of the approved boards: fed to the bound template they must render the same
HTML as the frozen boards (scripts/public-website/blog-archive/test-bound-equivalence.cjs).
"""
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gen_d as G  # noqa: E402

OUT = sys.argv[1]
B = lambda i: '/_blob/' + i  # noqa: E731
ASSETS = {'glitchNavy': B('1063184040c6121be1f86602803b0f55'), 'glitchNeg': B('72025ed97a7ce0c610ec355f78efed74'),
          'spark': B('2def96f284c302de0cf9fa4736ed9d18')}


def parts(title, term=None):
    if not term:
        return [{'t': title, 'pl': True, 'hl': False}]
    out, last = [], 0
    for m in re.finditer(re.escape(term), title, flags=re.I):
        if m.start() > last:
            out.append({'t': title[last:m.start()], 'pl': True, 'hl': False})
        out.append({'t': m.group(0), 'pl': False, 'hl': True})
        last = m.end()
    if last < len(title):
        out.append({'t': title[last:], 'pl': True, 'hl': False})
    return out


def row(p, show_topic, term=None, full_date=False):
    glitch = p['topic'] == 'Glitch'
    label = p['fmt'] if (glitch or not show_topic) else f"{p['topic']} · {p['fmt']}"
    return {'url': '#', 'date': p['date'] if full_date else p['date'].rsplit(' ', 1)[0], 'parts': parts(p['title'], term),
            'glitch': glitch, 'plain': not glitch, 'label': label, 'min': p['min'], 'pd': True, 'gd': False, 'ed': None, 'fl': False}


def groups(posts, totals, scope, show_topic):
    out = []
    for year in sorted({p['date'][-4:] for p in posts}, reverse=True):
        n = totals[year]
        out.append({'year': year, 'caption': f"{n} {'publicación' if n == 1 else 'publicaciones'} {scope}",
                    'rows': [row(p, show_topic) for p in posts if p['date'][-4:] == year]})
    return out


def hero(label, p, term=None):
    glitch = p['topic'] == 'Glitch'
    return {'url': '#', 'img': B(p['img']), 'imgCls': 'hc__img' if p.get('wide') else 'hc__img hc__img--sq', 'label': label,
            'bar': f"background: {G.TOPIC[p['topic']][1]};", 'glitch': glitch, 'plain': not glitch,
            'kind': p['fmt'] if glitch else f"{p['fmt']} · {p['topic']}", 'parts': parts(p['title'], term),
            'min': p['min'], 'date': p['date']}


def filt(total, items):
    all_items = [('Todo', total)] + items
    return {'segStyle': f'--n: {len(all_items)};', 'indStyle': 'transform: translateX(0%);',
            'items': [{'label': k, 'count': v, 'url': '#', 'cur': 'page' if i == 0 else None,
                       'chipCls': 'chip is-on live' if i == 0 else 'chip live'} for i, (k, v) in enumerate(all_items)]}


def pager(note, pages, label):
    return {'note': note, 'label': label, 'multi': True, 'prev': None, 'next': '#',
            'pages': [{'num': True, 'gap': False, 'n': n, 'url': '#', 'cur': 'page' if n == 1 else None} for n in pages]}


def topics(title, exclude=None, eyebrow='Explora por tema'):
    items = []
    for name, n in G.OTHER_TOPICS:
        if name == exclude:
            continue
        acc = G.TOPIC[name][0]
        items.append({'url': '#', 'name': name, 'count': f"{n} {'publicación' if n == 1 else 'publicaciones'}",
                      'style': f'--acc: {acc};', 'barStyle': f'background: {acc};'})
    return {'eyebrow': eyebrow, 'title': title, 'all': 44, 'allUrl': '#', 'items': items}


def crumbs(items):
    return [{'label': x, 'url': '#'} for x in items[:-1]], items[-1]


def base(view, crumb_items, eyebrow, bar):
    c, last = crumbs(crumb_items)
    return {'view': view, 'assets': ASSETS, 'crumbs': c, 'crumb': last, 'headCls': 'ah ah--f', 'gridCls': 'ah__g ah__g--f',
            'gridStyle': None, 'eyebrow': eyebrow, 'eyebrowBar': f'background: {bar};', 'isAuthor': False, 'author': None,
            'plainH1': True, 'h1': None, 'h1Cls': 'idea ah__t', 'h1Style': None, 'desc': None, 'search': None,
            'suggestions': None, 'meta': None, 'hero': None, 'parent': None, 'spark': False, 'filter': None,
            'list': None, 'meanwhile': None, 'topics': None, 'rootCls': 'v3 arc', 'gl': None}


def meanwhile(title):
    g = G.AUTHOR[0]
    return {'title': title,
            'glitch': {'url': '#', 'img': B(g['img']), 'title': g['title'], 'min': g['min'], 'date': g['date']},
            'guide': {'url': '#', 'kicker': 'Guía · Loop Marketing', 'bar': 'background: #36c8bf;', 'title': 'Cómo ejecutar Loop Marketing en tu empresa'},
            'article': {'url': '#', 'kicker': 'Artículo · AEO', 'bar': 'background: #0375db;', 'title': 'El fin de la web «solo para humanos»'}}


def search(value):
    return {'action': '#', 'value': value, 'label': 'Buscar en el blog'}


docs = {}

d = base('tema', ['Inicio', 'Blog', 'Temas', 'HubSpot'], 'Tema', '#e86bd0')
d.update(h1='HubSpot', h1Style='color: #e86bd0;',
         desc='Cómo usamos HubSpot para ordenar ventas, marketing y servicio: casos reales, guías paso a paso y lo que aprendimos implementándolo.',
         meta=[{'k': 'publicaciones', 'v': '12'}, {'k': 'la última', 'v': '17 jul 2026'}], hero=hero('Lo más reciente', G.HUBSPOT[0]),
         filter=filt(12, [('Artículos', 4), ('Guías', 4), ('Casos', 2), ('Novedades', 2)]),
         list={'label': 'Todas las publicaciones de HubSpot', 'groups': groups(G.HUBSPOT[1:], {'2026': 2, '2025': 1, '2024': 9}, 'en HubSpot', False),
               'flat': None, 'pager': pager('Mostrando 1–10 de 12 publicaciones', [1, 2], 'Páginas del tema')},
         topics=topics('Otros temas del blog.', exclude='HubSpot'))
docs['tema'] = d

d = base('etiqueta', ['Inicio', 'Blog', 'Etiquetas', 'inbound'], 'Etiqueta', '#cfe4fa')
d.update(h1='inbound', desc='Publicaciones marcadas con «inbound», de distintos temas.',
         meta=[{'k': 'publicaciones', 'v': '11'}, {'k': 'la última', 'v': '26 nov 2024'}], hero=hero('Lo más reciente', G.INBOUND_TAG[0]),
         filter=filt(11, [('Artículos', 8), ('Guías', 1), ('Novedades', 2)]),
         list={'label': 'Publicaciones con la etiqueta inbound', 'groups': groups(G.INBOUND_TAG[1:], {'2024': 11}, 'con esta etiqueta', True),
               'flat': None, 'pager': pager('Mostrando 1–10 de 11 publicaciones', [1, 2], 'Páginas de la etiqueta')},
         topics=topics('Explora por tema.'))
docs['etiqueta'] = d

d = base('autor', ['Inicio', 'Blog', 'Autores', 'Julio Reyes'], 'Autor', '#36c8bf')
d.update(isAuthor=True, plainH1=False, author={'photo': B('9a8e2f558646ef115b46fdbc23b1ed5b'), 'name': 'Julio Reyes', 'role': 'Fundador y Managing & GTM Director de Efeonce Group'},
         desc=G.JULIO_BIO, meta=[{'k': 'publicaciones', 'v': '44'}, {'k': 'la última', 'v': '28 sep 2026'}], hero=hero('Lo último de Julio', G.AUTHOR[0]),
         filter=filt(44, [('Artículos', 25), ('Glitch', 10), ('Guías', 5), ('Casos', 2), ('Novedades', 2)]),
         list={'label': 'Publicaciones de Julio Reyes', 'groups': groups(G.AUTHOR[1:], {'2026': 22}, 'de Julio', True),
               'flat': None, 'pager': pager('Mostrando 1–10 de 44 publicaciones', [1, 2, 3, 4, 5], 'Páginas del autor')},
         topics=topics('Los temas de Julio.', eyebrow='Escribe sobre'))
docs['autor'] = d

d = base('busqueda', ['Inicio', 'Blog', 'Búsqueda'], 'Búsqueda en el blog', '#36c8bf')
d.update(h1='«Inbound»', h1Cls='idea ah__t ah__t--m', search=search('Inbound'), meta=[{'k': 'resultados', 'v': '19'}],
         hero=hero('Mejor resultado', G.SEARCH[0], term='Inbound'), filter=filt(19, [('Artículos', 16), ('Guías', 3)]),
         list={'label': 'Resultados', 'groups': None, 'flat': [row(p, True, term='Inbound', full_date=True) for p in G.SEARCH[1:]],
               'pager': pager('Mostrando 1–10 de 19 resultados', [1, 2], 'Páginas de resultados')},
         topics=topics('¿No era esto? Busca por tema.'))
docs['busqueda'] = d

d = base('tema-vacio', ['Inicio', 'Blog', 'Temas', 'Marketing Digital', 'Redes Sociales'], 'Tema', G.TOPIC['Redes Sociales'][0])
d.update(headCls='ah', gridCls='ah__g', h1='Redes Sociales', h1Style=f"color: {G.TOPIC['Redes Sociales'][0]};",
         desc='Todavía no hay publicaciones en este tema. Mientras tanto, Marketing Digital reúne lo más cercano.',
         parent={'url': '#', 'name': 'Marketing Digital', 'count': 6}, meanwhile=meanwhile('Mientras tanto'),
         topics=topics('Otros temas del blog.', exclude='Redes Sociales'))
docs['tema-vacio'] = d

d = base('busqueda-vacia', ['Inicio', 'Blog', 'Búsqueda'], 'Búsqueda en el blog', '#36c8bf')
d.update(headCls='ah', gridCls='ah__g', gridStyle='align-items: center;', h1='Nada sobre «metaverso», todavía.', h1Cls='idea ah__t ah__t--m',
         desc='Prueba con otra palabra o con una de las preguntas que más nos hacen.', search=search('metaverso'),
         suggestions=[{'url': '#', 'label': s} for s in ['Cómo aparecer en ChatGPT', 'Ordenar mi CRM en HubSpot', 'Qué es Loop Marketing', 'Escalar la producción creativa']],
         spark=True, meanwhile=meanwhile('Mientras tanto, para empezar'), topics=topics('O busca por tema.'))
docs['busqueda-vacia'] = d

# TASK-2056 — the Glitch variant of the topic view (canvas version 79).
import gen_glitch as GL  # noqa: E402

d = base('tema-glitch', ['Inicio', 'Blog', 'Temas', 'Glitch'], 'El newsletter de Efeonce', GL.ACC)
grows = []
for p in GL.ROWS:
    num, title = GL.split_edition(p['title']) if p['kind'] == 'Edición' else (None, p['title'])
    grows.append({'url': '#', 'date': p['date'], 'parts': parts(title), 'glitch': False, 'plain': True, 'label': p['kind'],
                  'min': p['min'], 'pd': False, 'gd': True, 'ed': num, 'fl': p['kind'] == 'Flash'})
d.update(rootCls='v3 arc gl', plainH1=False, hero=hero('Lo más reciente', GL.HERO),
         filter=filt(10, [('Ediciones', 7), ('Flash', 1), ('Notas', 2)]),
         list={'label': 'Todas las publicaciones de Glitch', 'flat': None,
               'groups': [{'year': '2026', 'caption': '10 publicaciones en Glitch', 'rows': grows}],
               'pager': {'note': 'Mostrando las 10 publicaciones', 'label': 'Páginas del tema', 'multi': False, 'prev': None, 'next': None, 'pages': []}},
         topics=topics('Otros temas del blog.', exclude='Glitch'),
         gl={'wordmark': B('72025ed97a7ce0c610ec355f78efed74'), 'logo': B('1063184040c6121be1f86602803b0f55'),
             'trail': B('3b6e8663a0a14cda3ae78bca5e9226e7'),
             'desc': 'El resumen semanal de Efeonce sobre IA, marketing y tecnología: lo que cambió, por qué importa y qué hacer con eso,',
             'mul': 'sin anestesia.', 'edition': {'n': '17', 'date': '28 jul 2026'}, 'flash': {'date': '28 sep 2026'},
             'sub': {'demo': True, 'live': False}})
docs['tema-glitch'] = d

for k, v in docs.items():
    with open(os.path.join(OUT, f'fixture.{k}.json'), 'w', encoding='utf-8') as f:
        json.dump(v, f, ensure_ascii=False, indent=2)
        f.write('\n')
print('fixtures:', ', '.join(docs))
