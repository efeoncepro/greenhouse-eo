#!/usr/bin/env python3
"""Dirección D «Órbita + Índice» del Archivo del blog (TASK-2055), en el canvas «Portada Blog Efeonce».

Cabecera oscura de B (nombre en el color del tema, cifras útiles, formatos como filtro), una pieza destacada y las
filas del archivo de A, cierre «Otros temas» en navy. Seis vistas (tema, etiqueta, autor, búsqueda, tema vacío,
búsqueda sin resultados) a 1440 y 390 con el mismo marcado: lo que cambia entre medidas vive en clases, emitidas
como `@media (max-width: 767px)` y como `.mob` (los tableros de 390 llevan `.mob` en la raíz).
Datos reales de efeoncepro.com al 2026-10-24. CSS literal de la portada v3 donde existe.
"""
import html
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(os.path.dirname(HERE), 'artifact-files', 'd0b47eaf-e9d9-406a-b453-d88c2ddd62fd', 'project')
CSS_LINES = open(os.path.join(HERE, 'portada.css'), encoding='utf-8').read().split('\n')


def css_range(a, b):
    return '\n'.join(CSS_LINES[a - 1:b])


BASE_CSS = '\n'.join([css_range(1, 14), css_range(77, 89), css_range(101, 110), css_range(117, 129),
                      css_range(135, 228), css_range(322, 335)])

DESK_CSS = r"""
/* ── Archivo del blog · D (TASK-2055). Valores de la portada v3; lo que cambia en móvil va abajo, por clase ── */
.arc{font-family:'Poppins',system-ui,sans-serif;color:#023c70;background:#ffffff;overflow-x:clip}
.crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:0;padding:0;list-style:none;font-size:14px;color:#cfe4fa}
.crumb li{display:inline-flex;align-items:center;gap:8px}
.crumb li+li::before{content:"/";opacity:.5}
.crumb a{color:inherit;text-decoration:none;border-radius:6px}
.crumb [aria-current]{color:#ffffff;font-weight:500}
.eyb{display:flex;align-items:center;gap:10px;margin:0;font-size:14px;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:#6d6777}
.eyb--d{color:#cfe4fa}
.eyb__bar{width:28px;height:5px;border-radius:3px;flex:none}
.ah{position:relative;background:#001a33;color:#ffffff;padding:168px 0 104px;overflow:hidden}
.ah__g{display:grid;grid-template-columns:minmax(0,7fr) minmax(0,5fr);gap:48px 72px;align-items:end;margin-top:56px}
.ah__t{margin:16px 0 0;font-size:184px;line-height:.84;font-weight:760;letter-spacing:-.06em;text-wrap:balance;overflow-wrap:anywhere}
.ah__t--m{font-size:132px;line-height:.88;letter-spacing:-.05em}
.ah__d{margin:36px 0 0;max-width:620px;font-size:20px;line-height:1.55;color:#cfe4fa}
.ah__side{display:flex;flex-direction:column;gap:28px;width:100%;max-width:520px;justify-self:end}
.ah__n{display:flex;align-items:baseline;gap:14px;margin:0;color:#ffffff}
.ah__n .idea{font-size:200px;line-height:.8;font-weight:760;letter-spacing:-.07em;font-variant-numeric:tabular-nums}
.ah__n > span:last-child{font-size:28px;font-weight:500}
.ah__l{margin:0;padding-top:24px;border-top:1px solid rgba(207,228,250,.18);font-size:16px;color:#cfe4fa}
.chips{display:flex;flex-wrap:wrap;gap:10px}
:is(.v3,.m3) .chip.chip--d{border-color:rgba(207,228,250,.32);color:#ffffff}
:is(.v3,.m3) .chip.chip--d.is-on{background-color:#ffffff;border-color:#ffffff;color:#001a33}
@media (hover:hover){:is(.v3,.m3) .chip.chip--d:not(.is-on):hover{border-color:#ffffff;background-color:rgba(255,255,255,.08)}}
.chip--d:focus-visible{outline:2px solid #36c8bf;outline-offset:3px}
.chip__n{font-weight:400;opacity:.75;font-variant-numeric:tabular-nums}
.au{display:flex;flex-direction:column;align-items:flex-start;gap:28px;margin-top:24px}
.au__ph{width:168px;height:168px;flex:none;border-radius:50%;object-fit:cover;box-shadow:0 0 0 4px #001a33,0 0 0 6px #36c8bf}
.au__r{margin:12px 0 0;font-size:18px;font-weight:600;color:#ffffff}
.sfd{display:flex;align-items:center;gap:12px;margin-top:40px;max-width:720px;height:84px;padding:0 10px 0 32px;border-radius:999px;background:#ffffff;border:1.5px solid #ffffff}
.sfd input{flex:1;min-width:0;height:60px;border:0;background:transparent;color:#023c70;font:400 20px 'Poppins',sans-serif}
.sfd .beamsvg rect{rx:42.5px}
.spark{display:block;width:100%;max-width:440px;height:auto;margin-left:auto}
.fx{background:#ffffff;padding:104px 0 0}
.fc{position:relative;display:grid;grid-template-columns:minmax(0,7fr) minmax(0,5fr);min-height:520px;margin-top:28px;border-radius:40px;overflow:hidden;background:#001a33;color:#ffffff;text-decoration:none;transition:transform 300ms cubic-bezier(0.2,0,0,1)}
.fc__b{display:flex;flex-direction:column;justify-content:space-between;gap:32px;padding:56px 56px 52px 64px}
.fc__k{display:flex;align-items:center;gap:10px;font-size:14px;color:#cfe4fa}
.fc__k > span:first-child{width:28px;height:5px;border-radius:3px;flex:none}
.fc__t{margin-top:20px;font-size:56px;line-height:.96;font-weight:760;letter-spacing:-.045em;text-wrap:balance}
.fc__m{display:flex;align-items:center;gap:16px;font-size:15px;color:#cfe4fa}
.fc__img{position:relative;overflow:hidden;background:#001a33}
.fc__img img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;transition:transform 1200ms cubic-bezier(0.2,0,0,1)}
.fc .card__a{top:28px;right:28px}
.fc--wide{grid-template-columns:minmax(0,5fr) minmax(0,7fr);min-height:0}
.fc--wide .fc__img{min-height:100%;aspect-ratio:16/9}
.fc--wide .fc__t{font-size:44px;line-height:.98;letter-spacing:-.04em}
.fc--stack{grid-template-columns:minmax(0,1fr);min-height:0}
.fc--stack .fc__img{order:-1;aspect-ratio:16/9}
.fc--stack .fc__b{padding:36px 40px 36px}
.fc--stack .fc__t{font-size:40px;line-height:.98;letter-spacing:-.04em}
.fc:focus-visible{outline:2px solid #023c70;outline-offset:4px}
.fc:active{transform:scale(.99)}
@media (hover:hover){.fc:hover .fc__img img{transform:scale(1.04)}.fc:hover .card__a{opacity:1;transform:none}.fc:hover .ax{transform:translateX(3px)}.fc:hover .ax__s{stroke-dasharray:1 2}}
.al{background:#ffffff;padding:104px 0 128px}
.yg{display:grid;grid-template-columns:minmax(0,4fr) minmax(0,8fr);gap:72px;align-items:start;padding-top:56px}
.yg__y{position:sticky;top:112px}
.yg__n{margin:0;font-size:120px;line-height:.82;font-weight:760;letter-spacing:-.06em}
.yg__c{margin:16px 0 0;font-size:14px;color:#6d6777}
.rows{border-bottom:1px solid rgba(2,60,112,.14)}
.arch-row--x{grid-template-columns:110px minmax(0,1fr) 230px}
.rw__d{font-size:14px;color:#6d6777}
.rw__t{font-size:30px;line-height:1.08;font-weight:640;letter-spacing:-.025em}
.rw__k{font-size:14px;text-align:right}
.rw__m{color:#6d6777}
.hl{background:rgba(54,200,191,.22);color:inherit;border-radius:4px;padding:0 .08em}
.pgw{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:24px;margin-top:40px}
.pgw__n{font-size:14px;color:#6d6777}
.pager{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:0;padding:0;list-style:none}
.pg{display:inline-grid;place-items:center;min-width:48px;height:48px;padding:0 6px;border-radius:999px;border:1px solid rgba(2,60,112,.24);color:#023c70;font-size:15px;font-weight:600;text-decoration:none;font-variant-numeric:tabular-nums;transition:background-color 150ms,border-color 150ms}
.pg[aria-current="page"]{background:#023c70;border-color:#023c70;color:#ffffff}
.pg--gap{border-color:transparent}
.pg:focus-visible{outline:2px solid #023c70;outline-offset:3px}
@media (hover:hover){.pg:not([aria-current]):not(.pg--gap):hover{border-color:#023c70;background:#ffffff}}
.ot{background:#001a33;color:#ffffff;padding:112px 0 120px}
.ot__h{display:flex;flex-wrap:wrap;align-items:flex-end;justify-content:space-between;gap:24px}
.ot__t{margin:16px 0 0;font-size:72px;line-height:.9;font-weight:760;letter-spacing:-.05em}
.ot__g{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:40px 32px;margin-top:64px}
.lab2{display:flex;flex-direction:column;gap:6px;text-decoration:none;color:#ffffff;border-radius:12px;padding:8px 4px}
.lab2 .nm{font-family:'Bricolage Grotesque',sans-serif;font-size:28px;line-height:1;font-weight:700;letter-spacing:-.02em;transition:color 200ms cubic-bezier(0.4,0,0.2,1)}
.lab2 .ct{font-size:14px;color:#cfe4fa}
.lab2 .bar{width:40px;height:3px;border-radius:2px}
.lab2:focus-visible{outline:2px solid #36c8bf;outline-offset:2px}
@media (hover:hover){.lab2:hover .nm{color:var(--acc)}}
.mt{background:#ffffff;padding:104px 0 128px}
.mt__g{display:grid;grid-template-columns:minmax(0,7fr) minmax(0,5fr);gap:20px;margin-top:28px}
.mt__c{display:grid;grid-template-rows:minmax(0,1fr) minmax(0,1fr);gap:20px}
.gc{position:relative;display:flex;flex-direction:column;justify-content:space-between;gap:24px;min-height:250px;padding:32px;border-radius:32px;overflow:hidden;text-decoration:none;transition:transform 300ms cubic-bezier(0.2,0,0,1)}
.gc:focus-visible{outline:2px solid #023c70;outline-offset:4px}
@media (hover:hover){.gc:hover{transform:translateY(-6px)}.gc:hover .card__a{opacity:1;transform:none}}
.gc__t{font-size:30px;line-height:1.02;font-weight:740;letter-spacing:-.03em}
.nvs{position:absolute;top:12px;left:50%;transform:translateX(-50%);z-index:5;width:min(1180px,calc(100% - 32px));height:62px;display:flex;align-items:center;justify-content:space-between;gap:16px;padding:0 10px 0 28px;border-radius:999px;background:#ffffff;box-shadow:0 10px 30px rgba(0,26,51,.08)}
.nvs__l{font-size:13px;color:#6d6777}
.nvs__c{display:inline-flex;align-items:center;height:44px;padding:0 20px;border-radius:999px;background:#001a33;color:#ffffff;font-size:15px;font-weight:600}
.nvs__m{display:none}
@media (prefers-reduced-motion:reduce){.fc,.fc__img img,.gc,.pg,.lab2 .nm{transition:none}.fc:hover .fc__img img,.gc:hover{transform:none}}
"""

# Phone (< 768 px): emitted as a media query and as `.mob` (the 390 artboards). Values from the Movil-v3 board.
MOB_RULES = [
    ('.w', 'padding:0 16px'),
    ('.nvs', 'top:8px;width:calc(100% - 16px);height:56px;padding:0 6px 0 20px'),
    ('.nvs__l,.nvs__c', 'display:none'),
    ('.nvs__m', 'display:grid;place-items:center;width:44px;height:44px;border-radius:999px;background:#001a33;color:#ffffff'),
    ('.crumb', 'font-size:13px'),
    ('.eyb', 'font-size:12px'),
    ('.ah', 'padding:104px 0 56px'),
    ('.ah__g', 'grid-template-columns:minmax(0,1fr);gap:36px;margin-top:32px;align-items:start'),
    ('.ah__t', 'margin-top:12px;font-size:76px;line-height:.86;letter-spacing:-.055em'),
    ('.ah__t--m', 'font-size:60px;line-height:.9;letter-spacing:-.045em'),
    ('.ah__d', 'margin-top:20px;font-size:16px'),
    ('.ah__side', 'gap:20px;max-width:none;justify-self:stretch'),
    ('.ah__n .idea', 'font-size:120px'),
    ('.ah__n > span:last-child', 'font-size:22px'),
    ('.ah__l', 'padding-top:16px;font-size:14px'),
    ('.chips', 'flex-wrap:nowrap;overflow-x:auto;margin:0 -16px;padding:0 16px 4px;scrollbar-width:none'),
    ('.chips .chip', 'flex:none'),
    ('.au', 'flex-direction:column;align-items:flex-start;gap:20px;margin-top:8px'),
    ('.au__ph', 'width:112px;height:112px'),
    ('.au__r', 'font-size:15px'),
    ('.sfd', 'height:64px;margin-top:24px;padding:0 6px 0 20px;gap:8px'),
    ('.sfd input', 'height:52px;font-size:17px'),
    ('.sfd .beamsvg rect', 'rx:32.5px'),
    ('.sfd .ab', 'min-height:52px!important;padding:0 1rem!important'),
    ('.spark', 'max-width:220px;margin:0 auto'),
    ('.fx', 'padding:56px 0 0'),
    ('.fc', 'grid-template-columns:minmax(0,1fr);min-height:0;margin-top:20px;border-radius:26px'),
    ('.fc__img', 'order:-1;height:220px'),
    ('.fc--wide .fc__img,.fc--stack .fc__img', 'height:auto;min-height:0;aspect-ratio:16/9'),
    ('.fc--wide .fc__t,.fc--stack .fc__t', 'font-size:30px'),
    ('.fc--stack .fc__b', 'padding:24px 22px 26px'),
    ('.fc__b', 'padding:24px 22px 26px;gap:20px'),
    ('.fc__k', 'font-size:12px'),
    ('.fc__t', 'margin-top:12px;font-size:30px;line-height:1;letter-spacing:-.035em'),
    ('.fc__m', 'font-size:13px'),
    ('.al', 'padding:56px 0 64px'),
    ('.yg', 'grid-template-columns:minmax(0,1fr);gap:8px;padding-top:40px'),
    ('.yg__y', 'position:static;display:flex;align-items:baseline;justify-content:space-between;gap:12px'),
    ('.yg__n', 'font-size:72px;letter-spacing:-.06em'),
    ('.yg__c', 'margin:0;font-size:12px'),
    ('.arch-row--x', 'grid-template-columns:auto minmax(0,1fr);gap:6px 10px;padding:16px 0!important;margin:0'),
    ('.rw__d', 'font-size:12px'),
    ('.rw__k', 'grid-column:2;grid-row:1;justify-content:flex-start;font-size:12px;text-align:left'),
    ('.rw__t', 'grid-column:1 / -1;grid-row:2;font-size:22px;line-height:1.1'),
    ('.arch-a', 'display:none'),
    ('.pgw', 'flex-direction:column;align-items:stretch;gap:16px;margin-top:28px'),
    ('.pgw__n', 'font-size:12px;text-align:center'),
    ('.pager', 'justify-content:center'),
    ('.pg', 'min-width:44px;height:44px;font-size:14px'),
    ('.ot', 'padding:64px 0 56px'),
    ('.ot__t', 'margin-top:12px;font-size:48px;line-height:.92;letter-spacing:-.045em'),
    ('.ot__g', 'grid-template-columns:repeat(2,minmax(0,1fr));gap:24px 16px;margin-top:32px'),
    ('.lab2 .nm', 'font-size:22px'),
    ('.lab2 .ct', 'font-size:12px'),
    ('.mt', 'padding:56px 0 64px'),
    ('.mt__g', 'grid-template-columns:minmax(0,1fr);margin-top:20px;gap:16px'),
    ('.mt__c', 'grid-template-rows:none;gap:16px'),
    ('.gc', 'min-height:220px;padding:24px;border-radius:26px'),
    ('.gc__t', 'font-size:24px'),
]


def mob_css():
    plain = '\n'.join(f'{sel}{{{decl}}}' for sel, decl in MOB_RULES)

    def scoped(sel):
        return ','.join(f'.mob {s.strip()}' for s in sel.split(','))
    mob = '\n'.join(f'{scoped(sel)}{{{decl}}}' for sel, decl in MOB_RULES)
    return f'@media (max-width:767px){{\n{plain}\n}}\n{mob}\n'


ICON = {
    'arrow': '<svg class="arch-a" width="18" height="18" viewBox="0 0 24 24" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5"/><path d="M14 7l5 5l-5 5"/></g></svg>',
    'card': '<svg class="card__a" viewBox="0 0 24 24" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7 17L17 7"/><path d="M8 7h9v9"/></g></svg>',
    'ax': '<svg class="ax" width="20" height="20" viewBox="0 0 24 24" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path class="ax__s" pathLength="1" d="M19 12H5"/><path class="ax__h" d="M14 7l5 5l-5 5"/></g></svg>',
    'search': '<svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 10a6 6 0 1 0 12 0a6 6 0 1 0 -12 0"/><path d="M20 20l-5.6 -5.6"/></g></svg>',
    'menu': '<svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8h16M4 16h16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
}
GLITCH_NEG = '<img src="/_blob/72025ed97a7ce0c610ec355f78efed74" alt="Glitch" width="56" height="15" style="display: inline-block; height: 15px; width: auto; vertical-align: -2px;">'
GLITCH_LOGO = '<img src="/_blob/1063184040c6121be1f86602803b0f55" alt="Glitch" width="56" height="15" style="display: inline-block; height: 15px; width: auto; vertical-align: -2px;">'

# Topic palette as EO_CM_Util::TOPICS after the 2026-10-24 change (inbound, ai, novedades recolored).
TOPIC = {
    'HubSpot': ('#e86bd0', '#8e1b82'), 'Inbound Marketing': ('#e86bd0', '#8e1b82'), 'AEO': ('#0375db', '#0375db'),
    'Inteligencia Artificial': ('#0375db', '#0375db'), 'Loop Marketing': ('#36c8bf', '#0e8c82'), 'Diseño': ('#ff6500', '#ff6500'),
    'Diseño Web': ('#ff6500', '#ff6500'), 'Growth': ('#36c8bf', '#0e8c82'), 'Marketing Digital': ('#36c8bf', '#0e8c82'),
    'Redes Sociales': ('#36c8bf', '#0e8c82'), 'SEO': ('#0375db', '#0375db'), 'Novedades Efeonce': ('#36c8bf', '#0e8c82'),
    'Glitch': ('#6ec207', '#4f8c00'),
}
OTHER_TOPICS = [('HubSpot', 12), ('Glitch', 10), ('Inbound Marketing', 10), ('Marketing Digital', 6), ('Loop Marketing', 5),
                ('AEO', 4), ('Inteligencia Artificial', 2), ('Diseño', 2), ('SEO', 2), ('Novedades Efeonce', 2), ('Growth', 1)]


def e(s):
    return html.escape(s, quote=True)


def hl(title, term):
    if not term:
        return e(title)
    out, last = [], 0
    for m in re.finditer(re.escape(term), title, flags=re.I):
        out.append(e(title[last:m.start()]))
        out.append(f'<mark class="hl">{e(m.group(0))}</mark>')
        last = m.end()
    out.append(e(title[last:]))
    return ''.join(out)


# ───────────────────────────── building blocks ─────────────────────────────
def nav_stub():
    return f'''<div class="nvs" aria-hidden="true">
  <img src="/_blob/83245a45d586a61636aa1ac2deff2ab6" alt="" style="height: 26px; width: auto; display: block;">
  <span class="nvs__l">Menú global del sitio (heredado sin cambios)</span>
  <span class="nvs__c">Agenda tu diagnóstico</span>
  <span class="nvs__m">{ICON['menu']}</span>
</div>'''


def crumbs(items):
    lis = ''.join(f'<li><a href="#">{e(x)}</a></li>' for x in items[:-1])
    return f'<nav aria-label="Migas de pan"><ol class="crumb">{lis}<li><span aria-current="page">{e(items[-1])}</span></li></ol></nav>'


def chips(items, active=None, dark=True):
    cls = 'chip chip--d' if dark else 'chip'
    out = []
    for label, n in items:
        on = ' is-on' if label == active else ''
        pressed = 'true' if label == active else 'false'
        num = f' <span class="chip__n">{n}</span>' if n is not None else ''
        out.append(f'<a href="#" class="{cls}{on} live" aria-pressed="{pressed}">{e(label)}{num}</a>')
    return '\n          '.join(out)


def side_count(n, unit, last, fmt_items):
    return f'''<div class="ah__side">
        <p class="ah__n"><span class="idea">{n}</span><span>{e(unit)}</span></p>
        <p class="ah__l">{e(last)}</p>
        <div class="chips" role="group" aria-label="Filtrar por formato">
          {chips([('Todo', None)] + fmt_items, active='Todo')}
        </div>
      </div>'''


def featured(label, p, term=None):
    wide = ' fc--wide' if p.get('wide') else ''
    acc = TOPIC[p['topic']][0]
    kind = f'{GLITCH_NEG} <span>{e(p["fmt"])}</span>' if p['topic'] == 'Glitch' else f'<span>{e(p["fmt"])} · {e(p["topic"])}</span>'
    return f'''<section class="fx" aria-labelledby="fx-h">
  <div class="w">
    <p id="fx-h" class="eyb"><span class="eyb__bar" style="background: {acc};"></span>{e(label)}</p>
    <a href="#" class="fc{wide}">{ICON['card']}
      <span class="fc__b">
        <span>
          <span class="fc__k"><span style="background: {acc};"></span>{kind}</span>
          <span class="idea fc__t" style="display: block;">{hl(p['title'], term)}</span>
        </span>
        <span class="fc__m"><span>{p['min']} min de lectura · {e(p['date'])}</span><span class="nl nl--dark live" style="margin: 0 0 0 auto;"><span class="roll"><span class="roll__in"><span>Leer</span><span aria-hidden="true">Leer</span></span></span>{ICON['ax']}</span></span>
      </span>
      <span class="fc__img"><img src="/_blob/{p['img']}" alt=""></span>
    </a>
  </div>
</section>'''


def row(p, show_topic, term=None, full_date=False):
    date = p['date'] if full_date else p['date'].rsplit(' ', 1)[0]
    mins = f' <span class="rw__m">· {p["min"]} min</span>'
    if p['topic'] == 'Glitch':
        kind = f'<span class="arch-gl">{GLITCH_LOGO}<span>{e(p["fmt"])}{mins}</span></span>'
    elif show_topic:
        kind = f'<span>{e(p["topic"])} · {e(p["fmt"])}{mins}</span>'
    else:
        kind = f'<span>{e(p["fmt"])}{mins}</span>'
    return f'''<a href="#" class="lnk arch-row arch-row--x">
            <span class="rw__d">{e(date)}</span>
            <span class="idea u rw__t">{hl(p['title'], term)}</span>
            <span class="arch-k rw__k">{kind}{ICON['arrow']}</span>
          </a>'''


def year_groups(posts, year_totals, scope, show_topic):
    out = []
    for year in sorted({p['date'][-4:] for p in posts}, reverse=True):
        ps = [p for p in posts if p['date'][-4:] == year]
        n = year_totals[year]
        unit = 'publicación' if n == 1 else 'publicaciones'
        rows = '\n          '.join(row(p, show_topic) for p in ps)
        out.append(f'''<div class="yg">
      <div class="yg__y"><p class="idea yg__n">{year}</p><p class="yg__c">{n} {unit} {e(scope)}</p></div>
      <div class="rows">
          {rows}
      </div>
    </div>''')
    return '\n    '.join(out)


def pager(note, pages, label):
    items = []
    for pg in pages:
        if pg == '…':
            items.append('<li><span class="pg pg--gap" aria-hidden="true">…</span></li>')
        else:
            cur = ' aria-current="page"' if pg == 1 else ''
            items.append(f'<li><a href="#" class="pg"{cur}>{pg}</a></li>')
    items.append(f'<li><a href="#" class="nl nl--light live" style="margin: 0 0 0 8px;"><span class="roll"><span class="roll__in"><span>Siguiente</span><span aria-hidden="true">Siguiente</span></span></span>{ICON["ax"]}</a></li>')
    return f'''<div class="pgw">
      <span class="pgw__n">{e(note)}</span>
      <nav aria-label="{e(label)}"><ul class="pager">{''.join(items)}</ul></nav>
    </div>'''


def other_topics(title, exclude=None, eyebrow='Explora por tema'):
    labs = []
    for name, n in OTHER_TOPICS:
        if name == exclude:
            continue
        acc = TOPIC[name][0]
        unit = 'publicación' if n == 1 else 'publicaciones'
        labs.append(f'<a href="#" class="lab2" style="--acc: {acc};"><span class="nm">{e(name)}</span><span class="ct">{n} {unit}</span><span class="bar" style="background: {acc};"></span></a>')
    labs_html = '\n      '.join(labs)
    return f'''<section class="ot" aria-labelledby="ot-h">
  <div class="w">
    <div class="ot__h">
      <div>
        <p class="eyb eyb--d">{e(eyebrow)}</p>
        <h2 id="ot-h" class="idea ot__t">{e(title)}</h2>
      </div>
      <a href="#" class="nl nl--dark live"><span class="roll"><span class="roll__in"><span>Todo el archivo</span><span aria-hidden="true">Todo el archivo</span></span></span><span class="nl__n">44</span>{ICON['ax']}</a>
    </div>
    <div class="ot__g">
      {labs_html}
    </div>
  </div>
</section>'''


def footer_stub():
    return '''<footer style="background: #f7f8f6; padding: 64px 16px 72px;">
  <div style="display: flex; flex-direction: column; align-items: center; gap: 14px;">
    <img src="/_blob/83245a45d586a61636aa1ac2deff2ab6" alt="Efeonce" style="width: 200px; max-width: 50%; height: auto;">
    <p style="margin: 0; font-size: 14px; color: #6d6777;">Pie global del sitio, heredado sin cambios.</p>
  </div>
</footer>'''


def search_form(value, label):
    return f'''<form role="search" action="#" class="sf sfd">
          <svg class="beamsvg" aria-hidden="true" focusable="false"><rect class="bm-t" pathLength="100"/><rect class="bm-m" pathLength="100"/><rect class="bm-h" pathLength="100"/></svg>
          <label for="q" class="sr">{e(label)}</label>
          <input id="q" type="search" name="s" value="{e(value)}" placeholder="Por ejemplo: cómo aparezco en ChatGPT">
          <button type="submit" class="ab ab--navy live" style="min-height: 60px; padding: 0 1.25rem 0 1.5rem;"><span class="ab__c" style="display: inline-flex; align-items: center; gap: .5rem;"><span class="roll"><span class="roll__in"><span>Buscar</span><span aria-hidden="true">Buscar</span></span></span>{ICON['search']}</span></button>
        </form>'''


def page(title, body, mobile, h):
    root_cls = 'v3 arc mob' if mobile else 'v3 arc'
    w = 390 if mobile else 1440
    return f'''<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>{e(title)}</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
<helmet>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="anonymous">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,300..800&amp;family=Poppins:ital,wght@0,300;0,400;0,500;0,600;1,400&amp;display=swap">
<style>
{BASE_CSS}
{DESK_CSS}
{mob_css()}
</style>
</helmet>
<div class="{root_cls}" style="position: relative;">
{nav_stub()}
{body}
{footer_stub()}
</div>
</x-dc>
<script type="text/x-dc" data-dc-script data-props='{{"$preview":{{"width":{w},"height":{h}}}}}'>
class Component extends DCLogic {{
  renderVals() {{ return {{}}; }}
}}
</script>
</body>
</html>
'''


# ───────────────────────────── data (efeoncepro.com, 2026-10-24) ─────────────────────────────
def P(date, topic, fmt, mins, title, img=None, wide=False):
    return {'date': date, 'topic': topic, 'fmt': fmt, 'min': mins, 'title': title, 'img': img, 'wide': wide}


HUBSPOT = [
    P('17 jul 2026', 'HubSpot', 'Caso', 18, '¿Qué necesita una IA para atender bien a tus clientes? Lo que aprendimos diseñando el Customer Agent de ANAM', '99eaef2d43c6f807676e064585ec1c4d', True),
    P('17 jul 2026', 'HubSpot', 'Caso', 13, 'Un dashboard no arregla un proceso comercial: cómo construimos paneles confiables en HubSpot para ANAM'),
    P('18 sep 2025', 'HubSpot', 'Guía', 21, 'Cómo ejecutar Loop Marketing en tu empresa con las innovaciones de HubSpot 2025'),
    P('26 nov 2024', 'HubSpot', 'Artículo', 9, 'De Excel a HubSpot en 5 Días: Organiza, Automatiza y Escala tus Ventas'),
    P('24 nov 2024', 'HubSpot', 'Guía', 15, 'Crea un Pipeline de Ventas que Convierte: Guía Paso a Paso'),
    P('24 nov 2024', 'HubSpot', 'Artículo', 6, '5 Pasos para transformar tu CRM en el motor de crecimiento de tu Negocio'),
    P('20 nov 2024', 'HubSpot', 'Guía', 5, 'Cómo crear formularios con validación de RUT chileno en minutos'),
    P('21 oct 2024', 'HubSpot', 'Novedad', 5, '¡Efeonce + Truora: La Alianza que Llevará tu Negocio a Otro Nivel!'),
    P('20 oct 2024', 'HubSpot', 'Novedad', 11, 'Efeonce es HubSpot Solutions Partner: Potencia tu Crecimiento'),
    P('17 ago 2024', 'HubSpot', 'Artículo', 21, 'HubSpot y el Desafío del Onboarding: Estrategias para un Inicio Exitoso'),
]

INBOUND_TAG = [
    P('26 nov 2024', 'HubSpot', 'Artículo', 9, 'De Excel a HubSpot en 5 Días: Organiza, Automatiza y Escala tus Ventas', '7134fd8c6f379f6b08f6cd7dfd4e5618'),
    P('24 nov 2024', 'HubSpot', 'Guía', 15, 'Crea un Pipeline de Ventas que Convierte: Guía Paso a Paso'),
    P('24 nov 2024', 'HubSpot', 'Artículo', 6, '5 Pasos para transformar tu CRM en el motor de crecimiento de tu Negocio'),
    P('21 oct 2024', 'HubSpot', 'Novedad', 5, '¡Efeonce + Truora: La Alianza que Llevará tu Negocio a Otro Nivel!'),
    P('21 oct 2024', 'Inbound Marketing', 'Artículo', 12, 'Qué es paid media y cómo combinarlo con el inbound marketing'),
    P('20 oct 2024', 'HubSpot', 'Novedad', 11, 'Efeonce es HubSpot Solutions Partner: Potencia tu Crecimiento'),
    P('17 ago 2024', 'HubSpot', 'Artículo', 21, 'HubSpot y el Desafío del Onboarding: Estrategias para un Inicio Exitoso'),
    P('11 ago 2024', 'HubSpot', 'Artículo', 18, 'HubSpot: Potenciando Marketing y Ventas para un Crecimiento Sostenible'),
    P('10 ago 2024', 'Inbound Marketing', 'Artículo', 9, 'Topic clusters y contenido pilar: cómo ordenar tu SEO para Google y la IA'),
    P('6 ago 2024', 'Diseño Web', 'Artículo', 18, 'Growth-Driven Design: Sitios Web que Generan Resultados'),
]

AUTHOR = [
    P('28 sep 2026', 'Glitch', 'Flash', 9, 'Glitch Flash: Sonnet 5.5 roza a Opus, a mitad de precio', '08933b6eae580530405a3ebace493378', True),
    P('28 jul 2026', 'Glitch', 'Edición', 13, 'Glitch #17: Agente rompe la jaula, la confianza reordena el frontier, la correa manda'),
    P('21 jul 2026', 'Glitch', 'Edición', 13, 'Glitch #16: Open-weight que descargas, precio que miente, canal sin dueño'),
    P('18 jul 2026', 'AEO', 'Artículo', 22, 'El fin de la web “solo para humanos”: cómo preparar tu sitio para los agentes de IA'),
    P('18 jul 2026', 'Inteligencia Artificial', 'Artículo', 8, '«I Know Kung Fu»: el momento Matrix de los Agent Skills'),
    P('17 jul 2026', 'HubSpot', 'Caso', 18, '¿Qué necesita una IA para atender bien a tus clientes? Lo que aprendimos diseñando el Customer Agent de ANAM'),
    P('17 jul 2026', 'HubSpot', 'Caso', 13, 'Un dashboard no arregla un proceso comercial: cómo construimos paneles confiables en HubSpot para ANAM'),
    P('15 jul 2026', 'Diseño', 'Artículo', 24, 'Creative Workflows: cómo escalar la creatividad sin automatizar el criterio'),
    P('14 jul 2026', 'Glitch', 'Edición', 15, 'Glitch #15: Token barato, criterio caro, y las capas que no controlas.'),
    P('10 jul 2026', 'Glitch', 'Nota', 6, 'GPT-5.6 y ChatGPT Work: OpenAI ya no está lanzando modelos, está cambiando la forma de trabajar'),
]

SEARCH = [
    P('7 sep 2025', 'Loop Marketing', 'Artículo', 20, '¿Qué es Loop Marketing? El framework que reemplaza al funnel y evoluciona el inbound', '7abf1bf7a4d059512788fdbc83bac04e'),
    P('21 oct 2024', 'Inbound Marketing', 'Artículo', 12, 'Qué es paid media y cómo combinarlo con el inbound marketing'),
    P('21 jul 2024', 'Inbound Marketing', 'Artículo', 12, 'Qué es el inbound marketing y cómo funciona en 2026'),
    P('6 feb 2026', 'Loop Marketing', 'Artículo', 23, 'Express en Loop Marketing: POV, voz única, buyer persona y Jobs-to-be-done'),
    P('6 feb 2026', 'Marketing Digital', 'Artículo', 21, 'La Ley 21.719 no regula datos: obliga a rediseñar el marketing y el Go-To-Market'),
    P('6 feb 2026', 'Inteligencia Artificial', 'Artículo', 15, 'El Protocolo de Comercio Universal (UCP): cuando la IA se convierte en el nuevo punto de venta'),
    P('6 feb 2026', 'Growth', 'Artículo', 19, '5 pasos para definir a tu cliente ideal: ICP, Buyer Persona, IPP y Jobs to Be Done'),
    P('18 sep 2025', 'HubSpot', 'Guía', 21, 'Cómo ejecutar Loop Marketing en tu empresa con las innovaciones de HubSpot 2025'),
    P('13 sep 2025', 'Loop Marketing', 'Artículo', 20, 'Cómo aplicar Loop Marketing: estrategia, etapas y conexión con el consumidor actual'),
    P('16 mar 2025', 'Marketing Digital', 'Guía', 20, '¿Es hora de contratar una agencia de marketing? Guía práctica para elegir la mejor opción'),
]

JULIO_BIO = ('Más de 12 años diseñando sistemas de marketing, crecimiento y operaciones creativas para organizaciones en '
             'Latinoamérica. Escribe sobre Loop Marketing, IA aplicada, SEO/AEO, Creative Operations y diseño de sistemas '
             'donde tecnología, datos y criterio humano trabajan juntos.')


# ───────────────────────────── views ─────────────────────────────
def v_tema():
    acc, deep = TOPIC['HubSpot']
    head = f'''<header class="ah" data-site-nav-tone="dark">
  <div class="w">
    {crumbs(['Inicio', 'Blog', 'Temas', 'HubSpot'])}
    <div class="ah__g">
      <div>
        <p class="eyb eyb--d"><span class="eyb__bar" style="background: {acc};"></span>Tema</p>
        <h1 class="idea ah__t" style="color: {acc};">HubSpot</h1>
        <p class="ah__d">[Descripción editorial del tema: una o dos frases que escribe el equipo en WordPress. Sin ella, la página queda fuera de Google.]</p>
      </div>
      {side_count(12, 'publicaciones', 'Lo último, 17 jul 2026', [('Artículos', 4), ('Guías', 4), ('Casos', 2), ('Novedades', 2)])}
    </div>
  </div>
</header>'''
    lst = f'''<section class="al" aria-label="Todas las publicaciones de HubSpot">
  <div class="w">
    {year_groups(HUBSPOT[1:], {'2026': 2, '2025': 1, '2024': 9}, 'en HubSpot', False)}
    {pager('Mostrando 1–10 de 12 publicaciones', [1, 2], 'Páginas del tema')}
  </div>
</section>'''
    return '\n'.join([head, featured('Lo más reciente', HUBSPOT[0]), lst, other_topics('Otros temas del blog.', exclude='HubSpot')])


def v_etiqueta():
    head = f'''<header class="ah" data-site-nav-tone="dark">
  <div class="w">
    {crumbs(['Inicio', 'Blog', 'Etiquetas', 'inbound'])}
    <div class="ah__g">
      <div>
        <p class="eyb eyb--d"><span class="eyb__bar" style="background: #cfe4fa;"></span>Etiqueta</p>
        <h1 class="idea ah__t">inbound</h1>
        <p class="ah__d">Publicaciones marcadas con «inbound», de distintos temas.</p>
      </div>
      {side_count(11, 'publicaciones', 'Lo último, 26 nov 2024', [('Artículos', 8), ('Guías', 1), ('Novedades', 2)])}
    </div>
  </div>
</header>'''
    lst = f'''<section class="al" aria-label="Publicaciones con la etiqueta inbound">
  <div class="w">
    {year_groups(INBOUND_TAG[1:], {'2024': 11}, 'con esta etiqueta', True)}
    {pager('Mostrando 1–10 de 11 publicaciones', [1, 2], 'Páginas de la etiqueta')}
  </div>
</section>'''
    return '\n'.join([head, featured('Lo más reciente', INBOUND_TAG[0]), lst, other_topics('Explora por tema.')])


def v_autor():
    head = f'''<header class="ah" data-site-nav-tone="dark">
  <div class="w">
    {crumbs(['Inicio', 'Blog', 'Autores', 'Julio Reyes'])}
    <div class="ah__g">
      <div>
        <p class="eyb eyb--d"><span class="eyb__bar" style="background: #36c8bf;"></span>Autor</p>
        <div class="au">
          <img class="au__ph" src="/_blob/9a8e2f558646ef115b46fdbc23b1ed5b" alt="Julio Reyes">
          <div>
            <h1 class="idea ah__t ah__t--m" style="margin: 0;">Julio Reyes</h1>
            <p class="au__r">Fundador y Managing &amp; GTM Director de Efeonce Group</p>
          </div>
        </div>
        <p class="ah__d">{e(JULIO_BIO)}</p>
      </div>
      {side_count(44, 'publicaciones', 'Lo último, 28 sep 2026', [('Artículos', 25), ('Glitch', 10), ('Guías', 5), ('Casos', 2), ('Novedades', 2)])}
    </div>
  </div>
</header>'''
    lst = f'''<section class="al" aria-label="Publicaciones de Julio Reyes">
  <div class="w">
    {year_groups(AUTHOR[1:], {'2026': 22}, 'de Julio', True)}
    {pager('Mostrando 1–10 de 44 publicaciones', [1, 2, 3, 4, 5], 'Páginas del autor')}
  </div>
</section>'''
    return '\n'.join([head, featured('Lo último de Julio', AUTHOR[0]), lst, other_topics('Los temas de Julio.', eyebrow='Escribe sobre')])


def v_busqueda():
    term = 'Inbound'
    rows = '\n          '.join(row(p, True, term=term, full_date=True) for p in SEARCH[1:])
    head = f'''<header class="ah" data-site-nav-tone="dark">
  <div class="w">
    {crumbs(['Inicio', 'Blog', 'Búsqueda'])}
    <div class="ah__g">
      <div>
        <p class="eyb eyb--d"><span class="eyb__bar" style="background: #36c8bf;"></span>Búsqueda en el blog</p>
        <h1 class="idea ah__t ah__t--m">«Inbound»</h1>
        {search_form(term, 'Buscar en el blog')}
      </div>
      {side_count(19, 'resultados', 'Artículos, guías y recursos del blog', [('Artículos', 16), ('Guías', 3)])}
    </div>
  </div>
</header>'''
    lst = f'''<section class="al" aria-label="Resultados">
  <div class="w">
    <div class="rows" style="margin-top: 56px;">
          {rows}
    </div>
    {pager('Mostrando 1–10 de 19 resultados', [1, 2], 'Páginas de resultados')}
  </div>
</section>'''
    return '\n'.join([head, featured('Mejor resultado', SEARCH[0], term=term), lst,
                      other_topics('¿No era esto? Busca por tema.', eyebrow='Explora por tema')])


def meanwhile(title):
    glitch = AUTHOR[0]
    return f'''<section class="mt" aria-labelledby="mt-h">
  <div class="w">
    <p id="mt-h" class="eyb"><span class="eyb__bar" style="background: #36c8bf;"></span>{e(title)}</p>
    <div class="mt__g">
      <a href="#" class="fc fc--stack" style="margin-top: 0;">{ICON['card']}
        <span class="fc__b">
          <span>
            <span class="fc__k"><span style="background: #6ec207;"></span>{GLITCH_NEG} <span>Lo último de Glitch</span></span>
            <span class="idea fc__t" style="display: block;">{e(glitch['title'])}</span>
          </span>
          <span class="fc__m"><span>{glitch['min']} min de lectura · {e(glitch['date'])}</span></span>
        </span>
        <span class="fc__img"><img src="/_blob/{glitch['img']}" alt=""></span>
      </a>
      <div class="mt__c">
        <a href="#" class="gc" style="background: #023c70; color: #ffffff;">{ICON['card']}
          <span class="fc__k"><span style="background: #36c8bf;"></span>Guía · Loop Marketing</span>
          <span class="idea gc__t">Cómo ejecutar Loop Marketing en tu empresa</span>
        </a>
        <a href="#" class="gc" style="background: #f7f8f6; color: #023c70;">{ICON['card']}
          <span class="fc__k" style="color: #6d6777;"><span style="background: #0375db;"></span>Artículo · AEO</span>
          <span class="idea gc__t">El fin de la web «solo para humanos»</span>
        </a>
      </div>
    </div>
  </div>
</section>'''


def v_tema_vacio():
    acc = TOPIC['Redes Sociales'][0]
    head = f'''<header class="ah" data-site-nav-tone="dark">
  <div class="w">
    {crumbs(['Inicio', 'Blog', 'Temas', 'Marketing Digital', 'Redes Sociales'])}
    <div class="ah__g">
      <div>
        <p class="eyb eyb--d"><span class="eyb__bar" style="background: {acc};"></span>Tema</p>
        <h1 class="idea ah__t" style="color: {acc};">Redes Sociales</h1>
        <p class="ah__d">Todavía no hay publicaciones en este tema. Mientras tanto, Marketing Digital reúne lo más cercano.</p>
      </div>
      <div class="ah__side">
        <p class="ah__l" style="border-top: 0; padding-top: 0;">El tema que lo contiene</p>
        <a href="#" class="nl nl--dark live" style="font-size: 20px;"><span class="roll"><span class="roll__in"><span>Marketing Digital</span><span aria-hidden="true">Marketing Digital</span></span></span><span class="nl__n">6</span>{ICON['ax']}</a>
      </div>
    </div>
  </div>
</header>'''
    return '\n'.join([head, meanwhile('Mientras tanto'), other_topics('Otros temas del blog.', exclude='Redes Sociales')])


def v_busqueda_vacia():
    sugg = ['Cómo aparecer en ChatGPT', 'Ordenar mi CRM en HubSpot', 'Qué es Loop Marketing', 'Escalar la producción creativa']
    sugg_html = '\n          '.join(f'<a href="#" class="chip chip--d live">{e(s)}</a>' for s in sugg)
    head = f'''<header class="ah" data-site-nav-tone="dark">
  <div class="w">
    {crumbs(['Inicio', 'Blog', 'Búsqueda'])}
    <div class="ah__g" style="align-items: center;">
      <div>
        <p class="eyb eyb--d"><span class="eyb__bar" style="background: #36c8bf;"></span>Búsqueda en el blog</p>
        <h1 class="idea ah__t ah__t--m">Nada sobre «metaverso», todavía.</h1>
        <p class="ah__d">Prueba con otra palabra o con una de las preguntas que más nos hacen.</p>
        {search_form('metaverso', 'Buscar en el blog')}
        <div class="chips" style="margin-top: 20px;">
          {sugg_html}
        </div>
      </div>
      <div class="ah__side" style="align-self: end;">
        <img class="spark" src="/_blob/2def96f284c302de0cf9fa4736ed9d18" alt="El Spark de investigación de Efeonce, con su lupa">
      </div>
    </div>
  </div>
</header>'''
    return '\n'.join([head, meanwhile('Mientras tanto, para empezar'), other_topics('O busca por tema.', eyebrow='Explora por tema')])


VIEWS = [
    ('tema', 'Tema · HubSpot', v_tema, 4300, 4700),
    ('etiqueta', 'Etiqueta · inbound', v_etiqueta, 4100, 4600),
    ('autor', 'Autor · Julio Reyes', v_autor, 4300, 5000),
    ('busqueda', 'Búsqueda · «Inbound»', v_busqueda, 3700, 4600),
    ('tema-vacio', 'Tema vacío · Redes Sociales', v_tema_vacio, 2600, 3300),
    ('busqueda-vacia', 'Búsqueda sin resultados · «metaverso»', v_busqueda_vacia, 2700, 3600),
]

if __name__ == '__main__':
    boards = []
    for slug, title, fn, hd, hm in VIEWS:
        body = fn()
        for mobile, h in [(False, hd), (True, hm)]:
            name = f'Archivo-D-{slug}-{"390" if mobile else "1440"}.dc.html'
            with open(os.path.join(OUT, name), 'w', encoding='utf-8') as f:
                f.write(page(f'Archivo D · {title} · {"390" if mobile else "1440"}', body, mobile, h))
            boards.append((name, title, mobile, h))
    import json
    json.dump(boards, open(os.path.join(HERE, 'd_boards.json'), 'w'), ensure_ascii=False)
    for b in boards:
        print(b[0], os.path.getsize(os.path.join(OUT, b[0])))
