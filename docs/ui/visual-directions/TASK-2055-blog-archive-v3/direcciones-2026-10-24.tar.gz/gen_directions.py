#!/usr/bin/env python3
"""Genera las tres direcciones del «Archivo del blog» (TASK-2055) para el canvas «Portada Blog Efeonce».

Reutiliza el CSS literal del tablero Portada-v3 (base, riel, archivo, botones, chips, segmentado, buscador con haz)
y datos reales del tema HubSpot leídos de efeoncepro.com el 2026-10-24.
"""
import html
import os

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(os.path.dirname(HERE), 'artifact-files', 'd0b47eaf-e9d9-406a-b453-d88c2ddd62fd')
CSS_LINES = open(os.path.join(HERE, 'portada.css'), encoding='utf-8').read().split('\n')


def css_range(a, b):
    return '\n'.join(CSS_LINES[a - 1:b])


# Literal CSS from Portada-v3 (line numbers in portada.css): base, riel, archivo, sres/spin, haz del buscador,
# sistema de botones/chips/segmentado/flechas, haz que recorre el borde.
BASE_CSS = '\n'.join([css_range(1, 14), css_range(77, 89), css_range(101, 110), css_range(117, 129),
                      css_range(135, 228), css_range(322, 335)])

ARCHIVE_CSS = r"""
/* ── Archivo del blog (TASK-2055): piezas nuevas, todas con valores de la portada ── */
.crumb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:0;padding:0;list-style:none;font-size:14px;color:#6d6777}
.crumb li{display:inline-flex;align-items:center;gap:8px}
.crumb li+li::before{content:"/";opacity:.5}
.crumb a{color:inherit;text-decoration:none;border-radius:6px}
.crumb a:hover{color:#023c70}
.crumb--dark{color:#cfe4fa}.crumb--dark a:hover{color:#ffffff}
.crumb [aria-current]{color:#023c70;font-weight:500}.crumb--dark [aria-current]{color:#ffffff}
.eyb{display:flex;align-items:center;gap:10px;margin:0;font-size:14px;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:#6d6777}
.eyb__bar{width:28px;height:5px;border-radius:3px}
:is(.v3,.m3) .chip.is-on{background-color:#023c70;border-color:#023c70;color:#ffffff}
.chip__n{font-weight:400;opacity:.75;font-variant-numeric:tabular-nums}
.fbar{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:16px 32px}
.fbar__g{display:flex;flex-wrap:wrap;align-items:center;gap:10px}
.fbar__l{font-size:13px;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:#6d6777;margin-right:6px}
.arch-row--x{grid-template-columns:110px minmax(0,1fr) 200px}
.arch-k__m{color:#6d6777}
.pager{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:0;padding:0;list-style:none}
.pg{display:inline-grid;place-items:center;min-width:48px;height:48px;padding:0 6px;border-radius:999px;border:1px solid rgba(2,60,112,.24);color:#023c70;font-size:15px;font-weight:600;text-decoration:none;font-variant-numeric:tabular-nums;transition:background-color 150ms,border-color 150ms}
.pg[aria-current="page"]{background:#023c70;border-color:#023c70;color:#ffffff}
.pg:focus-visible{outline:2px solid #023c70;outline-offset:3px}
@media (hover:hover){.pg:not([aria-current]):hover{border-color:#023c70;background:#ffffff}}
.stat{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));margin:0;border-top:1px solid rgba(2,60,112,.14)}
.stat div{display:flex;flex-direction:column;gap:8px;padding:22px 0 0 20px;border-left:1px solid rgba(2,60,112,.14)}
.stat div:first-child{padding-left:0;border-left:0}
.stat dt{order:2;font-size:14px;font-weight:500;color:#6d6777}
.stat dd{order:1;margin:0;font-family:'Bricolage Grotesque',sans-serif;font-size:56px;line-height:1;font-weight:760;letter-spacing:-.03em;font-variant-numeric:tabular-nums}
.lab2{display:flex;flex-direction:column;gap:6px;text-decoration:none;color:#ffffff;border-radius:12px;padding:8px 4px}
.lab2 .nm{font-family:'Bricolage Grotesque',sans-serif;font-size:28px;line-height:1;font-weight:700;letter-spacing:-.02em;transition:color 200ms cubic-bezier(0.4,0,0.2,1)}
.lab2 .ct{font-size:14px;color:#cfe4fa}
.lab2 .bar{width:40px;height:3px;border-radius:2px}
.lab2:focus-visible{outline:2px solid #36c8bf;outline-offset:2px}
@media (hover:hover){.lab2:hover .nm{color:var(--acc)}}
.gcard{position:relative;display:flex;flex-direction:column;min-height:560px;border-radius:32px;overflow:hidden;text-decoration:none;transition:transform 300ms cubic-bezier(0.2,0,0,1)}
.gcard img{transition:transform 700ms cubic-bezier(0.2,0,0,1)}
.gcard:focus-visible{outline:2px solid #023c70;outline-offset:4px}
.gcard:active{transform:scale(.98)}
@media (hover:hover){.gcard:hover{transform:translateY(-6px)}.gcard:hover img{transform:scale(1.04)}.gcard:hover .card__a{opacity:1;transform:none}}
.gcard__k{display:flex;align-items:center;gap:10px;font-size:14px}
.gcard__k > span:first-child{width:28px;height:5px;border-radius:3px;flex:none}
.sf__scope{display:inline-flex;align-items:center;gap:8px;height:40px;padding:0 8px 0 16px;border-radius:999px;background:rgba(2,60,112,.08);color:#023c70;font-size:15px;font-weight:600;white-space:nowrap;flex:none}
.sf__x{display:grid;place-items:center;width:28px;height:28px;border-radius:999px}
@media (hover:hover){.sf__x:hover{background:rgba(2,60,112,.12)}}
.sf__x:focus-visible{outline:2px solid #023c70;outline-offset:2px}
@media (prefers-reduced-motion:reduce){.gcard,.gcard img,.pg,.lab2 .nm{transition:none}.gcard:hover,.gcard:hover img{transform:none}}
:is(.v3,.m3) .chip.chip--dark{border-color:rgba(207,228,250,.32);color:#ffffff}
@media (hover:hover){:is(.v3,.m3) .chip.chip--dark:hover{border-color:#ffffff;background-color:rgba(255,255,255,.08)}}
.chip--dark:focus-visible{outline:2px solid #36c8bf;outline-offset:3px}
@media (max-width:767px){.w{padding:0 20px}}
"""

ARROW = ('<svg class="arch-a" width="18" height="18" viewBox="0 0 24 24" aria-hidden="true"><g fill="none" stroke="currentColor" '
         'stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5"/><path d="M14 7l5 5l-5 5"/></g></svg>')
CARD_ARROW = ('<svg class="card__a" viewBox="0 0 24 24" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="2" '
              'stroke-linecap="round" stroke-linejoin="round"><path d="M7 17L17 7"/><path d="M8 7h9v9"/></g></svg>')
AX = ('<svg class="ax" width="20" height="20" viewBox="0 0 24 24" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="2" '
      'stroke-linecap="round" stroke-linejoin="round"><path class="ax__s" pathLength="1" d="M19 12H5"/><path class="ax__h" d="M14 7l5 5l-5 5"/></g></svg>')
SEARCH_ICON = ('<svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="1.6" '
               'stroke-linecap="round" stroke-linejoin="round"><path d="M4 10a6 6 0 1 0 12 0a6 6 0 1 0 -12 0"/><path d="M20 20l-5.6 -5.6"/></g></svg>')

HUB = {'name': 'HubSpot', 'accent': '#e86bd0', 'deep': '#8e1b82', 'n': 12, 'share': 27, 'total': 44}

# Real posts in /category/hubspot/ (efeoncepro.com, 2026-10-24). Minutes: 200 words/min, as EO_CM_Util::reading_minutes.
POSTS = [
    ('17 jul', '2026', 'Caso', 18, '¿Qué necesita una IA para atender bien a tus clientes? Lo que aprendimos diseñando el Customer Agent de ANAM', '99eaef2d43c6f807676e064585ec1c4d', 'wide'),
    ('17 jul', '2026', 'Caso', 13, 'Un dashboard no arregla un proceso comercial: cómo construimos paneles confiables en HubSpot para ANAM', '5b2a61d9ed0512bff4b3e78fe1cd5a02', 'wide'),
    ('18 sep', '2025', 'Guía', 21, 'Cómo ejecutar Loop Marketing en tu empresa con las innovaciones de HubSpot 2025', '5d056872f172292650ec093028e68c08', 'sq'),
    ('26 nov', '2024', 'Artículo', 9, 'De Excel a HubSpot en 5 Días: Organiza, Automatiza y Escala tus Ventas', '7134fd8c6f379f6b08f6cd7dfd4e5618', 'sq'),
    ('24 nov', '2024', 'Guía', 15, 'Crea un Pipeline de Ventas que Convierte: Guía Paso a Paso', '2f948a4576a452fc2898459dd3ba7250', 'sq'),
    ('24 nov', '2024', 'Artículo', 6, '5 Pasos para transformar tu CRM en el motor de crecimiento de tu Negocio', '9c8246b19b15971c4674e6b9d6376d0a', 'sq'),
    ('20 nov', '2024', 'Guía', 5, 'Cómo crear formularios con validación de RUT chileno en minutos', '83d1f33a3e289b8a8514331180a51989', 'sq'),
    ('21 oct', '2024', 'Novedad', 5, '¡Efeonce + Truora: La Alianza que Llevará tu Negocio a Otro Nivel!', '84462fa43280743e1f15efeddb6a54dd', 'sq'),
    ('20 oct', '2024', 'Novedad', 11, 'Efeonce es HubSpot Solutions Partner: Potencia tu Crecimiento', '2626133e1a43ce8d03fc629105ff75e4', 'sq'),
    ('17 ago', '2024', 'Artículo', 21, 'HubSpot y el Desafío del Onboarding: Estrategias para un Inicio Exitoso', '2556f2b0078cb8d19178913003d0ae62', 'sq'),
    ('13 ago', '2024', 'Guía', 10, 'Cómo Rastrear y Medir Formularios de HubSpot en GA4: Guía Paso a Paso', '559683fe4d86e916f28e1d7828f0149d', 'sq'),
    ('11 ago', '2024', 'Artículo', 18, 'HubSpot: Potenciando Marketing y Ventas para un Crecimiento Sostenible', '055d6ba08979a5f6a71074ab3bc103c6', 'sq'),
]

FORMATS = [('Todos', 12, True), ('Artículos', 4, False), ('Guías', 4, False), ('Casos', 2, False), ('Novedades', 2, False)]

# Other topics (live counts 2026-10-24) with the accent used by the home orbit (EO_CM_Util topic palette).
OTHER_TOPICS = [('AEO', 4, '#0375db'), ('Inteligencia Artificial', 2, '#36c8bf'), ('Loop Marketing', 5, '#36c8bf'),
                ('Diseño', 2, '#ff6500'), ('Growth', 1, '#36c8bf'), ('Inbound Marketing', 10, '#36c8bf'),
                ('SEO', 2, '#0375db'), ('Novedades Efeonce', 2, '#cfe4fa'), ('Glitch', 10, '#6ec207')]

PAGE_SIZE = 10


def e(s):
    return html.escape(s, quote=True)


def head(title):
    return f'''<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>{e(title)}</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
<helmet>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="anonymous">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,300..800&amp;family=Poppins:ital,wght@0,300;0,400;0,500;0,600;1,400&amp;display=swap">
<style>
{BASE_CSS}
{ARCHIVE_CSS}
</style>
</helmet>
'''


def tail(h):
    return f'''</x-dc>
<script type="text/x-dc" data-dc-script data-props='{{"$preview":{{"width":1440,"height":{h}}}}}'>
class Component extends DCLogic {{
  renderVals() {{ return {{}}; }}
}}
</script>
</body>
</html>
'''


def nav_stub():
    # The canonical site header (AXIS island, TASK-2042) is inherited unchanged; drawn here only to hold its place.
    return '''<div aria-hidden="true" style="position: absolute; top: 12px; left: 50%; transform: translateX(-50%); z-index: 5; width: min(1180px, calc(100% - 32px)); height: 62px; display: flex; align-items: center; justify-content: space-between; gap: 16px; padding: 0 10px 0 28px; border-radius: 999px; background: #ffffff; box-shadow: 0 10px 30px rgba(0,26,51,.08);">
  <img src="/_blob/83245a45d586a61636aa1ac2deff2ab6" alt="" style="height: 26px; width: auto; display: block;">
  <span style="font-size: 13px; color: #6d6777;">Menú global del sitio (heredado sin cambios)</span>
  <span style="display: inline-flex; align-items: center; height: 44px; padding: 0 20px; border-radius: 999px; background: #001a33; color: #ffffff; font-size: 15px; font-weight: 600;">Agenda tu diagnóstico</span>
</div>
'''


def footer_stub():
    return '''<footer style="background: #f7f8f6; padding: 64px 0 72px;">
  <div class="w" style="display: flex; flex-direction: column; align-items: center; gap: 14px;">
    <img src="/_blob/83245a45d586a61636aa1ac2deff2ab6" alt="Efeonce" style="width: 200px; height: auto;">
    <p style="margin: 0; font-size: 14px; color: #6d6777;">Pie global del sitio, heredado sin cambios.</p>
  </div>
</footer>
'''


def crumbs(dark=False):
    cls = 'crumb crumb--dark' if dark else 'crumb'
    return f'''<nav aria-label="Migas de pan"><ol class="{cls}"><li><a href="#">Inicio</a></li><li><a href="#">Blog</a></li><li><a href="#">Temas</a></li><li><span aria-current="page">HubSpot</span></li></ol></nav>'''


def format_chips():
    out = []
    for label, n, on in FORMATS:
        cls = 'chip is-on' if on else 'chip'
        out.append(f'<button type="button" class="{cls}" aria-pressed="{"true" if on else "false"}">{e(label)} <span class="chip__n">{n}</span></button>')
    return '\n      '.join(out)


def arch_row(p, show_year=False):
    d, y, fmt, mins, title, _img, _shape = p
    date = f'{d} {y}' if show_year else d
    return f'''<a href="#" class="lnk arch-row arch-row--x">
            <span style="font-size: 14px; color: #6d6777;">{e(date)}</span>
            <span class="idea u" style="font-size: 30px; line-height: 1.08; font-weight: 640; letter-spacing: -0.025em;">{e(title)}</span>
            <span class="arch-k" style="font-size: 14px;"><span>{e(fmt)} <span class="arch-k__m">· {mins} min</span></span>{ARROW}</span>
          </a>'''


def pager(note):
    return f'''<div style="display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 24px; margin-top: 40px;">
        <span style="font-size: 14px; color: #6d6777;">{e(note)}</span>
        <nav aria-label="Páginas del tema"><ul class="pager"><li><a href="#" class="pg" aria-current="page">1</a></li><li><a href="#" class="pg">2</a></li><li><a href="#" class="nl nl--light live" style="margin: 0 0 0 8px;"><span class="roll"><span class="roll__in"><span>Siguiente</span><span aria-hidden="true">Siguiente</span></span></span>{AX}</a></li></ul></nav>
      </div>'''


def other_topics():
    labs = []
    for name, n, acc in OTHER_TOPICS:
        unit = 'publicación' if n == 1 else 'publicaciones'
        labs.append(f'<a href="#" class="lab2" style="--acc: {acc};"><span class="nm">{e(name)}</span><span class="ct">{n} {unit}</span><span class="bar" style="background: {acc};"></span></a>')
    labs_html = '\n        '.join(labs)
    return f'''<section data-site-nav-tone="dark" aria-labelledby="otros-h" style="background: #001a33; color: #ffffff; padding: 112px 0 120px;">
  <div class="w">
    <div style="display: flex; flex-wrap: wrap; align-items: flex-end; justify-content: space-between; gap: 24px;">
      <div>
        <p class="eyb" style="color: #cfe4fa;">Explora por tema</p>
        <h2 id="otros-h" class="idea" style="margin: 16px 0 0; font-size: 72px; line-height: 0.9; font-weight: 760; letter-spacing: -0.05em;">Otros temas del blog.</h2>
      </div>
      <a href="#" class="nl nl--dark live"><span class="roll"><span class="roll__in"><span>Todo el archivo</span><span aria-hidden="true">Todo el archivo</span></span></span><span class="nl__n">44</span>{AX}</a>
    </div>
    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(min(240px, 100%), 1fr)); gap: 40px 32px; margin-top: 64px;">
        {labs_html}
    </div>
  </div>
</section>
'''


# ───────────────────────── Dirección A · Índice ─────────────────────────
def direction_a():
    page = POSTS[:PAGE_SIZE]
    groups = []
    for year in ['2026', '2025', '2024']:
        rows = [p for p in page if p[1] == year]
        if not rows:
            continue
        total_year = len([p for p in POSTS if p[1] == year])
        unit = 'publicación' if total_year == 1 else 'publicaciones'
        rows_html = '\n          '.join(arch_row(p) for p in rows)
        groups.append(f'''<div class="arch" style="padding-top: 56px;">
      <div style="position: sticky; top: 112px; align-self: start;">
        <p class="idea" style="margin: 0; font-size: 120px; line-height: 0.82; font-weight: 760; letter-spacing: -0.06em;">{year}</p>
        <p style="margin: 16px 0 0; font-size: 14px; color: #6d6777;">{total_year} {unit} en HubSpot</p>
      </div>
      <div style="border-bottom: 1px solid rgba(2,60,112,0.14);">
          {rows_html}
      </div>
    </div>''')
    groups_html = '\n    '.join(groups)
    body = f'''<div class="v3" style="position: relative; background: #ffffff; color: #023c70;">
{nav_stub()}
<header data-site-nav-tone="light" style="background: #f7f8f6; padding: 168px 0 96px;">
  <div class="w">
    {crumbs()}
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(min(480px, 100%), 1fr)); gap: 48px 96px; align-items: end; margin-top: 56px;">
      <div>
        <p class="eyb"><span class="eyb__bar" style="background: {HUB['deep']};"></span>Tema</p>
        <h1 class="idea" style="margin: 16px 0 0; font-size: 184px; line-height: 0.82; font-weight: 760; letter-spacing: -0.06em;">HubSpot</h1>
        <p style="margin: 40px 0 0; max-width: 620px; font-size: 20px; line-height: 1.55;">[Descripción editorial del tema: una o dos frases que escribe el equipo en WordPress. Sin ella, la página queda fuera de Google.]</p>
      </div>
      <dl class="stat">
        <div><dt>publicaciones</dt><dd>12</dd></div>
        <div><dt>formatos</dt><dd>4</dd></div>
        <div><dt>lo último</dt><dd>17 jul</dd></div>
      </dl>
    </div>
  </div>
</header>
<section aria-label="Filtros" style="background: #ffffff; padding: 32px 0; border-bottom: 1px solid rgba(2,60,112,0.14);">
  <div class="w fbar">
    <div class="fbar__g" role="group" aria-label="Formato"><span class="fbar__l">Formato</span>
      {format_chips()}
    </div>
    <span style="font-size: 14px; color: #6d6777;">Más recientes primero</span>
  </div>
</section>
<section data-site-nav-tone="light" aria-label="Publicaciones de HubSpot" style="background: #ffffff; padding: 40px 0 128px;">
  <div class="w">
    {groups_html}
    {pager('Mostrando 1–10 de 12 publicaciones')}
  </div>
</section>
{other_topics()}
{footer_stub()}
</div>
'''
    return head('Archivo · A · Índice') + body + tail(3700)


# ───────────────────────── Dirección B · Órbita ─────────────────────────
def gcard(p, featured=False):
    d, y, fmt, mins, title, img, shape = p
    if featured:
        return f'''<a href="#" class="gcard" style="grid-column: span 2; background: #001a33; color: #ffffff; min-height: 560px;">{CARD_ARROW}
        <img src="/_blob/{img}" alt="" style="position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover;">
        <span aria-hidden="true" style="position: absolute; inset: 0; background: linear-gradient(180deg, rgba(0,26,51,0) 35%, rgba(0,26,51,.92) 100%);"></span>
        <span style="position: relative; margin-top: auto; padding: 40px; display: flex; flex-direction: column; gap: 16px;">
          <span class="gcard__k" style="color: #cfe4fa;"><span style="background: {HUB['accent']};"></span>{e(fmt)} · {d} {y}</span>
          <span class="idea u" style="font-size: 48px; line-height: 0.98; font-weight: 760; letter-spacing: -0.04em; max-width: 760px;">{e(title)}</span>
          <span style="font-size: 14px; color: #cfe4fa;">{mins} min de lectura</span>
        </span>
      </a>'''
    if fmt == 'Guía':
        return f'''<a href="#" class="gcard" style="background: #023c70; color: #ffffff; padding: 36px; justify-content: space-between;">{CARD_ARROW}
        <span class="gcard__k" style="color: #cfe4fa;"><span style="background: #36c8bf;"></span>Guía · {d} {y}</span>
        <span class="idea" style="font-size: 200px; line-height: 0.8; font-weight: 760; letter-spacing: -0.07em;">{mins}<span style="font-size: 28px; letter-spacing: 0; font-weight: 500;"> min</span></span>
        <span class="idea u" style="font-size: 30px; line-height: 1.02; font-weight: 740; letter-spacing: -0.03em;">{e(title)}</span>
      </a>'''
    if fmt == 'Novedad':
        return f'''<a href="#" class="gcard" style="background: #091951; color: #ffffff; padding: 36px; justify-content: space-between;">{CARD_ARROW}
        <span style="font-size: 13px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: #cfe4fa;">Novedad · {d} {y}</span>
        <span class="idea u" style="font-size: 44px; line-height: 0.95; font-weight: 760; letter-spacing: -0.045em;">{e(title)}</span>
        <span style="font-size: 14px; color: #cfe4fa;">{mins} min de lectura</span>
      </a>'''
    return f'''<a href="#" class="gcard" style="background: #001a33; color: #ffffff;">{CARD_ARROW}
        <img src="/_blob/{img}" alt="" style="width: 100%; height: 280px; object-fit: cover; display: block;">
        <span style="padding: 32px; display: flex; flex-direction: column; flex: 1;">
          <span class="gcard__k" style="color: #cfe4fa;"><span style="background: {HUB['accent']};"></span>{e(fmt)} · {d} {y}</span>
          <span class="idea u" style="margin-top: 16px; font-size: 30px; line-height: 1; font-weight: 760; letter-spacing: -0.035em;">{e(title)}</span>
          <span style="margin-top: auto; padding-top: 24px; font-size: 14px; color: #cfe4fa;">{mins} min de lectura</span>
        </span>
      </a>'''


def direction_b():
    page = POSTS[:PAGE_SIZE]
    cards = [gcard(page[0], featured=True)] + [gcard(p) for p in page[1:]]
    cards_html = '\n      '.join(cards)
    # Orbit measure: r = 190 on a 440 box, 27 % of the circumference, starting at 12 o'clock (like the home orbit).
    import math
    r, cx, cy = 190, 220, 220
    a = 2 * math.pi * HUB['share'] / 100
    ex, ey = cx + r * math.sin(a), cy - r * math.cos(a)
    large = 1 if HUB['share'] > 50 else 0
    arc = f'M {cx} {cy - r} A {r} {r} 0 {large} 1 {ex:.2f} {ey:.2f}'
    body = f'''<div class="v3" style="position: relative; background: #f7f8f6; color: #023c70;">
{nav_stub()}
<header data-site-nav-tone="dark" style="background: #001a33; color: #ffffff; padding: 168px 0 104px; overflow: hidden;">
  <div class="w">
    {crumbs(dark=True)}
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(min(520px, 100%), 1fr)); gap: 48px 72px; align-items: center; margin-top: 48px;">
      <div>
        <p class="eyb" style="color: #cfe4fa;"><span class="eyb__bar" style="background: {HUB['accent']};"></span>Tema</p>
        <h1 class="idea" style="margin: 16px 0 0; font-size: 184px; line-height: 0.82; font-weight: 760; letter-spacing: -0.06em; color: {HUB['accent']};">HubSpot</h1>
        <p style="margin: 40px 0 0; max-width: 560px; font-size: 20px; line-height: 1.55; color: #cfe4fa;">[Descripción editorial del tema: una o dos frases que escribe el equipo en WordPress. Sin ella, la página queda fuera de Google.]</p>
      </div>
      <div style="justify-self: end; width: 100%; max-width: 520px; display: flex; flex-direction: column; gap: 32px;">
        <p style="margin: 0; display: flex; align-items: baseline; gap: 14px;"><span class="idea" style="font-size: 240px; line-height: 0.8; font-weight: 760; letter-spacing: -0.07em; color: #ffffff;">12</span><span style="font-size: 28px; font-weight: 500; color: #ffffff;">publicaciones</span></p>
        <p style="margin: 0; padding-top: 24px; border-top: 1px solid rgba(207,228,250,.18); font-size: 16px; color: #cfe4fa;">Lo último, 17 jul 2026</p>
        <div class="fbar__g" role="group" aria-label="Filtrar por formato">
          <a href="#" class="chip chip--dark">Artículos <span class="chip__n">4</span></a>
          <a href="#" class="chip chip--dark">Guías <span class="chip__n">4</span></a>
          <a href="#" class="chip chip--dark">Casos <span class="chip__n">2</span></a>
          <a href="#" class="chip chip--dark">Novedades <span class="chip__n">2</span></a>
        </div>
      </div>
    </div>
  </div>
</header>
<section aria-label="Filtros" style="padding: 40px 0 0;">
  <div class="w fbar">
    <div class="fbar__g" role="group" aria-label="Formato"><span class="fbar__l">Formato</span>
      {format_chips()}
    </div>
    <span style="font-size: 14px; color: #6d6777;">Mostrando 1–10 de 12</span>
  </div>
</section>
<section data-site-nav-tone="light" aria-label="Publicaciones de HubSpot" style="padding: 40px 0 128px;">
  <div class="w">
    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(min(380px, 100%), 1fr)); gap: 20px;">
      {cards_html}
    </div>
    <div style="display: flex; justify-content: center; margin-top: 64px;">
      <nav aria-label="Páginas del tema"><ul class="pager"><li><a href="#" class="pg" aria-current="page">1</a></li><li><a href="#" class="pg">2</a></li><li><a href="#" class="nl nl--light live" style="margin: 0 0 0 8px;"><span class="roll"><span class="roll__in"><span>Siguiente</span><span aria-hidden="true">Siguiente</span></span></span>{AX}</a></li></ul></nav>
    </div>
  </div>
</section>
{other_topics()}
{footer_stub()}
</div>
'''
    return head('Archivo · B · Órbita') + body + tail(4300)


# ───────────────────────── Dirección C · Buscador ─────────────────────────
def rail_card(p):
    d, y, fmt, mins, title, img, shape = p
    if fmt == 'Guía':
        return gcard(p)
    return f'''<a href="#" class="gcard" style="background: #001a33; color: #ffffff; min-height: 600px;">{CARD_ARROW}
        <img src="/_blob/{img}" alt="" style="width: 100%; height: 330px; object-fit: cover; display: block;">
        <span style="padding: 32px; display: flex; flex-direction: column; flex: 1;">
          <span class="gcard__k" style="color: #cfe4fa;"><span style="background: {HUB['accent']};"></span>{e(fmt)} · HubSpot</span>
          <span class="idea u" style="margin-top: 16px; font-size: 32px; line-height: 1; font-weight: 760; letter-spacing: -0.035em;">{e(title)}</span>
          <span style="margin-top: auto; padding-top: 24px; font-size: 14px; color: #cfe4fa;">{mins} min de lectura · {d} {y}</span>
        </span>
      </a>'''


def direction_c():
    lead = POSTS[:3]
    rest = POSTS[3:PAGE_SIZE + 3 - 3]
    rest = POSTS[3:12]
    rows_html = '\n          '.join(arch_row(p, show_year=True) for p in rest)
    cards_html = '\n      '.join(rail_card(p) for p in lead)
    body = f'''<div class="v3" style="position: relative; background: #ffffff; color: #023c70;">
{nav_stub()}
<header data-site-nav-tone="light" style="background: #f7f8f6; padding: 168px 0 112px; overflow: hidden;">
  <div class="w">
    {crumbs()}
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(min(520px, 100%), 1fr)); gap: 48px 72px; align-items: center; margin-top: 48px;">
      <div>
        <p class="eyb"><span class="eyb__bar" style="background: {HUB['deep']};"></span>Tema</p>
        <h1 class="idea" style="margin: 16px 0 0; font-size: 120px; line-height: 0.86; font-weight: 760; letter-spacing: -0.05em;">HubSpot</h1>
        <p style="margin: 28px 0 0; max-width: 600px; font-size: 20px; line-height: 1.55;">[Descripción editorial del tema: una o dos frases que escribe el equipo en WordPress. Sin ella, la página queda fuera de Google.]</p>
        <form role="search" action="#" class="sf" style="display: flex; align-items: center; gap: 12px; margin-top: 40px; height: 84px; padding: 0 10px 0 16px; border-radius: 999px; background: #ffffff; border: 1.5px solid #023c70;">
          <svg class="beamsvg" aria-hidden="true" focusable="false"><rect class="bm-t" pathLength="100"/><rect class="bm-m" pathLength="100"/><rect class="bm-h" pathLength="100"/></svg>
          <span class="sf__scope">En HubSpot<button type="button" class="sf__x" aria-label="Buscar en todo el blog"><svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></button></span>
          <label for="c-q" class="sr">Buscar dentro de HubSpot</label>
          <input id="c-q" type="search" placeholder="Busca dentro de HubSpot" style="flex: 1; min-width: 0; height: 60px; border: 0; background: transparent; color: #023c70; font: 400 20px 'Poppins', sans-serif;">
          <button type="submit" class="ab ab--navy live" style="min-height: 56px; padding: 0 1.25rem 0 1.5rem;"><span class="ab__c" style="display: inline-flex; align-items: center; gap: .5rem;"><span class="roll"><span class="roll__in"><span>Buscar</span><span aria-hidden="true">Buscar</span></span></span>{SEARCH_ICON}</span></button>
        </form>
        <div class="fbar__g" role="group" aria-label="Formato" style="margin-top: 24px;">
      {format_chips()}
        </div>
      </div>
      <div class="gcard" style="background: #ffffff; border: 1px solid rgba(2,60,112,0.12); padding: 36px; justify-content: space-between; min-height: 520px; max-width: 440px; justify-self: end; width: 100%;">
        <span class="gcard__k"><span style="background: {HUB['deep']};"></span>HubSpot en el blog</span>
        <span class="idea" style="font-size: 240px; line-height: 0.8; font-weight: 760; letter-spacing: -0.07em;">12<span style="font-size: 28px; letter-spacing: 0; font-weight: 500;"> publicaciones</span></span>
        <span class="idea" style="font-size: 32px; line-height: 1.02; font-weight: 740; letter-spacing: -0.03em;">Lo último, 17 jul 2026.</span>
      </div>
    </div>
  </div>
</header>
<section data-site-nav-tone="light" aria-labelledby="c-rec" style="background: #ffffff; padding: 120px 0 0;">
  <div class="w">
    <h2 id="c-rec" class="idea" style="margin: 0 0 48px; font-size: 72px; line-height: 0.9; font-weight: 760; letter-spacing: -0.05em;">Lo más reciente.</h2>
    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(min(380px, 100%), 1fr)); gap: 20px;">
      {cards_html}
    </div>
  </div>
</section>
<section data-site-nav-tone="light" aria-labelledby="c-all" style="background: #ffffff; padding: 120px 0 128px;">
  <div class="w arch">
    <div style="position: sticky; top: 112px; align-self: start;">
      <p class="eyb">Todo HubSpot · 12 publicaciones</p>
      <h2 id="c-all" class="idea" style="margin: 16px 0 0; font-size: 96px; line-height: 0.88; font-weight: 760; letter-spacing: -0.05em;">El archivo.</h2>
    </div>
    <div>
      <div style="border-bottom: 1px solid rgba(2,60,112,0.14);">
          {rows_html}
      </div>
      {pager('Mostrando 4–12 de 12 publicaciones')}
    </div>
  </div>
</section>
{other_topics()}
{footer_stub()}
</div>
'''
    return head('Archivo · C · Buscador') + body + tail(4100)


if __name__ == '__main__':
    out = os.path.join(ROOT, 'project')
    for name, fn in [('Archivo-A.dc.html', direction_a), ('Archivo-B.dc.html', direction_b), ('Archivo-C.dc.html', direction_c)]:
        with open(os.path.join(out, name), 'w', encoding='utf-8') as f:
            f.write(fn())
        print(name, os.path.getsize(os.path.join(out, name)))
