export const GLOBE_API_VERSION = 'v1' as const;

export const GLOBE_CAPABILITIES = [
  'globe.studio.access',
  'globe.project.read',
  'globe.run.prepare',
  'globe.run.approve',
  'globe.delivery.release',
] as const;

export type GlobeCapability = (typeof GLOBE_CAPABILITIES)[number];

/**
 * Trusted principal context produced by Globe authentication middleware.
 * It is never accepted as a caller-provided request body or header.
 */
export type AuthenticatedPrincipalV1 = Readonly<{
  schemaVersion: '1';
  principalId: string;
  principalType: 'human' | 'service';
  issuer: 'greenhouse' | 'google-cloud';
  subject: string;
  authenticationMethod: 'greenhouse-session' | 'google-id-token';
  capabilities: readonly GlobeCapability[];
}>;

export type GlobeApiErrorCode =
  | 'authentication_required'
  | 'access_denied'
  | 'invalid_request'
  | 'not_found'
  | 'conflict'
  | 'rate_limited'
  | 'dependency_unavailable'
  | 'internal_error';

export type GlobeApiErrorV1 = Readonly<{
  schemaVersion: '1';
  error: Readonly<{
    code: GlobeApiErrorCode;
    message: string;
    retryable: boolean;
    correlationId: string;
  }>;
}>;

export type GlobeHealthV1 = Readonly<{
  schemaVersion: '1';
  service: 'efeonce-globe';
  apiVersion: typeof GLOBE_API_VERSION;
  status: 'ok' | 'degraded';
  checkedAt: string;
}>;

export type ArtifactManifestV1 = Readonly<{
  schemaVersion: '1';
  artifactId: string;
  workspaceId: string;
  compositionId: string;
  runId: string;
  mediaType: 'image' | 'video' | 'audio' | 'document' | 'vector';
  objectUri: string;
  sha256: string;
  reviewStatus: 'candidate' | 'approved' | 'rejected';
  createdAt: string;
}>;

export type CommandEnvelope<TPayload> = Readonly<{
  command: string;
  apiVersion: typeof GLOBE_API_VERSION;
  workspaceId: string;
  actorId: string;
  idempotencyKey: string;
  correlationId: string;
  payload: TPayload;
}>;
