import assert from 'node:assert/strict';
import test from 'node:test';

import { GLOBE_CAPABILITIES } from './index.ts';

test('keeps Globe authorization namespaced and role-independent', () => {
  assert.equal(GLOBE_CAPABILITIES.length, 5);
  assert.ok(GLOBE_CAPABILITIES.every(capability => capability.startsWith('globe.')));
  assert.ok(GLOBE_CAPABILITIES.every(capability => !capability.includes('admin')));
});
