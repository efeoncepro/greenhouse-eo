import assert from 'node:assert/strict';
import test from 'node:test';
import { GLOBE_ASSET_PROVENANCE_COMMANDS, GLOBE_ASSET_PROVENANCE_READERS } from '@efeonce-globe/contracts/asset-provenance';
import { GLOBE_GENERATED_RIGHTS_POLICY_COMMANDS } from '@efeonce-globe/contracts/asset-governance';
import { GLOBE_PRODUCTION_ROUTING_COMMANDS, GLOBE_PRODUCTION_ROUTING_READERS } from '@efeonce-globe/contracts/production-routing-control';
import { GLOBE_GOVERNED_RUN_COMMANDS, GLOBE_GOVERNED_RUN_READERS, GLOBE_TENANCY_COMMANDS } from '@efeonce-globe/contracts';

import { GlobeClient, GlobeSdkError, createCallbackAuth } from './index.ts';

test('calls Globe with correlation context and Cloud Run auth without exposing an actor header', async () => {
  let captured: Request | undefined;
  const client = new GlobeClient({
    baseUrl: 'https://globe-api-abc.run.app',
    auth: createCallbackAuth(async request => {
      assert.equal(request.audience, 'https://globe-api-abc.run.app');
      return { kind: 'cloud-run-id-token', token: 'signed-id-token' };
    }),
    fetch: async (input, init) => {
      captured = new Request(input, init);
      return Response.json({
        schemaVersion: '1',
        service: 'efeonce-globe',
        apiVersion: 'v1',
        status: 'ok',
        checkedAt: '2026-07-19T12:00:00.000Z',
      });
    },
  });

  const health = await client.health({ correlationId: 'corr_01', workspaceId: 'ws_internal' });

  assert.equal(health.status, 'ok');
  assert.equal(captured?.url, 'https://globe-api-abc.run.app/v1/health');
  assert.equal(captured?.headers.get('authorization'), 'Bearer signed-id-token');
  assert.equal(captured?.headers.get('x-serverless-authorization'), null); // Cloud Run forwards Authorization; X-Serverless it consumes
  assert.equal(captured?.headers.get('x-globe-correlation-id'), 'corr_01');
  assert.equal(captured?.headers.get('x-globe-workspace-id'), 'ws_internal');
  assert.equal(captured?.headers.has('x-globe-actor-id'), false);
});

test('sanitizes non-contract upstream errors', async () => {
  const client = new GlobeClient({
    baseUrl: 'https://globe-api-abc.run.app',
    auth: createCallbackAuth(async () => ({ kind: 'bearer', token: 'opaque' })),
    fetch: async () => new Response('database password leaked', { status: 500 }),
  });

  await assert.rejects(
    client.health({ correlationId: 'corr_02' }),
    (error: unknown) => {
      assert.ok(error instanceof GlobeSdkError);
      assert.equal(error.message, 'globe_request_failed');
      assert.equal(error.code, 'dependency_unavailable');
      assert.equal(error.retryable, true);
      assert.equal(error.message.includes('password'), false);
      return true;
    },
  );
});

test('rejects insecure remote endpoints and header injection', async () => {
  assert.throws(
    () => new GlobeClient({
      baseUrl: 'http://globe.example.com',
      auth: createCallbackAuth(async () => ({ kind: 'bearer', token: 'opaque' })),
    }),
    { message: 'globe_sdk_base_url_insecure' },
  );

  const client = new GlobeClient({
    baseUrl: 'http://localhost:8080',
    auth: createCallbackAuth(async () => ({ kind: 'bearer', token: 'opaque' })),
    fetch: async () => Response.json({}),
  });

  await assert.rejects(
    client.health({ correlationId: 'safe\r\nX-Injected: true' }),
    { message: 'globe_sdk_correlation_id_invalid' },
  );
});

test('uses the canonical command and reader primitives for asynchronous private ingest', async () => {
  const envelopes: unknown[] = [];
  const client = new GlobeClient({
    baseUrl: 'https://globe-api.example.test',
    auth: createCallbackAuth(async () => ({ kind: 'bearer', token: 'opaque' })),
    fetch: async (_input, init) => {
      envelopes.push(JSON.parse(String(init?.body)));
      return Response.json({ schemaVersion: '1', outcome: {}, data: {} });
    },
  });

  await client.completePrivateAssetIngest(
    { ingestSessionId: 'ing-1' },
    { workspaceId: 'workspace-a', idempotencyKey: 'complete-1' },
  );
  await client.getPrivateAssetIngestStatus({ ingestSessionId: 'ing-1' }, { workspaceId: 'workspace-a' });

  assert.equal((envelopes[0] as { command: string }).command, GLOBE_ASSET_PROVENANCE_COMMANDS.completeIngest);
  assert.equal((envelopes[1] as { reader: string }).reader, GLOBE_ASSET_PROVENANCE_READERS.status);
});

test('uses operator-only routing commands/readers without a parallel transport', async () => {
  const envelopes: Array<Record<string, unknown>> = [];
  const client = new GlobeClient({
    baseUrl: 'https://globe-api.example.test',
    auth: createCallbackAuth(async () => ({ kind: 'bearer', token: 'opaque' })),
    fetch: async (_input, init) => {
      envelopes.push(JSON.parse(String(init?.body)) as Record<string, unknown>);
      return Response.json({ schemaVersion: '1', outcome: {}, data: {} });
    },
  });
  const identity = { routeId: 'ref/still/rrss-v1', providerId: 'fal', modelId: 'seedream-5-pro', modelVersion: 'v5-pro' };
  await client.appendProductionRoute({ expectedRevision: 0, binding: { ...identity, endpointId: 'fal.seedream.text-to-image', region: 'us-central1', completionDriver: 'webhook-and-poll', enabled: true } }, { workspaceId: 'workspace-a', idempotencyKey: 'route-1' });
  await client.getProviderCircuit({ providerId: 'fal', endpointId: 'fal.seedream.text-to-image', region: 'us-central1' }, { workspaceId: 'workspace-a' });
  await client.publishGeneratedRightsPolicy({ policyId: 'policy-a', policyVersion: 'v1', routeId: identity.routeId, providerId: identity.providerId, modelId: identity.modelId, modelVersion: identity.modelVersion, appliesTo: 'generated', providerTermsRef: 'legal:fal-terms-v1', providerTermsDigest: `sha256:${'a'.repeat(64)}`, effectiveRestrictions: ['internal-review-only'], validFrom: '2026-07-01T00:00:00Z', expiresAt: '2026-08-01T00:00:00Z' }, { workspaceId: 'workspace-a', idempotencyKey: 'rights-1' });
  assert.equal(envelopes[0]?.command, GLOBE_PRODUCTION_ROUTING_COMMANDS.appendRoute);
  assert.equal(envelopes[1]?.reader, GLOBE_PRODUCTION_ROUTING_READERS.circuit);
  assert.equal(envelopes[2]?.command, GLOBE_GENERATED_RIGHTS_POLICY_COMMANDS.publish);
});

test('uses canonical durable run controls through the shared command and reader transport', async () => {
  const envelopes: Array<Record<string, unknown>> = [];
  const client = new GlobeClient({
    baseUrl: 'https://globe-api.example.test',
    auth: createCallbackAuth(async () => ({ kind: 'bearer', token: 'opaque' })),
    fetch: async (_input, init) => {
      envelopes.push(JSON.parse(String(init?.body)) as Record<string, unknown>);
      return Response.json({ schemaVersion: '1', outcome: {}, data: {} });
    },
  });
  await client.cancelGovernedRun({ runId: 'run-a', expectedRevision: 2, reason: 'operator_request' },
    { workspaceId: 'workspace-a', idempotencyKey: 'cancel-a' });
  await client.listGovernedRuns({ states: ['cancellation_requested'] }, { workspaceId: 'workspace-a' });
  await client.estimateGovernedRunRetry({ runId: 'run-a', expectedRevision: 2, expectedAttempt: 1 }, { workspaceId: 'workspace-a' });
  assert.equal(envelopes[0]?.command, GLOBE_GOVERNED_RUN_COMMANDS.cancel);
  assert.equal(envelopes[1]?.reader, GLOBE_GOVERNED_RUN_READERS.list);
  assert.equal(envelopes[2]?.reader, GLOBE_GOVERNED_RUN_READERS.retryEstimate);
});

test('sends tenancy V2 through the canonical command transport', async () => {
  const envelopes: Array<Record<string, unknown>> = [];
  const client = new GlobeClient({
    baseUrl: 'https://globe-api.example.test',
    auth: createCallbackAuth(async () => ({ kind: 'bearer', token: 'opaque' })),
    fetch: async (_input, init) => {
      envelopes.push(JSON.parse(String(init?.body)) as Record<string, unknown>);
      return Response.json({ schemaVersion: '1', outcome: {} });
    },
  });
  await client.reconcileTenancyProjection({
    snapshot: {
      schemaVersion: '2',
      brokerBindingId: 'greenhouse-org:efeonce',
      bindingState: 'active',
      workspaceRevision: 3,
      reconciliationId: 'reconcile-a',
      issuedAt: '2026-07-23T09:00:00.000Z',
      expiresAt: '2026-07-23T09:15:00.000Z',
      members: [{
        identityIssuer: 'greenhouse',
        identitySubject: 'greenhouse:user:person-a',
        state: 'active',
        memberRevision: 2,
        desiredCapabilities: ['globe.studio.access'],
        expiresAt: '2026-07-23T09:15:00.000Z',
      }],
    },
  }, { workspaceId: 'greenhouse-org:efeonce', idempotencyKey: 'reconcile-a' });
  assert.equal(envelopes[0]?.command, GLOBE_TENANCY_COMMANDS.reconcile);
  assert.equal((envelopes[0]?.payload as { snapshot: { schemaVersion: string } }).snapshot.schemaVersion, '2');
});
