import assert from 'node:assert/strict';
import { createHmac } from 'node:crypto';
import { describe, it } from 'node:test';

import {
  createHmacGlobeUiDelegationV1,
  fingerprintGlobeUiDelegationRequest,
  sha256GlobeUiDelegationBody,
} from './ui-delegation.ts';

const NOW = 1_752_883_200;
const SECRET = '0123456789abcdef0123456789abcdef';
const config = {
  secret: SECRET,
  issuer: 'globe-studio-web',
  audience: 'globe-api-internal',
  caller: 'globe-web-runtime@efeonce-globe.iam.gserviceaccount.com',
} as const;
const request = {
  method: 'POST',
  path: '/v1/commands',
  bodySha256: sha256GlobeUiDelegationBody('{"command":"globe.lab.experiment.prepare"}'),
  capability: 'globe.lab.experiment.prepare',
  correlationId: 'corr-1',
  idempotencyKey: 'idem-1',
} as const;
const mintInput = {
  actorId: 'greenhouse:user:1',
  workspaceId: 'greenhouse-org:efeonce',
  capabilities: ['globe.lab.experiment.run', 'globe.producer.catalog.read'] as const,
  request,
  issuedAtSeconds: NOW,
  ttlSeconds: 30,
  jti: 'delegation-1',
} as const;

describe('HMAC Globe UI delegation V1', () => {
  it('round-trips exact request-bound claims and never carries the secret', () => {
    const signer = createHmacGlobeUiDelegationV1(config);
    const token = signer.mint(mintInput);
    const verified = signer.verify(token, { request, nowSeconds: NOW });

    assert.ok(verified);
    assert.equal(verified.actorId, mintInput.actorId);
    assert.equal(verified.workspaceId, mintInput.workspaceId);
    assert.deepEqual(verified.capabilities, [...mintInput.capabilities].sort());
    assert.equal(verified.surface, 'ui');
    assert.equal(verified.purpose, 'ui');
    assert.equal(verified.fingerprint, fingerprintGlobeUiDelegationRequest(request));
    assert.doesNotMatch(token, new RegExp(SECRET));
  });

  it('is deterministic for equivalent capability sets and method casing', () => {
    const signer = createHmacGlobeUiDelegationV1(config);
    const first = signer.mint(mintInput);
    const second = signer.mint({
      ...mintInput,
      capabilities: [...mintInput.capabilities].reverse(),
      request: { ...request, method: 'post' },
    });
    assert.equal(first, second);
  });

  it('binds method, path, body, capability, correlation and idempotency independently', () => {
    const signer = createHmacGlobeUiDelegationV1(config);
    const token = signer.mint(mintInput);
    const mutations = [
      { ...request, method: 'GET' },
      { ...request, path: '/v1/readers' },
      { ...request, bodySha256: sha256GlobeUiDelegationBody('different') },
      { ...request, capability: 'globe.producer.catalog.list' },
      { ...request, correlationId: 'corr-2' },
      { ...request, idempotencyKey: 'idem-2' },
    ];
    for (const changed of mutations) assert.equal(signer.verify(token, { request: changed, nowSeconds: NOW }), undefined);
  });

  it('rejects the wrong secret, issuer, audience or workload caller', () => {
    const token = createHmacGlobeUiDelegationV1(config).mint(mintInput);
    assert.equal(createHmacGlobeUiDelegationV1({ ...config, secret: `${SECRET}x` }).verify(token, { request, nowSeconds: NOW }), undefined);
    assert.equal(createHmacGlobeUiDelegationV1({ ...config, issuer: 'someone-else' }).verify(token, { request, nowSeconds: NOW }), undefined);
    assert.equal(createHmacGlobeUiDelegationV1({ ...config, audience: 'another-api' }).verify(token, { request, nowSeconds: NOW }), undefined);
    assert.equal(createHmacGlobeUiDelegationV1({ ...config, caller: 'wrong@efeonce-globe.iam.gserviceaccount.com' }).verify(token, { request, nowSeconds: NOW }), undefined);
  });

  it('enforces expiry as closed, a maximum 30 second TTL and bounded future clock skew', () => {
    const signer = createHmacGlobeUiDelegationV1(config);
    const token = signer.mint(mintInput);
    assert.ok(signer.verify(token, { request, nowSeconds: NOW + 29 }));
    assert.equal(signer.verify(token, { request, nowSeconds: NOW + 30 }), undefined);
    assert.throws(() => signer.mint({ ...mintInput, ttlSeconds: 31 }), /ttl_invalid/);

    const future = signer.mint({ ...mintInput, issuedAtSeconds: NOW + 4 });
    assert.equal(signer.verify(future, { request, nowSeconds: NOW }), undefined);
    assert.ok(signer.verify(future, { request, nowSeconds: NOW, clockSkewSeconds: 5 }));
  });

  it('rejects malformed, non-canonical and tampered tokens without throwing', () => {
    const signer = createHmacGlobeUiDelegationV1(config);
    const token = signer.mint(mintInput);
    const [version, payload, signature] = token.split('.');
    for (const candidate of [
      '', 'garbage', 'v1.only-two', 'v2.a.b', 'v1.!.sig',
      `${version}.${payload}x.${signature}`,
      `${version}.${payload}.${signature}x`,
    ]) assert.equal(signer.verify(candidate, { request, nowSeconds: NOW }), undefined);

    // Even a correctly signed payload is rejected when its JSON is not canonical. This keeps
    // one semantic claim set from having multiple signed byte representations.
    const claims = signer.verify(token, { request, nowSeconds: NOW });
    assert.ok(claims);
    const nonCanonicalPayload = Buffer.from(JSON.stringify(claims), 'utf8').toString('base64url');
    const nonCanonicalSignature = createHmac('sha256', SECRET)
      .update(`v1.${nonCanonicalPayload}`)
      .digest('base64url');
    assert.equal(
      signer.verify(`v1.${nonCanonicalPayload}.${nonCanonicalSignature}`, { request, nowSeconds: NOW }),
      undefined,
    );
  });

  it('hashes exact body bytes and refuses weak secrets or duplicate authorities', () => {
    assert.equal(sha256GlobeUiDelegationBody('é'), sha256GlobeUiDelegationBody(new TextEncoder().encode('é')));
    assert.notEqual(sha256GlobeUiDelegationBody('{}'), sha256GlobeUiDelegationBody('{ }'));
    assert.throws(() => createHmacGlobeUiDelegationV1({ ...config, secret: 'short' }), /secret_invalid/);
    const signer = createHmacGlobeUiDelegationV1(config);
    assert.throws(
      () => signer.mint({ ...mintInput, capabilities: ['globe.lab.experiment.run', 'globe.lab.experiment.run'] }),
      /capabilities_invalid/,
    );
  });
});
