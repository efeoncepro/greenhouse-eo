import { createHash, createHmac, timingSafeEqual } from 'node:crypto';

import {
  GLOBE_UI_DELEGATION_MAX_TTL_SECONDS,
  GLOBE_UI_DELEGATION_PURPOSE,
  GLOBE_UI_DELEGATION_SURFACE,
  GLOBE_UI_DELEGATION_VERSION,
  canonicalizeGlobeUiDelegationClaims,
  canonicalizeGlobeUiDelegationRequest,
  normalizeGlobeUiDelegationRequest,
  parseGlobeUiDelegationClaims,
  type GlobeCapability,
  type GlobeUiDelegationClaimsV1,
  type GlobeUiDelegationRequestV1,
} from '@efeonce-globe/contracts';

const TOKEN_FORM = /^[A-Za-z0-9_-]+$/;
const MAX_TOKEN_LENGTH = 16_384;

export type GlobeUiDelegationMintInputV1 = Readonly<{
  actorId: string;
  workspaceId: string;
  capabilities: readonly GlobeCapability[];
  request: GlobeUiDelegationRequestV1;
  issuedAtSeconds: number;
  ttlSeconds?: number;
  jti: string;
}>;

export type GlobeUiDelegationVerifyInputV1 = Readonly<{
  request: GlobeUiDelegationRequestV1;
  nowSeconds: number;
  /** Bounded tolerance for an issuer clock slightly ahead. Never extends expiry. */
  clockSkewSeconds?: number;
}>;

export interface GlobeUiDelegationSignerV1 {
  mint(input: GlobeUiDelegationMintInputV1): string;
  verify(token: string, expected: GlobeUiDelegationVerifyInputV1): GlobeUiDelegationClaimsV1 | undefined;
}

export type HmacGlobeUiDelegationOptionsV1 = Readonly<{
  secret: string | Uint8Array;
  issuer: string;
  audience: string;
  caller: string;
  maxTtlSeconds?: number;
}>;

/** Hashes the exact raw request body. Parsed/re-serialized JSON is not an equivalent request. */
export function sha256GlobeUiDelegationBody(body: string | Uint8Array): string {
  return `sha256:${createHash('sha256').update(body).digest('hex')}`;
}

/** Stable request identity recorded in claims/audit and re-derived by the private API. */
export function fingerprintGlobeUiDelegationRequest(request: GlobeUiDelegationRequestV1): string {
  return sha256GlobeUiDelegationBody(canonicalizeGlobeUiDelegationRequest(request));
}

/**
 * Creates the stateless HMAC V1 boundary used only between the same-origin UI BFF and Globe's
 * IAM-private API. IAM authenticates the workload caller; this token delegates one human,
 * workspace and capability set to exactly one request for at most 30 seconds.
 */
export function createHmacGlobeUiDelegationV1(
  options: HmacGlobeUiDelegationOptionsV1,
): GlobeUiDelegationSignerV1 {
  const secret = typeof options.secret === 'string' ? Buffer.from(options.secret, 'utf8') : Buffer.from(options.secret);
  if (secret.byteLength < 32) throw new Error('globe_ui_delegation_secret_invalid');
  const maxTtlSeconds = options.maxTtlSeconds ?? GLOBE_UI_DELEGATION_MAX_TTL_SECONDS;
  if (!Number.isSafeInteger(maxTtlSeconds) || maxTtlSeconds < 1 || maxTtlSeconds > GLOBE_UI_DELEGATION_MAX_TTL_SECONDS) {
    throw new Error('globe_ui_delegation_ttl_invalid');
  }

  const sign = (payload: string): Buffer =>
    createHmac('sha256', secret).update(`${GLOBE_UI_DELEGATION_VERSION}.${payload}`).digest();

  return {
    mint(input) {
      const ttlSeconds = input.ttlSeconds ?? maxTtlSeconds;
      if (!Number.isSafeInteger(input.issuedAtSeconds) || input.issuedAtSeconds < 0) {
        throw new Error('globe_ui_delegation_iat_invalid');
      }
      if (!Number.isSafeInteger(ttlSeconds) || ttlSeconds < 1 || ttlSeconds > maxTtlSeconds) {
        throw new Error('globe_ui_delegation_ttl_invalid');
      }
      const capabilities = [...new Set(input.capabilities)].sort();
      if (capabilities.length !== input.capabilities.length) throw new Error('globe_ui_delegation_capabilities_invalid');
      const request = normalizeGlobeUiDelegationRequest(input.request);
      const claims: GlobeUiDelegationClaimsV1 = {
        schemaVersion: '1',
        iss: options.issuer,
        aud: options.audience,
        purpose: GLOBE_UI_DELEGATION_PURPOSE,
        caller: options.caller,
        actorId: input.actorId,
        workspaceId: input.workspaceId,
        capabilities,
        surface: GLOBE_UI_DELEGATION_SURFACE,
        request,
        fingerprint: fingerprintGlobeUiDelegationRequest(request),
        iat: input.issuedAtSeconds,
        exp: input.issuedAtSeconds + ttlSeconds,
        jti: input.jti,
      };
      // The same strict parser used on verify validates signer configuration and mint input.
      if (!parseGlobeUiDelegationClaims(claims)) throw new Error('globe_ui_delegation_claims_invalid');
      const payload = Buffer.from(canonicalizeGlobeUiDelegationClaims(claims), 'utf8').toString('base64url');
      return `${GLOBE_UI_DELEGATION_VERSION}.${payload}.${sign(payload).toString('base64url')}`;
    },

    verify(token, expected) {
      try {
        if (token.length === 0 || token.length > MAX_TOKEN_LENGTH) return undefined;
        const parts = token.split('.');
        if (parts.length !== 3) return undefined;
        const [version, payload, signature] = parts;
        if (version !== GLOBE_UI_DELEGATION_VERSION || !payload || !signature) return undefined;
        if (!TOKEN_FORM.test(payload) || !TOKEN_FORM.test(signature)) return undefined;
        const providedSignature = decodeBase64Url(signature);
        if (!providedSignature || !signaturesMatch(sign(payload), providedSignature)) return undefined;

        const decodedPayload = decodeBase64Url(payload)?.toString('utf8');
        if (!decodedPayload) return undefined;
        const claims = parseGlobeUiDelegationClaims(JSON.parse(decodedPayload) as unknown);
        if (!claims || canonicalizeGlobeUiDelegationClaims(claims) !== decodedPayload) return undefined;
        if (claims.iss !== options.issuer || claims.aud !== options.audience || claims.caller !== options.caller) return undefined;
        if (claims.purpose !== GLOBE_UI_DELEGATION_PURPOSE || claims.surface !== GLOBE_UI_DELEGATION_SURFACE) return undefined;
        if (claims.exp <= claims.iat || claims.exp - claims.iat > maxTtlSeconds) return undefined;
        if (!Number.isSafeInteger(expected.nowSeconds) || expected.nowSeconds < 0) return undefined;
        const clockSkewSeconds = expected.clockSkewSeconds ?? 0;
        if (!Number.isSafeInteger(clockSkewSeconds) || clockSkewSeconds < 0 || clockSkewSeconds > 5) return undefined;
        if (claims.iat > expected.nowSeconds + clockSkewSeconds || claims.exp <= expected.nowSeconds) return undefined;

        const request = normalizeGlobeUiDelegationRequest(expected.request);
        if (canonicalizeGlobeUiDelegationRequest(claims.request) !== canonicalizeGlobeUiDelegationRequest(request)) return undefined;
        if (claims.fingerprint !== fingerprintGlobeUiDelegationRequest(claims.request)) return undefined;
        return claims;
      } catch {
        return undefined;
      }
    },
  };
}

function decodeBase64Url(value: string): Buffer | undefined {
  try {
    const decoded = Buffer.from(value, 'base64url');
    return decoded.toString('base64url') === value ? decoded : undefined;
  } catch {
    return undefined;
  }
}

function signaturesMatch(expected: Buffer, provided: Buffer): boolean {
  return expected.byteLength === provided.byteLength && timingSafeEqual(expected, provided);
}
