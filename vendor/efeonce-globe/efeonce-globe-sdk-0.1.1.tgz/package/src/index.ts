import {
  GLOBE_API_VERSION,
  GLOBE_EVAL_COMMANDS,
  GLOBE_EVAL_READERS,
  GLOBE_LAB_COMMANDS,
  GLOBE_LAB_READERS,
  GLOBE_GOVERNED_RUN_COMMANDS,
  GLOBE_GOVERNED_RUN_READERS,
  GLOBE_MODEL_READINESS_COMMANDS,
  GLOBE_MODEL_READINESS_READERS,
  GLOBE_TENANCY_COMMANDS,
  GLOBE_TENANCY_READERS,
  GLOBE_PRODUCER_ASSET_COMMANDS,
  GLOBE_PRODUCER_ASSET_READERS,
  GLOBE_VOICE_PRESET_COMMANDS,
  GLOBE_VOICE_PRESET_READERS,
  GLOBE_PRODUCER_READERS,
  GLOBE_RESPONSIBILITY_COMMANDS,
  GLOBE_RESPONSIBILITY_READERS,
  type AssetAnnotationsDataV1,
  type CapabilityCoverageManifestV1,
  type CommandRequestEnvelopeV1,
  type CommandResultV1,
  type EstimateExperimentQueryV1,
  type EvaluateAttemptPayloadV1,
  type EvaluationReportV1,
  type EvaluationRubricV1,
  type ExperimentAttemptManifestV1,
  type LabEstimatePreviewV1,
  type ModelReadinessHistoryV1,
  type ModelReadinessListQueryV1,
  type ModelReadinessPageV1,
  type ModelReadinessQueryV1,
  type ModelReadinessReviewV1,
  type ModelReadinessRevisionV1,
  type ProposeModelRoutePayloadV1,
  type RecordModelReadinessReviewPayloadV1,
  type TransitionModelRoutePayloadV1,
  type EffectiveWorkspaceAccessV1,
  type IssueWorkspaceGrantPayloadV1,
  type ReconcileTenancyProjectionPayloadV1,
  type ReconcileTenancyProjectionPayloadV2,
  type RevokeWorkspaceGrantPayloadV1,
  type WorkspaceGrantHistoryV1,
  type WorkspaceGrantRevisionV1,
  type WorkspaceTenancyAggregateV1,
  type GlobeApiErrorCode,
  type GlobeApiErrorV1,
  type GlobeHealthV1,
  type GoldenBriefFixtureV1,
  type LabExperimentV1,
  type PrepareExperimentPayloadV1,
  type CopyAsReferencePayloadV1,
  type FavoriteAssetOutcomeV1,
  type FavoriteAssetPayloadV1,
  type GetOutputQueryV1,
  type ProducerCatalogGetDataV1,
  type ProducerCatalogListDataV1,
  type ProducerCatalogListQueryV1,
  type ProducerOutputHandleV1,
  type ProducerReferenceHandleV1,
  type RegisterVoicePresetPayloadV1,
  type VoicePresetGetDataV1,
  type VoicePresetGetQueryV1,
  type VoicePresetListDataV1,
  type VoicePresetV1,
  type AssignResponsibilityPayloadV1,
  type ChangeResponsibilityPayloadV1,
  type EffectiveResponsibilityQueryV1,
  type OperatingResponsibilityAssignmentV1,
  type ResponsibilityAssignmentQueryV1,
  type ResponsibilityHistoryV1,
  type ReaderRequestEnvelopeV1,
  type ReaderResultV1,
  type CancelGovernedRunPayloadV1,
  type GovernedRunListQueryV1,
  type GovernedRunPageV1,
  type GovernedRunQueryV1,
  type GovernedRunViewV1,
  type GovernedRunRetryEstimateQueryV1,
  type GovernedRunRetryEstimateV1,
  type ReconcileGovernedRunPayloadV1,
  type RetryGovernedRunPayloadV1,
  type SetGovernedRunPriorityPayloadV1,
} from '@efeonce-globe/contracts';
import {
  GLOBE_PRODUCTION_ROUTING_COMMANDS,
  GLOBE_PRODUCTION_ROUTING_READERS,
  type AppendProductionRoutePayloadV1,
  type ProductionRouteBindingRevisionV1,
  type ProductionRouteHistoryV1,
  type ProductionRouteQueryV1,
  type ProviderCircuitHistoryV1,
  type ProviderCircuitQueryV1,
  type ProviderCircuitStateRevisionV1,
  type TransitionProviderCircuitPayloadV1,
} from '@efeonce-globe/contracts/production-routing-control';
import {
  GLOBE_ASSET_PROVENANCE_COMMANDS,
  GLOBE_ASSET_PROVENANCE_READERS,
  type AssetIngestStatusQueryV1,
  type AssetProvenanceDataV1,
  type CompletePrivateIngestPayloadV1,
  type GovernedAssetPageV1,
  type GovernedAssetV1,
  type InitiatePrivateIngestOutcomeV1,
  type InitiatePrivateIngestPayloadV1,
  type ListGovernedAssetsQueryV1,
  type SubmitAssetRightsEvidencePayloadV1,
} from '@efeonce-globe/contracts/asset-provenance';
import {
  GLOBE_GENERATED_RIGHTS_POLICY_COMMANDS,
  GLOBE_GENERATED_RIGHTS_POLICY_READERS,
  type GeneratedRightsPolicyListQueryV1,
  type GeneratedRightsPolicyPageV1,
  type GeneratedRightsPolicyQueryV1,
  type GeneratedRightsPolicyV1,
  type PublishGeneratedRightsPolicyPayloadV1,
} from '@efeonce-globe/contracts/asset-governance';

const SDK_VERSION = '0.1.1' as const;
const SAFE_CONTEXT_VALUE = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/;

export type GlobeAuthMaterial =
  | Readonly<{ kind: 'bearer'; token: string }>
  | Readonly<{ kind: 'cloud-run-id-token'; token: string }>;

export type GlobeAuthRequest = Readonly<{
  audience: string;
  method: string;
  url: string;
}>;

export interface GlobeAuthStrategy {
  getAuthMaterial(request: GlobeAuthRequest): Promise<GlobeAuthMaterial>;
}

export type GlobeInvocationContext = Readonly<{
  correlationId?: string;
  workspaceId?: string;
  idempotencyKey?: string;
  signal?: AbortSignal;
}>;

export type GlobeClientOptions = Readonly<{
  baseUrl: string;
  audience?: string;
  auth: GlobeAuthStrategy;
  fetch?: typeof globalThis.fetch;
  timeoutMs?: number;
}>;

export class GlobeSdkError extends Error {
  readonly code: GlobeApiErrorCode | 'transport_error' | 'invalid_response';
  readonly status: number | undefined;
  readonly retryable: boolean;
  readonly correlationId: string | undefined;

  constructor(options: {
    code: GlobeApiErrorCode | 'transport_error' | 'invalid_response';
    message: string;
    status?: number;
    retryable: boolean;
    correlationId?: string;
  }) {
    super(options.message);
    this.name = 'GlobeSdkError';
    this.code = options.code;
    this.status = options.status;
    this.retryable = options.retryable;
    this.correlationId = options.correlationId;
  }
}

export class GlobeClient {
  readonly #baseUrl: URL;
  readonly #audience: string;
  readonly #auth: GlobeAuthStrategy;
  readonly #fetch: typeof globalThis.fetch;
  readonly #timeoutMs: number;

  constructor(options: GlobeClientOptions) {
    this.#baseUrl = normalizeServiceUrl(options.baseUrl);
    this.#audience = options.audience ?? this.#baseUrl.origin;
    this.#auth = options.auth;
    this.#fetch = options.fetch ?? globalThis.fetch;
    this.#timeoutMs = options.timeoutMs ?? 10_000;

    if (!Number.isSafeInteger(this.#timeoutMs) || this.#timeoutMs < 100 || this.#timeoutMs > 120_000) {
      throw new Error('globe_sdk_timeout_invalid');
    }
  }

  async health(context: GlobeInvocationContext = {}): Promise<GlobeHealthV1> {
    return this.#request<GlobeHealthV1>('GET', 'v1/health', context);
  }

  /**
   * Machine-readable capability coverage for every Full API Parity surface. A
   * consumer reads this to learn which capabilities are `available`,
   * `policy-blocked` or `not-applicable` before attempting a dispatch.
   */
  async capabilities(context: GlobeInvocationContext = {}): Promise<CapabilityCoverageManifestV1> {
    return this.#request<CapabilityCoverageManifestV1>('GET', 'v1/capabilities', context);
  }

  /**
   * Dispatches a governed command through the private API. The command name and
   * payload are the only caller-provided data; actor and workspace authority are
   * derived server-side. `context.workspaceId` is an untrusted workspace
   * selection validated against the principal's bindings.
   */
  async dispatchCommand<TOutcome = unknown>(
    command: string,
    payload: unknown,
    context: GlobeInvocationContext = {},
  ): Promise<CommandResultV1<TOutcome>> {
    if (!context.idempotencyKey) throw new Error('globe_sdk_idempotency_key_required');

    const correlationId = context.correlationId ?? globalThis.crypto.randomUUID();
    const envelope: CommandRequestEnvelopeV1 = {
      schemaVersion: '1',
      apiVersion: GLOBE_API_VERSION,
      command,
      idempotencyKey: context.idempotencyKey,
      correlationId,
      ...(context.workspaceId !== undefined ? { workspaceSelection: context.workspaceId } : {}),
      payload,
    };

    return this.#request<CommandResultV1<TOutcome>>('POST', 'v1/commands', { ...context, correlationId }, envelope);
  }

  /**
   * Dispatches a governed reader. Reads are policy-filtered projections; the
   * reader name and query are the only caller-provided data.
   */
  async dispatchReader<TData = unknown>(
    reader: string,
    query: unknown,
    context: GlobeInvocationContext = {},
  ): Promise<ReaderResultV1<TData>> {
    const correlationId = context.correlationId ?? globalThis.crypto.randomUUID();
    const envelope: ReaderRequestEnvelopeV1 = {
      schemaVersion: '1',
      apiVersion: GLOBE_API_VERSION,
      reader,
      correlationId,
      ...(context.workspaceId !== undefined ? { workspaceSelection: context.workspaceId } : {}),
      query,
    };

    return this.#request<ReaderResultV1<TData>>('POST', 'v1/readers', { ...context, correlationId }, envelope);
  }

  // --- Model Lab (TASK-1457) typed methods ---

  /** Prepares a Model Lab experiment. Requires an idempotency key (it is a command). */
  async prepareExperiment(
    payload: PrepareExperimentPayloadV1,
    context: GlobeInvocationContext = {},
  ): Promise<CommandResultV1<LabExperimentV1>> {
    return this.dispatchCommand<LabExperimentV1>(GLOBE_LAB_COMMANDS.prepare, payload, context);
  }

  /** Executes a prepared experiment: estimate, fence the hard cap, run and settle. */
  async executeExperiment(
    experimentId: string,
    context: GlobeInvocationContext = {},
  ): Promise<CommandResultV1<LabExperimentV1>> {
    return this.dispatchCommand<LabExperimentV1>(GLOBE_LAB_COMMANDS.execute, { experimentId }, context);
  }

  /** Cancels a non-terminal experiment. */
  async cancelExperiment(
    experimentId: string,
    reason: string,
    context: GlobeInvocationContext = {},
  ): Promise<CommandResultV1<LabExperimentV1>> {
    return this.dispatchCommand<LabExperimentV1>(GLOBE_LAB_COMMANDS.cancel, { experimentId, reason }, context);
  }

  /** Reads an experiment projection scoped to the caller workspace. */
  async getExperiment(
    experimentId: string,
    context: GlobeInvocationContext = {},
  ): Promise<ReaderResultV1<LabExperimentV1>> {
    return this.dispatchReader<LabExperimentV1>(GLOBE_LAB_READERS.get, { experimentId }, context);
  }

  /** Reads the per-attempt manifests of an experiment. */
  async getExperimentEvidence(
    experimentId: string,
    context: GlobeInvocationContext = {},
  ): Promise<ReaderResultV1<{ experimentId: string; attempts: readonly ExperimentAttemptManifestV1[] }>> {
    return this.dispatchReader(GLOBE_LAB_READERS.evidence, { experimentId }, context);
  }

  // --- Durable governed run controls (TASK-1469/TASK-1505) ---

  async cancelGovernedRun(payload: CancelGovernedRunPayloadV1, context: GlobeInvocationContext = {}): Promise<CommandResultV1<GovernedRunViewV1>> {
    return this.dispatchCommand(GLOBE_GOVERNED_RUN_COMMANDS.cancel, payload, context);
  }

  async retryGovernedRun(payload: RetryGovernedRunPayloadV1, context: GlobeInvocationContext = {}): Promise<CommandResultV1<GovernedRunViewV1>> {
    return this.dispatchCommand(GLOBE_GOVERNED_RUN_COMMANDS.retry, payload, context);
  }

  async setGovernedRunPriority(payload: SetGovernedRunPriorityPayloadV1, context: GlobeInvocationContext = {}): Promise<CommandResultV1<GovernedRunViewV1>> {
    return this.dispatchCommand(GLOBE_GOVERNED_RUN_COMMANDS.setPriority, payload, context);
  }

  async reconcileGovernedRun(payload: ReconcileGovernedRunPayloadV1, context: GlobeInvocationContext = {}): Promise<CommandResultV1<GovernedRunViewV1>> {
    return this.dispatchCommand(GLOBE_GOVERNED_RUN_COMMANDS.reconcile, payload, context);
  }

  async getGovernedRun(query: GovernedRunQueryV1, context: GlobeInvocationContext = {}): Promise<ReaderResultV1<GovernedRunViewV1>> {
    return this.dispatchReader(GLOBE_GOVERNED_RUN_READERS.get, query, context);
  }

  async getGovernedRunStatus(query: GovernedRunQueryV1, context: GlobeInvocationContext = {}): Promise<ReaderResultV1<GovernedRunViewV1>> {
    return this.dispatchReader(GLOBE_GOVERNED_RUN_READERS.status, query, context);
  }

  async listGovernedRuns(query: GovernedRunListQueryV1 = {}, context: GlobeInvocationContext = {}): Promise<ReaderResultV1<GovernedRunPageV1>> {
    return this.dispatchReader(GLOBE_GOVERNED_RUN_READERS.list, query, context);
  }

  async estimateGovernedRunRetry(query: GovernedRunRetryEstimateQueryV1, context: GlobeInvocationContext = {}): Promise<ReaderResultV1<GovernedRunRetryEstimateV1>> {
    return this.dispatchReader(GLOBE_GOVERNED_RUN_READERS.retryEstimate, query, context);
  }

  /**
   * Previews the credit estimate (`✨N`) for a prospective (route × output-shape) tuple, read-only
   * and BEFORE any spend: no experiment is created, no credit reserved. The returned preview is
   * curated — it exposes the credit number, the fidelity route and budget signals, never the
   * provider/model slug, vendor cost or margin (TASK-1502).
   */
  async estimateExperiment(
    query: EstimateExperimentQueryV1,
    context: GlobeInvocationContext = {},
  ): Promise<ReaderResultV1<LabEstimatePreviewV1>> {
    return this.dispatchReader<LabEstimatePreviewV1>(GLOBE_LAB_READERS.estimate, query, context);
  }

  // --- Golden Briefs & Evaluation Harness (TASK-1458) typed methods ---

  /**
   * Runs a golden brief through the Model Lab and scores its attempt against a versioned
   * rubric. Returns a versioned report whose verdict never auto-marks a creative pass —
   * objective checks either fail, or clear the attempt for mandatory human review.
   */
  async evaluateGoldenBrief(
    payload: EvaluateAttemptPayloadV1,
    context: GlobeInvocationContext = {},
  ): Promise<CommandResultV1<EvaluationReportV1>> {
    return this.dispatchCommand<EvaluationReportV1>(GLOBE_EVAL_COMMANDS.evaluate, payload, context);
  }

  /** Lists the versioned golden-brief fixtures and their rubrics. */
  async listGoldenBriefs(
    context: GlobeInvocationContext = {},
  ): Promise<ReaderResultV1<{ fixtures: readonly GoldenBriefFixtureV1[]; rubrics: readonly EvaluationRubricV1[] }>> {
    return this.dispatchReader(GLOBE_EVAL_READERS.fixtures, {}, context);
  }

  /** Reads a versioned evaluation report scoped to the caller workspace. */
  async getEvaluationReport(
    reportId: string,
    context: GlobeInvocationContext = {},
  ): Promise<ReaderResultV1<EvaluationReportV1>> {
    return this.dispatchReader<EvaluationReportV1>(GLOBE_EVAL_READERS.report, { reportId }, context);
  }

  // --- Signed model promotion/readiness registry (TASK-1463) ---

  async recordModelReadinessReview(
    payload: RecordModelReadinessReviewPayloadV1,
    context: GlobeInvocationContext = {},
  ): Promise<CommandResultV1<ModelReadinessReviewV1>> {
    return this.dispatchCommand(GLOBE_MODEL_READINESS_COMMANDS.review, payload, context);
  }

  async proposeModelRoute(
    payload: ProposeModelRoutePayloadV1,
    context: GlobeInvocationContext = {},
  ): Promise<CommandResultV1<ModelReadinessRevisionV1>> {
    return this.dispatchCommand(GLOBE_MODEL_READINESS_COMMANDS.propose, payload, context);
  }

  async promoteModelRoute(payload: TransitionModelRoutePayloadV1, context: GlobeInvocationContext = {}) {
    return this.dispatchCommand<ModelReadinessRevisionV1>(GLOBE_MODEL_READINESS_COMMANDS.promote, payload, context);
  }

  async pauseModelRoute(payload: TransitionModelRoutePayloadV1, context: GlobeInvocationContext = {}) {
    return this.dispatchCommand<ModelReadinessRevisionV1>(GLOBE_MODEL_READINESS_COMMANDS.pause, payload, context);
  }

  async retireModelRoute(payload: TransitionModelRoutePayloadV1, context: GlobeInvocationContext = {}) {
    return this.dispatchCommand<ModelReadinessRevisionV1>(GLOBE_MODEL_READINESS_COMMANDS.retire, payload, context);
  }

  async getModelReadinessReview(reviewId: string, context: GlobeInvocationContext = {}) {
    return this.dispatchReader<ModelReadinessReviewV1>(GLOBE_MODEL_READINESS_READERS.review, { reviewId }, context);
  }

  async getModelReadiness(query: ModelReadinessQueryV1, context: GlobeInvocationContext = {}) {
    return this.dispatchReader<ModelReadinessRevisionV1>(GLOBE_MODEL_READINESS_READERS.get, query, context);
  }

  async listModelReadiness(query: ModelReadinessListQueryV1 = {}, context: GlobeInvocationContext = {}) {
    return this.dispatchReader<ModelReadinessPageV1>(GLOBE_MODEL_READINESS_READERS.list, query, context);
  }

  async getModelReadinessHistory(query: ModelReadinessQueryV1, context: GlobeInvocationContext = {}) {
    return this.dispatchReader<ModelReadinessHistoryV1>(GLOBE_MODEL_READINESS_READERS.history, query, context);
  }

  async resolvePromotedModelRoute(query: ModelReadinessQueryV1, context: GlobeInvocationContext = {}) {
    return this.dispatchReader<ModelReadinessRevisionV1>(GLOBE_MODEL_READINESS_READERS.resolvePromoted, query, context);
  }

  // --- Operator-only exact production routing control ---

  async appendProductionRoute(payload: AppendProductionRoutePayloadV1, context: GlobeInvocationContext = {}) {
    return this.dispatchCommand<ProductionRouteBindingRevisionV1>(GLOBE_PRODUCTION_ROUTING_COMMANDS.appendRoute, payload, context);
  }

  async transitionProviderCircuit(payload: TransitionProviderCircuitPayloadV1, context: GlobeInvocationContext = {}) {
    return this.dispatchCommand<ProviderCircuitStateRevisionV1>(GLOBE_PRODUCTION_ROUTING_COMMANDS.transitionCircuit, payload, context);
  }

  async getProductionRoute(query: ProductionRouteQueryV1, context: GlobeInvocationContext = {}) {
    return this.dispatchReader<ProductionRouteBindingRevisionV1>(GLOBE_PRODUCTION_ROUTING_READERS.route, query, context);
  }

  async getProductionRouteHistory(query: ProductionRouteQueryV1, context: GlobeInvocationContext = {}) {
    return this.dispatchReader<ProductionRouteHistoryV1>(GLOBE_PRODUCTION_ROUTING_READERS.routeHistory, query, context);
  }

  async getProviderCircuit(query: ProviderCircuitQueryV1, context: GlobeInvocationContext = {}) {
    return this.dispatchReader<ProviderCircuitStateRevisionV1>(GLOBE_PRODUCTION_ROUTING_READERS.circuit, query, context);
  }

  async getProviderCircuitHistory(query: ProviderCircuitQueryV1, context: GlobeInvocationContext = {}) {
    return this.dispatchReader<ProviderCircuitHistoryV1>(GLOBE_PRODUCTION_ROUTING_READERS.circuitHistory, query, context);
  }

  // --- Persisted broker-bounded tenancy projection (TASK-1511) ---

  async reconcileTenancyProjection(payload: ReconcileTenancyProjectionPayloadV1 | ReconcileTenancyProjectionPayloadV2, context: GlobeInvocationContext = {}) {
    return this.dispatchCommand<WorkspaceTenancyAggregateV1>(GLOBE_TENANCY_COMMANDS.reconcile, payload, context);
  }

  async issueWorkspaceGrant(payload: IssueWorkspaceGrantPayloadV1, context: GlobeInvocationContext = {}) {
    return this.dispatchCommand<WorkspaceGrantRevisionV1>(GLOBE_TENANCY_COMMANDS.grant, payload, context);
  }

  async revokeWorkspaceGrant(payload: RevokeWorkspaceGrantPayloadV1, context: GlobeInvocationContext = {}) {
    return this.dispatchCommand<WorkspaceGrantRevisionV1>(GLOBE_TENANCY_COMMANDS.revokeGrant, payload, context);
  }

  async getWorkspaceTenancy(context: GlobeInvocationContext = {}) {
    return this.dispatchReader<WorkspaceTenancyAggregateV1>(GLOBE_TENANCY_READERS.get, {}, context);
  }

  async getEffectiveWorkspaceAccess(context: GlobeInvocationContext = {}) {
    return this.dispatchReader<EffectiveWorkspaceAccessV1>(GLOBE_TENANCY_READERS.effectiveAccess, {}, context);
  }

  async getWorkspaceGrantHistory(grantId: string, context: GlobeInvocationContext = {}) {
    return this.dispatchReader<WorkspaceGrantHistoryV1>(GLOBE_TENANCY_READERS.grantHistory, { grantId }, context);
  }

  // --- Creative Producer route catalog (TASK-1500) typed methods ---

  /**
   * Lists the governed producer route catalog, optionally filtered by capability
   * and/or modality. Each route's `model` identity (name + optional version) is a
   * public quality anchor; the internal `house` classification is resolved
   * server-side and present only for an operator-authorized caller.
   */
  async listProducerRoutes(
    query: ProducerCatalogListQueryV1 = {},
    context: GlobeInvocationContext = {},
  ): Promise<ReaderResultV1<ProducerCatalogListDataV1>> {
    return this.dispatchReader<ProducerCatalogListDataV1>(GLOBE_PRODUCER_READERS.list, query, context);
  }

  /** Reads one producer catalog route by its wire key (`referenceRoute`). */
  async getProducerRoute(
    routeId: string,
    context: GlobeInvocationContext = {},
  ): Promise<ReaderResultV1<ProducerCatalogGetDataV1>> {
    return this.dispatchReader<ProducerCatalogGetDataV1>(GLOBE_PRODUCER_READERS.get, { routeId }, context);
  }

  // --- Creative Producer output side (TASK-1503) typed methods ---

  /**
   * Resolves one of the caller workspace's own retained outputs to a servable descriptor plus a
   * short-lived retrieval grant. It never returns bytes: redeem `retrievalGrant` against
   * `GET /v1/outputs/:sha256` for those.
   */
  async getProducerOutput(
    query: GetOutputQueryV1,
    context: GlobeInvocationContext = {},
  ): Promise<ReaderResultV1<ProducerOutputHandleV1>> {
    return this.dispatchReader<ProducerOutputHandleV1>(GLOBE_PRODUCER_ASSET_READERS.output, query, context);
  }

  /** Reads the caller workspace's producer annotations: starred candidates and references. */
  async listProducerAssets(
    context: GlobeInvocationContext = {},
  ): Promise<ReaderResultV1<AssetAnnotationsDataV1>> {
    return this.dispatchReader<AssetAnnotationsDataV1>(GLOBE_PRODUCER_ASSET_READERS.assets, {}, context);
  }

  /** Sets whether an output is starred. Takes the desired state, so a retry is idempotent. */
  async favoriteProducerAsset(
    payload: FavoriteAssetPayloadV1,
    context: GlobeInvocationContext = {},
  ): Promise<CommandResultV1<FavoriteAssetOutcomeV1>> {
    return this.dispatchCommand<FavoriteAssetOutcomeV1>(GLOBE_PRODUCER_ASSET_COMMANDS.favorite, payload, context);
  }

  /**
   * Certifies one of the caller's own outputs as a reusable reference. Zero spend and zero
   * bytes: the handle carries a content hash plus the rights inherited from its parent.
   */
  async copyProducerAssetAsReference(
    payload: CopyAsReferencePayloadV1,
    context: GlobeInvocationContext = {},
  ): Promise<CommandResultV1<ProducerReferenceHandleV1>> {
    return this.dispatchCommand<ProducerReferenceHandleV1>(
      GLOBE_PRODUCER_ASSET_COMMANDS.copyAsReference,
      payload,
      context,
    );
  }

  // --- Governed private asset ingest and provenance (TASK-1467) ---

  async initiatePrivateAssetIngest(
    payload: InitiatePrivateIngestPayloadV1,
    context: GlobeInvocationContext = {},
  ): Promise<CommandResultV1<InitiatePrivateIngestOutcomeV1>> {
    return this.dispatchCommand(GLOBE_ASSET_PROVENANCE_COMMANDS.initiateIngest, payload, context);
  }

  /** Accepts a verified private upload envelope and returns after its durable governance job is queued. */
  async completePrivateAssetIngest(
    payload: CompletePrivateIngestPayloadV1,
    context: GlobeInvocationContext = {},
  ): Promise<CommandResultV1<GovernedAssetV1>> {
    return this.dispatchCommand(GLOBE_ASSET_PROVENANCE_COMMANDS.completeIngest, payload, context);
  }

  /** Submits only an opaque server-held evidence reference; a browser cannot assert a rights verdict. */
  async submitPrivateAssetRightsEvidence(
    payload: SubmitAssetRightsEvidencePayloadV1,
    context: GlobeInvocationContext = {},
  ): Promise<CommandResultV1<GovernedAssetV1>> {
    return this.dispatchCommand(GLOBE_ASSET_PROVENANCE_COMMANDS.submitRightsEvidence, payload, context);
  }

  async getPrivateAssetIngestStatus(
    query: AssetIngestStatusQueryV1,
    context: GlobeInvocationContext = {},
  ): Promise<ReaderResultV1<InitiatePrivateIngestOutcomeV1>> {
    return this.dispatchReader(GLOBE_ASSET_PROVENANCE_READERS.status, query, context);
  }

  async getPrivateAssetProvenance(
    assetId: string,
    context: GlobeInvocationContext = {},
  ): Promise<ReaderResultV1<AssetProvenanceDataV1>> {
    return this.dispatchReader(GLOBE_ASSET_PROVENANCE_READERS.get, { assetId }, context);
  }

  async listGovernedPrivateAssets(
    query: ListGovernedAssetsQueryV1 = {},
    context: GlobeInvocationContext = {},
  ): Promise<ReaderResultV1<GovernedAssetPageV1>> {
    return this.dispatchReader(GLOBE_ASSET_PROVENANCE_READERS.list, query, context);
  }

  // --- Operator-only generated/derived rights policies ---

  async publishGeneratedRightsPolicy(payload: PublishGeneratedRightsPolicyPayloadV1, context: GlobeInvocationContext = {}) {
    return this.dispatchCommand<GeneratedRightsPolicyV1>(GLOBE_GENERATED_RIGHTS_POLICY_COMMANDS.publish, payload, context);
  }

  async getGeneratedRightsPolicy(query: GeneratedRightsPolicyQueryV1, context: GlobeInvocationContext = {}) {
    return this.dispatchReader<GeneratedRightsPolicyV1>(GLOBE_GENERATED_RIGHTS_POLICY_READERS.get, query, context);
  }

  async listGeneratedRightsPolicies(query: GeneratedRightsPolicyListQueryV1 = {}, context: GlobeInvocationContext = {}) {
    return this.dispatchReader<GeneratedRightsPolicyPageV1>(GLOBE_GENERATED_RIGHTS_POLICY_READERS.list, query, context);
  }

  // --- Voice preset registry (TASK-1504) ---

  /**
   * Registers a reusable voice for the caller's workspace. Zero spend: it runs no provider and
   * reserves no credit, which is why it carries its own grant rather than the Lab's.
   */
  async registerVoicePreset(
    payload: RegisterVoicePresetPayloadV1,
    context: GlobeInvocationContext = {},
  ): Promise<CommandResultV1<VoicePresetV1>> {
    return this.dispatchCommand<VoicePresetV1>(GLOBE_VOICE_PRESET_COMMANDS.register, payload, context);
  }

  /** Reads the caller workspace's registered voices. Never exposes a provider voice id. */
  async listVoicePresets(context: GlobeInvocationContext = {}): Promise<ReaderResultV1<VoicePresetListDataV1>> {
    return this.dispatchReader<VoicePresetListDataV1>(GLOBE_VOICE_PRESET_READERS.list, {}, context);
  }

  /** Reads one registered voice. A preset outside the caller's workspace is `not_found`. */
  async getVoicePreset(
    query: VoicePresetGetQueryV1,
    context: GlobeInvocationContext = {},
  ): Promise<ReaderResultV1<VoicePresetGetDataV1>> {
    return this.dispatchReader<VoicePresetGetDataV1>(GLOBE_VOICE_PRESET_READERS.get, query, context);
  }

  // --- Operating modes and responsibility assignments (TASK-1466) ---

  async assignResponsibility(
    payload: AssignResponsibilityPayloadV1,
    context: GlobeInvocationContext = {},
  ): Promise<CommandResultV1<OperatingResponsibilityAssignmentV1>> {
    return this.dispatchCommand(GLOBE_RESPONSIBILITY_COMMANDS.assign, payload, context);
  }

  async changeResponsibility(
    payload: ChangeResponsibilityPayloadV1,
    context: GlobeInvocationContext = {},
  ): Promise<CommandResultV1<OperatingResponsibilityAssignmentV1>> {
    return this.dispatchCommand(GLOBE_RESPONSIBILITY_COMMANDS.change, payload, context);
  }

  async getResponsibility(
    query: ResponsibilityAssignmentQueryV1,
    context: GlobeInvocationContext = {},
  ): Promise<ReaderResultV1<OperatingResponsibilityAssignmentV1>> {
    return this.dispatchReader(GLOBE_RESPONSIBILITY_READERS.get, query, context);
  }

  async getEffectiveResponsibility(
    query: EffectiveResponsibilityQueryV1 = {},
    context: GlobeInvocationContext = {},
  ): Promise<ReaderResultV1<OperatingResponsibilityAssignmentV1>> {
    return this.dispatchReader(GLOBE_RESPONSIBILITY_READERS.effective, query, context);
  }

  async getResponsibilityHistory(
    query: ResponsibilityAssignmentQueryV1,
    context: GlobeInvocationContext = {},
  ): Promise<ReaderResultV1<ResponsibilityHistoryV1>> {
    return this.dispatchReader(GLOBE_RESPONSIBILITY_READERS.history, query, context);
  }

  async #request<T>(
    method: string,
    path: string,
    context: GlobeInvocationContext,
    body?: unknown,
  ): Promise<T> {
    const url = new URL(path, this.#baseUrl);
    const correlationId = context.correlationId ?? globalThis.crypto.randomUUID();

    validateContextValue('correlation_id', correlationId);
    if (context.workspaceId) validateContextValue('workspace_id', context.workspaceId);
    if (context.idempotencyKey) validateContextValue('idempotency_key', context.idempotencyKey);

    const authMaterial = await this.#auth.getAuthMaterial({
      audience: this.#audience,
      method,
      url: url.toString(),
    });
    const headers = new Headers({
      Accept: 'application/json',
      'X-Globe-Correlation-Id': correlationId,
      'X-Globe-Sdk-Version': SDK_VERSION,
    });

    applyAuthMaterial(headers, authMaterial);
    if (context.workspaceId) headers.set('X-Globe-Workspace-Id', context.workspaceId);
    if (context.idempotencyKey) headers.set('Idempotency-Key', context.idempotencyKey);

    const requestInit: RequestInit = { method, headers };
    if (body !== undefined) {
      headers.set('Content-Type', 'application/json');
      requestInit.body = JSON.stringify(body);
    }

    const timeoutSignal = AbortSignal.timeout(this.#timeoutMs);
    requestInit.signal = context.signal
      ? AbortSignal.any([context.signal, timeoutSignal])
      : timeoutSignal;

    let response: Response;
    try {
      response = await this.#fetch(url, requestInit);
    } catch {
      throw new GlobeSdkError({
        code: 'transport_error',
        message: 'globe_transport_failed',
        retryable: true,
        correlationId,
      });
    }

    if (!response.ok) {
      throw await toSdkError(response, correlationId);
    }

    if (!response.headers.get('content-type')?.includes('application/json')) {
      throw new GlobeSdkError({
        code: 'invalid_response',
        message: 'globe_response_not_json',
        status: response.status,
        retryable: false,
        correlationId,
      });
    }

    try {
      return (await response.json()) as T;
    } catch {
      throw new GlobeSdkError({
        code: 'invalid_response',
        message: 'globe_response_invalid',
        status: response.status,
        retryable: false,
        correlationId,
      });
    }
  }
}

export function createCallbackAuth(
  callback: (request: GlobeAuthRequest) => Promise<GlobeAuthMaterial>,
): GlobeAuthStrategy {
  return { getAuthMaterial: callback };
}

function normalizeServiceUrl(value: string): URL {
  const url = new URL(value);
  const isLocal = url.protocol === 'http:' && ['localhost', '127.0.0.1', '::1'].includes(url.hostname);

  if (url.protocol !== 'https:' && !isLocal) throw new Error('globe_sdk_base_url_insecure');
  if (url.username || url.password || url.search || url.hash) throw new Error('globe_sdk_base_url_invalid');
  url.pathname = url.pathname.endsWith('/') ? url.pathname : `${url.pathname}/`;
  return url;
}

function validateContextValue(field: string, value: string): void {
  if (!SAFE_CONTEXT_VALUE.test(value)) throw new Error(`globe_sdk_${field}_invalid`);
}

function applyAuthMaterial(headers: Headers, material: GlobeAuthMaterial): void {
  if (!material.token || /[\r\n]/.test(material.token)) throw new Error('globe_sdk_auth_material_invalid');

  // The ID token goes in `Authorization`, NOT `X-Serverless-Authorization`. Both authenticate
  // the invoker at the Cloud Run perimeter, but they differ in one load-bearing way: Cloud Run
  // CONSUMES `X-Serverless-Authorization` (it does not forward it), while it FORWARDS
  // `Authorization` to the container. The api-mode service verifies the same ID token a second
  // time (defense in depth against `invokerIamDisabled`), so it must be able to READ it — which
  // it only can if the token was forwarded. Using X-Serverless would let the perimeter pass and
  // then the app reject the legitimate caller with 401 (verified live 2026-07-20). There is no
  // separate user token contending for `Authorization` here, so this is a clean single use.
  headers.set('Authorization', `Bearer ${material.token}`);
}

async function toSdkError(response: Response, fallbackCorrelationId: string): Promise<GlobeSdkError> {
  const fallbackCode: GlobeApiErrorCode = response.status === 401
    ? 'authentication_required'
    : response.status === 403
      ? 'access_denied'
      : response.status === 404
        ? 'not_found'
        : response.status === 409
          ? 'conflict'
          : response.status === 429
            ? 'rate_limited'
            : response.status >= 500
              ? 'dependency_unavailable'
              : 'invalid_request';

  let payload: GlobeApiErrorV1 | undefined;
  try {
    payload = (await response.json()) as GlobeApiErrorV1;
  } catch {
    // The SDK intentionally never returns a raw upstream body.
  }

  return new GlobeSdkError({
    code: payload?.error.code ?? fallbackCode,
    message: payload?.error.message ?? 'globe_request_failed',
    status: response.status,
    retryable: payload?.error.retryable ?? (response.status === 429 || response.status >= 500),
    correlationId: payload?.error.correlationId ?? fallbackCorrelationId,
  });
}
