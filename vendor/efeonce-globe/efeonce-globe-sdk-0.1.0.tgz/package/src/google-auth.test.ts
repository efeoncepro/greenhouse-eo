import assert from 'node:assert/strict';
import test from 'node:test';

import { createGoogleAdcIdTokenAuth } from './google-auth.ts';

test('uses ADC identity tokens with an exact audience and caches the client', async () => {
  let clientCalls = 0;
  let tokenCalls = 0;
  const auth = createGoogleAdcIdTokenAuth({
    audience: 'https://globe-api-abc.run.app',
    auth: {
      async getIdTokenClient(audience) {
        clientCalls += 1;
        assert.equal(audience, 'https://globe-api-abc.run.app');
        return {
          idTokenProvider: {
            async fetchIdToken(tokenAudience) {
              tokenCalls += 1;
              assert.equal(tokenAudience, audience);
              return `token-${tokenCalls}`;
            },
          },
        };
      },
    },
  });

  assert.deepEqual(
    await auth.getAuthMaterial({
      audience: 'https://globe-api-abc.run.app',
      method: 'GET',
      url: 'https://globe-api-abc.run.app/v1/health',
    }),
    { kind: 'cloud-run-id-token', token: 'token-1' },
  );
  await auth.getAuthMaterial({
    audience: 'https://globe-api-abc.run.app',
    method: 'GET',
    url: 'https://globe-api-abc.run.app/v1/health',
  });

  assert.equal(clientCalls, 1);
  assert.equal(tokenCalls, 2);
});

test('fails closed when the request audience differs', async () => {
  const auth = createGoogleAdcIdTokenAuth({
    audience: 'https://globe-api-abc.run.app',
    auth: {
      async getIdTokenClient() {
        throw new Error('must_not_be_called');
      },
    },
  });

  await assert.rejects(
    auth.getAuthMaterial({
      audience: 'https://attacker.example.com',
      method: 'GET',
      url: 'https://attacker.example.com/v1/health',
    }),
    { message: 'globe_google_auth_audience_mismatch' },
  );
});
