import assert from 'node:assert/strict';
import test from 'node:test';

import { GlobeClient, GlobeSdkError, createCallbackAuth } from './index.ts';

test('calls Globe with correlation context and Cloud Run auth without exposing an actor header', async () => {
  let captured: Request | undefined;
  const client = new GlobeClient({
    baseUrl: 'https://globe-api-abc.run.app',
    auth: createCallbackAuth(async request => {
      assert.equal(request.audience, 'https://globe-api-abc.run.app');
      return { kind: 'cloud-run-id-token', token: 'signed-id-token' };
    }),
    fetch: async (input, init) => {
      captured = new Request(input, init);
      return Response.json({
        schemaVersion: '1',
        service: 'efeonce-globe',
        apiVersion: 'v1',
        status: 'ok',
        checkedAt: '2026-07-19T12:00:00.000Z',
      });
    },
  });

  const health = await client.health({ correlationId: 'corr_01', workspaceId: 'ws_internal' });

  assert.equal(health.status, 'ok');
  assert.equal(captured?.url, 'https://globe-api-abc.run.app/v1/health');
  assert.equal(captured?.headers.get('x-serverless-authorization'), 'Bearer signed-id-token');
  assert.equal(captured?.headers.get('x-globe-correlation-id'), 'corr_01');
  assert.equal(captured?.headers.get('x-globe-workspace-id'), 'ws_internal');
  assert.equal(captured?.headers.has('x-globe-actor-id'), false);
});

test('sanitizes non-contract upstream errors', async () => {
  const client = new GlobeClient({
    baseUrl: 'https://globe-api-abc.run.app',
    auth: createCallbackAuth(async () => ({ kind: 'bearer', token: 'opaque' })),
    fetch: async () => new Response('database password leaked', { status: 500 }),
  });

  await assert.rejects(
    client.health({ correlationId: 'corr_02' }),
    (error: unknown) => {
      assert.ok(error instanceof GlobeSdkError);
      assert.equal(error.message, 'globe_request_failed');
      assert.equal(error.code, 'dependency_unavailable');
      assert.equal(error.retryable, true);
      assert.equal(error.message.includes('password'), false);
      return true;
    },
  );
});

test('rejects insecure remote endpoints and header injection', async () => {
  assert.throws(
    () => new GlobeClient({
      baseUrl: 'http://globe.example.com',
      auth: createCallbackAuth(async () => ({ kind: 'bearer', token: 'opaque' })),
    }),
    { message: 'globe_sdk_base_url_insecure' },
  );

  const client = new GlobeClient({
    baseUrl: 'http://localhost:8080',
    auth: createCallbackAuth(async () => ({ kind: 'bearer', token: 'opaque' })),
    fetch: async () => Response.json({}),
  });

  await assert.rejects(
    client.health({ correlationId: 'safe\r\nX-Injected: true' }),
    { message: 'globe_sdk_correlation_id_invalid' },
  );
});
