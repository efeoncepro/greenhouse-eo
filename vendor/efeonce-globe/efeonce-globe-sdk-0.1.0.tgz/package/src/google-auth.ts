import { GoogleAuth } from 'google-auth-library';

import type { GlobeAuthStrategy } from './index.js';

export type GoogleIdTokenClient = Readonly<{
  idTokenProvider: Readonly<{
    fetchIdToken(audience: string): Promise<string>;
  }>;
}>;

export type GoogleIdTokenClientFactory = Readonly<{
  getIdTokenClient(audience: string): Promise<GoogleIdTokenClient>;
}>;

export type GoogleAdcAuthOptions = Readonly<{
  audience: string;
  auth?: GoogleIdTokenClientFactory;
}>;

/**
 * Server-only Cloud Run authentication backed by Application Default Credentials.
 * Production resolves the attached service identity. Local development resolves
 * developer ADC or an explicitly impersonated service account.
 */
export function createGoogleAdcIdTokenAuth(options: GoogleAdcAuthOptions): GlobeAuthStrategy {
  const audience = normalizeAudience(options.audience);
  const auth = options.auth ?? new GoogleAuth();
  let clientPromise: Promise<GoogleIdTokenClient> | undefined;

  return {
    async getAuthMaterial(request) {
      if (request.audience !== audience) throw new Error('globe_google_auth_audience_mismatch');
      clientPromise ??= auth.getIdTokenClient(audience);
      const client = await clientPromise;
      const token = await client.idTokenProvider.fetchIdToken(audience);

      if (!token || /[\r\n]/.test(token)) throw new Error('globe_google_auth_token_invalid');
      return { kind: 'cloud-run-id-token', token };
    },
  };
}

function normalizeAudience(value: string): string {
  const url = new URL(value);
  if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash) {
    throw new Error('globe_google_auth_audience_invalid');
  }
  return url.origin;
}
