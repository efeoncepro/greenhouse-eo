import type {
  GlobeApiErrorCode,
  GlobeApiErrorV1,
  GlobeHealthV1,
} from '@efeonce-globe/contracts';

const SDK_VERSION = '0.1.0' as const;
const SAFE_CONTEXT_VALUE = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/;

export type GlobeAuthMaterial =
  | Readonly<{ kind: 'bearer'; token: string }>
  | Readonly<{ kind: 'cloud-run-id-token'; token: string }>;

export type GlobeAuthRequest = Readonly<{
  audience: string;
  method: string;
  url: string;
}>;

export interface GlobeAuthStrategy {
  getAuthMaterial(request: GlobeAuthRequest): Promise<GlobeAuthMaterial>;
}

export type GlobeInvocationContext = Readonly<{
  correlationId?: string;
  workspaceId?: string;
  idempotencyKey?: string;
  signal?: AbortSignal;
}>;

export type GlobeClientOptions = Readonly<{
  baseUrl: string;
  audience?: string;
  auth: GlobeAuthStrategy;
  fetch?: typeof globalThis.fetch;
  timeoutMs?: number;
}>;

export class GlobeSdkError extends Error {
  readonly code: GlobeApiErrorCode | 'transport_error' | 'invalid_response';
  readonly status: number | undefined;
  readonly retryable: boolean;
  readonly correlationId: string | undefined;

  constructor(options: {
    code: GlobeApiErrorCode | 'transport_error' | 'invalid_response';
    message: string;
    status?: number;
    retryable: boolean;
    correlationId?: string;
  }) {
    super(options.message);
    this.name = 'GlobeSdkError';
    this.code = options.code;
    this.status = options.status;
    this.retryable = options.retryable;
    this.correlationId = options.correlationId;
  }
}

export class GlobeClient {
  readonly #baseUrl: URL;
  readonly #audience: string;
  readonly #auth: GlobeAuthStrategy;
  readonly #fetch: typeof globalThis.fetch;
  readonly #timeoutMs: number;

  constructor(options: GlobeClientOptions) {
    this.#baseUrl = normalizeServiceUrl(options.baseUrl);
    this.#audience = options.audience ?? this.#baseUrl.origin;
    this.#auth = options.auth;
    this.#fetch = options.fetch ?? globalThis.fetch;
    this.#timeoutMs = options.timeoutMs ?? 10_000;

    if (!Number.isSafeInteger(this.#timeoutMs) || this.#timeoutMs < 100 || this.#timeoutMs > 120_000) {
      throw new Error('globe_sdk_timeout_invalid');
    }
  }

  async health(context: GlobeInvocationContext = {}): Promise<GlobeHealthV1> {
    return this.#request<GlobeHealthV1>('GET', 'v1/health', context);
  }

  async #request<T>(
    method: string,
    path: string,
    context: GlobeInvocationContext,
  ): Promise<T> {
    const url = new URL(path, this.#baseUrl);
    const correlationId = context.correlationId ?? globalThis.crypto.randomUUID();

    validateContextValue('correlation_id', correlationId);
    if (context.workspaceId) validateContextValue('workspace_id', context.workspaceId);
    if (context.idempotencyKey) validateContextValue('idempotency_key', context.idempotencyKey);

    const authMaterial = await this.#auth.getAuthMaterial({
      audience: this.#audience,
      method,
      url: url.toString(),
    });
    const headers = new Headers({
      Accept: 'application/json',
      'X-Globe-Correlation-Id': correlationId,
      'X-Globe-Sdk-Version': SDK_VERSION,
    });

    applyAuthMaterial(headers, authMaterial);
    if (context.workspaceId) headers.set('X-Globe-Workspace-Id', context.workspaceId);
    if (context.idempotencyKey) headers.set('Idempotency-Key', context.idempotencyKey);

    const timeoutSignal = AbortSignal.timeout(this.#timeoutMs);
    const signal = context.signal
      ? AbortSignal.any([context.signal, timeoutSignal])
      : timeoutSignal;

    let response: Response;
    try {
      response = await this.#fetch(url, { method, headers, signal });
    } catch {
      throw new GlobeSdkError({
        code: 'transport_error',
        message: 'globe_transport_failed',
        retryable: true,
        correlationId,
      });
    }

    if (!response.ok) {
      throw await toSdkError(response, correlationId);
    }

    if (!response.headers.get('content-type')?.includes('application/json')) {
      throw new GlobeSdkError({
        code: 'invalid_response',
        message: 'globe_response_not_json',
        status: response.status,
        retryable: false,
        correlationId,
      });
    }

    try {
      return (await response.json()) as T;
    } catch {
      throw new GlobeSdkError({
        code: 'invalid_response',
        message: 'globe_response_invalid',
        status: response.status,
        retryable: false,
        correlationId,
      });
    }
  }
}

export function createCallbackAuth(
  callback: (request: GlobeAuthRequest) => Promise<GlobeAuthMaterial>,
): GlobeAuthStrategy {
  return { getAuthMaterial: callback };
}

function normalizeServiceUrl(value: string): URL {
  const url = new URL(value);
  const isLocal = url.protocol === 'http:' && ['localhost', '127.0.0.1', '::1'].includes(url.hostname);

  if (url.protocol !== 'https:' && !isLocal) throw new Error('globe_sdk_base_url_insecure');
  if (url.username || url.password || url.search || url.hash) throw new Error('globe_sdk_base_url_invalid');
  url.pathname = url.pathname.endsWith('/') ? url.pathname : `${url.pathname}/`;
  return url;
}

function validateContextValue(field: string, value: string): void {
  if (!SAFE_CONTEXT_VALUE.test(value)) throw new Error(`globe_sdk_${field}_invalid`);
}

function applyAuthMaterial(headers: Headers, material: GlobeAuthMaterial): void {
  if (!material.token || /[\r\n]/.test(material.token)) throw new Error('globe_sdk_auth_material_invalid');

  const header = material.kind === 'cloud-run-id-token'
    ? 'X-Serverless-Authorization'
    : 'Authorization';
  headers.set(header, `Bearer ${material.token}`);
}

async function toSdkError(response: Response, fallbackCorrelationId: string): Promise<GlobeSdkError> {
  const fallbackCode: GlobeApiErrorCode = response.status === 401
    ? 'authentication_required'
    : response.status === 403
      ? 'access_denied'
      : response.status === 404
        ? 'not_found'
        : response.status === 409
          ? 'conflict'
          : response.status === 429
            ? 'rate_limited'
            : response.status >= 500
              ? 'dependency_unavailable'
              : 'invalid_request';

  let payload: GlobeApiErrorV1 | undefined;
  try {
    payload = (await response.json()) as GlobeApiErrorV1;
  } catch {
    // The SDK intentionally never returns a raw upstream body.
  }

  return new GlobeSdkError({
    code: payload?.error.code ?? fallbackCode,
    message: payload?.error.message ?? 'globe_request_failed',
    status: response.status,
    retryable: payload?.error.retryable ?? (response.status === 429 || response.status >= 500),
    correlationId: payload?.error.correlationId ?? fallbackCorrelationId,
  });
}
