import type { GlobeCapability } from './capabilities.js';
import type { CreativeCapability } from './index.js';
import type { GovernedRunStateV1 } from './governed-runs.js';
import type { LibraryAssetKeyV1 } from './asset-library.js';

export const GLOBE_PRODUCER_LIVE_FEED_CAPABILITY = 'globe.producer.library.read' satisfies GlobeCapability;

export const GLOBE_PRODUCER_LIVE_FEED_READERS = {
  list: 'globe.producer.feed.live.list',
  changes: 'globe.producer.feed.live.changes',
} as const;

export type ProducerLiveFeedKindV1 = 'active-run' | 'terminal-run' | 'retained-asset';
export type ProducerLiveFeedModeV1 = 'all' | 'active' | 'terminal' | 'retained';
export type ProducerLiveFeedMediaTypeV1 = 'image' | 'video' | 'audio' | 'model-3d' | 'text';

export type ProducerLiveFeedRouteLabelV1 = Readonly<{
  routeId: string;
  model?: Readonly<{ name: string; version?: string }>;
}>;

export type ProducerLiveFeedOutputV1 = Readonly<{
  item: LibraryAssetKeyV1;
  sha256: string;
  mediaType: Exclude<ProducerLiveFeedMediaTypeV1, 'text'>;
  mimeType?: string;
  favorite: boolean;
  containerIds: readonly string[];
  trashedAt?: string;
}>;

type ProducerLiveFeedCommonV1 = Readonly<{
  schemaVersion: '1';
  kind: ProducerLiveFeedKindV1;
  stableKey: string;
  workspaceId: string;
  runId: string;
  experimentId: string;
  revision: number;
  createdAt: string;
  updatedAt: string;
  displayTitle: string;
  capability: CreativeCapability;
  modality: ProducerLiveFeedMediaTypeV1;
  route: ProducerLiveFeedRouteLabelV1;
  spentCredits: number;
}>;

export type ProducerLiveFeedActiveRunItemV1 = ProducerLiveFeedCommonV1 & Readonly<{
  kind: 'active-run';
  state: GovernedRunStateV1;
  coarseProgress: 'waiting' | 'submitting' | 'provider-running' | 'finalizing' | 'cancelling';
  runRevision: number;
}>;

export type ProducerLiveFeedTerminalRunItemV1 = ProducerLiveFeedCommonV1 & Readonly<{
  kind: 'terminal-run';
  state: Extract<GovernedRunStateV1, 'completed' | 'failed' | 'cancelled' | 'timed_out'>;
  coarseProgress: 'terminal';
  runRevision: number;
  terminal: Readonly<{ retryable: boolean; failureReason?: string }>;
}>;

export type ProducerLiveFeedRetainedAssetItemV1 = ProducerLiveFeedCommonV1 & Readonly<{
  kind: 'retained-asset';
  state: 'retained';
  coarseProgress: 'terminal';
  runState: GovernedRunStateV1;
  runRevision: number;
  output: ProducerLiveFeedOutputV1;
}>;

export type UnifiedProducerFeedItemV1 =
  | ProducerLiveFeedActiveRunItemV1
  | ProducerLiveFeedTerminalRunItemV1
  | ProducerLiveFeedRetainedAssetItemV1;

export type ProducerLiveFeedListQueryV1 = Readonly<{
  cursor?: string;
  limit?: number;
  mode?: ProducerLiveFeedModeV1;
  modality?: ProducerLiveFeedMediaTypeV1;
}>;

export type ProducerLiveFeedChangesQueryV1 = Readonly<{
  cursor: string;
  limit?: number;
  modality?: ProducerLiveFeedMediaTypeV1;
}>;

export type ProducerLiveFeedPageV1 = Readonly<{
  schemaVersion: '1';
  items: readonly UnifiedProducerFeedItemV1[];
  watermark: string;
  generatedAt: string;
  nextCursor?: string;
}>;
