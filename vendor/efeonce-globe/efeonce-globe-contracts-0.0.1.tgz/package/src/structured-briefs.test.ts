import assert from 'node:assert/strict';
import { describe, it } from 'node:test';

import {
  BRIEF_INGREDIENT_KINDS,
  GLOBE_PROMPT_COMMANDS,
  GLOBE_PROMPT_READERS,
  GLOBE_RECIPE_COMMANDS,
  GLOBE_RECIPE_READERS,
  type CreativeRecipeV1,
  type PromptEnhancementProposalV1,
} from './index.ts';

describe('structured brief and recipe wire contract (TASK-1493)', () => {
  it('pins all six approved ingredient kinds and stable capability names', () => {
    assert.deepEqual(BRIEF_INGREDIENT_KINDS, ['subject', 'style', 'light', 'framing', 'mood', 'palette']);
    assert.equal(GLOBE_RECIPE_COMMANDS.save, 'globe.lab.recipe.save');
    assert.deepEqual(Object.values(GLOBE_RECIPE_READERS), [
      'globe.lab.recipe.list',
      'globe.lab.recipe.get',
      'globe.lab.recipe.materialize',
    ]);
    assert.deepEqual(Object.values(GLOBE_PROMPT_COMMANDS), [
      'globe.lab.prompt.enhance',
      'globe.lab.prompt.enhancement.accept',
      'globe.lab.prompt.enhancement.reject',
    ]);
    assert.deepEqual(Object.values(GLOBE_PROMPT_READERS), [
      'globe.lab.prompt.history',
      'globe.lab.prompt.enhancement.get',
    ]);
  });

  it('keeps recipe and enhancement projections client-safe', () => {
    const recipe: CreativeRecipeV1 = {
      schemaVersion: '1',
      recipeId: 'recipe-a',
      version: 1,
      workspaceId: 'ws-a',
      title: 'Editorial',
      capability: 'image-generate',
      brief: { schemaVersion: '1', ingredients: [{ kind: 'subject', value: 'A greenhouse', weight: 1 }] },
      createdAt: '2026-07-22T00:00:00.000Z',
    };
    const proposal: PromptEnhancementProposalV1 = {
      schemaVersion: '1',
      proposalId: 'proposal-a',
      status: 'proposed',
      source: { kind: 'text', prompt: 'A greenhouse' },
      proposed: { kind: 'text', prompt: 'An editorial greenhouse portrait' },
      evidence: { method: 'governed-rewrite', methodVersion: '1', model: 'Prompt Editor', policyVersion: '1' },
      createdAt: '2026-07-22T00:00:00.000Z',
    };
    const serialized = JSON.stringify({ recipe, proposal });
    assert.doesNotMatch(serialized, /providerPrompt|providerSlug|vendorCost|margin|secret|apiKey/i);
  });
});
