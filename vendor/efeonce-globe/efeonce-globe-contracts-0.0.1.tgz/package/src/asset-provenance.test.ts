import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import type { GovernedAssetV1, LatestRegionalEditMaskQueryV1, RegisterRegionalEditMaskPayloadV1, RegionalEditMaskTargetQueryV1, RegionalEditMaskV1 } from './asset-provenance.ts';

describe('asset provenance public contract', () => {
  it('has no storage coordinate in its safe projection', () => {
    const asset: GovernedAssetV1 = {
      schemaVersion: '1', assetId: 'asset-1', ownerActorId: 'actor-1', sourceKind: 'private-ingest',
      mediaType: 'image', integrity: { sha256: `sha256:${'a'.repeat(64)}`, byteSize: 10, mimeType: 'image/png' },
      lifecycle: 'quarantined', scan: 'clean', rights: { verdict: 'pending', consent: 'pending' },
      c2pa: { state: 'unavailable' }, retentionClass: 'working-30d', parentAssetIds: [],
      eligibleForGeneration: false, createdAt: '2026-07-22T00:00:00.000Z', updatedAt: '2026-07-22T00:00:00.000Z',
    };
    assert.doesNotMatch(JSON.stringify(asset), /bucket|objectKey|storageHandle|signedUrl|providerUrl/i);
  });
});

describe('regional edit mask contract', () => {
  it('lets the browser name only source and target while the projection carries server authority', () => {
    const request: RegisterRegionalEditMaskPayloadV1 = { sourceAssetId: 'asset-1', targetExperimentId: 'exp-1' };
    assert.deepEqual(Object.keys(request).sort(), ['sourceAssetId', 'targetExperimentId']);
    const mask: RegionalEditMaskV1 = {
      schemaVersion: '1', maskId: 'mask-1', sourceAssetId: 'asset-1',
      target: { experimentId: 'exp-1', attemptId: 'attempt-1', outputSha256: `sha256:${'b'.repeat(64)}`, width: 512, height: 512 },
      state: 'ready', normalizedIntegrity: { sha256: `sha256:${'c'.repeat(64)}`, byteSize: 20, mimeType: 'image/png' },
      rights: { rightsClass: 'internal-owned', issuedBy: 'globe:regional-edit-mask-authority', issuedAt: '2026-07-22T00:00:00Z' },
      createdAt: '2026-07-22T00:00:00Z', updatedAt: '2026-07-22T00:00:00Z',
    };
    assert.equal(mask.target.width, 512);
    assert.doesNotMatch(JSON.stringify(mask), /bucket|objectKey|storageHandle|signedUrl/i);
    const recovery: LatestRegionalEditMaskQueryV1 = { targetExperimentId:'exp-1' };
    const target: RegionalEditMaskTargetQueryV1 = { targetExperimentId:'exp-1' };
    assert.deepEqual(Object.keys(recovery),['targetExperimentId']);
    assert.deepEqual(Object.keys(target),['targetExperimentId']);
  });
});
