import assert from 'node:assert/strict';
import test from 'node:test';

import {
  GLOBE_CAPABILITIES,
  GLOBE_LAB_EXPERIMENT_CAPABILITY,
  GLOBE_PRODUCER_ASSETS_CAPABILITY,
  GLOBE_PRODUCER_ASSET_COMMANDS,
  GLOBE_PRODUCER_ASSET_READERS,
  GLOBE_PRODUCER_READERS,
  GLOBE_SURFACES,
  parseGlobeCapabilities,
  type SurfaceCoverageState,
} from './index.ts';

test('keeps Globe authorization namespaced and role-independent', () => {
  assert.equal(new Set(GLOBE_CAPABILITIES).size, GLOBE_CAPABILITIES.length);
  assert.ok(GLOBE_CAPABILITIES.every(capability => capability.startsWith('globe.')));
  assert.ok(GLOBE_CAPABILITIES.every(capability => !capability.includes('admin')));
  assert.ok(GLOBE_CAPABILITIES.includes('globe.lab.experiment.run'));
  assert.ok(GLOBE_CAPABILITIES.includes('globe.lab.evaluation.run'));
  assert.ok(GLOBE_CAPABILITIES.includes('globe.producer.catalog.read'));
  assert.ok(GLOBE_CAPABILITIES.includes('globe.producer.route.reveal_house'));
  assert.ok(GLOBE_CAPABILITIES.includes('globe.responsibility.manage'));
  assert.ok(GLOBE_CAPABILITIES.includes('globe.responsibility.read'));
  assert.ok(GLOBE_CAPABILITIES.includes('globe.producer.assets.operate'));
  // Its own grant on purpose: registering a voice runs no provider, so it must not imply the
  // Lab's authority to bill one.
  assert.ok(GLOBE_CAPABILITIES.includes('globe.voice.preset.manage'));
  assert.ok(GLOBE_CAPABILITIES.includes('globe.credits.read'));
  assert.ok(GLOBE_CAPABILITIES.includes('globe.credits.reserve'));
  assert.ok(GLOBE_CAPABILITIES.includes('globe.credits.adjust'));
});

test('keeps the producer output side on its own zero-spend authority and vocabulary', () => {
  // The retrieval/annotation authority must never be the Lab's spend grant: reading back a
  // piece you already produced cannot imply the ability to bill a provider.
  assert.notEqual(GLOBE_PRODUCER_ASSETS_CAPABILITY, GLOBE_LAB_EXPERIMENT_CAPABILITY);
  assert.ok(GLOBE_CAPABILITIES.includes(GLOBE_PRODUCER_ASSETS_CAPABILITY));

  // The asset ids are their own map: the catalog readers answer to a different capability.
  const assetIds = [
    ...Object.values(GLOBE_PRODUCER_ASSET_READERS),
    ...Object.values(GLOBE_PRODUCER_ASSET_COMMANDS),
  ];
  const catalogIds = Object.values(GLOBE_PRODUCER_READERS) as readonly string[];
  assert.equal(new Set(assetIds).size, assetIds.length);
  assert.ok(assetIds.every(id => !catalogIds.includes(id)));
  assert.deepEqual(assetIds, [
    'globe.producer.output.get',
    'globe.producer.asset.list',
    'globe.producer.asset.favorite',
    'globe.producer.asset.copyAsReference',
  ]);
});

test('narrows untrusted capability lists to the known vocabulary and drops unknowns', () => {
  const parsed = parseGlobeCapabilities([
    'globe.studio.access',
    'globe.admin.everything',
    'globe.run.prepare',
    'globe.studio.access',
  ]);

  assert.deepEqual(parsed, ['globe.studio.access', 'globe.run.prepare']);
});

test('enumerates every Full API Parity surface exactly once', () => {
  assert.deepEqual([...GLOBE_SURFACES], ['ui', 'http', 'sdk', 'mcp', 'cli', 'worker', 'sister-platform', 'e2e']);
  assert.equal(new Set(GLOBE_SURFACES).size, GLOBE_SURFACES.length);
});

test('restricts per-surface coverage to available | policy-blocked | not-applicable', () => {
  const valid: readonly SurfaceCoverageState[] = ['available', 'policy-blocked', 'not-applicable'];
  assert.equal(valid.length, 3);
  // `missing` is intentionally absent: an executable capability that omits a
  // surface fails to typecheck rather than degrading silently.
});
