import assert from 'node:assert/strict';
import { describe, it } from 'node:test';

import {
  canonicalJson,
  canonicalizeGlobeUiDelegationRequest,
  normalizeGlobeUiDelegationRequest,
  parseGlobeUiDelegationClaims,
  type GlobeUiDelegationClaimsV1,
} from './ui-delegation.ts';

const request = {
  method: 'POST',
  path: '/v1/commands',
  bodySha256: `sha256:${'a'.repeat(64)}`,
  capability: 'globe.lab.experiment.prepare',
  correlationId: 'corr-1',
  idempotencyKey: 'idem-1',
} as const;

const claims: GlobeUiDelegationClaimsV1 = {
  schemaVersion: '1',
  iss: 'globe-studio-web',
  aud: 'globe-api-internal',
  purpose: 'ui',
  caller: 'globe-web-runtime@efeonce-globe.iam.gserviceaccount.com',
  actorId: 'greenhouse:user:1',
  workspaceId: 'greenhouse-org:efeonce',
  capabilities: ['globe.lab.experiment.run', 'globe.producer.catalog.read'],
  surface: 'ui',
  request,
  fingerprint: `sha256:${'b'.repeat(64)}`,
  iat: 1_752_883_200,
  exp: 1_752_883_230,
  jti: 'delegation-1',
};

describe('Globe UI delegation contract', () => {
  it('canonicalizes JSON recursively independent of object insertion order', () => {
    assert.equal(
      canonicalJson({ z: 1, a: { y: true, x: ['two', 1] } }),
      '{"a":{"x":["two",1],"y":true},"z":1}',
    );
  });

  it('normalizes the method and serializes the complete request fingerprint input deterministically', () => {
    assert.deepEqual(normalizeGlobeUiDelegationRequest({ ...request, method: 'post' }), request);
    assert.equal(
      canonicalizeGlobeUiDelegationRequest(request),
      canonicalizeGlobeUiDelegationRequest({ ...request }),
    );
  });

  it('parses the exact V1 claims contract', () => {
    assert.deepEqual(parseGlobeUiDelegationClaims(claims), claims);
  });

  it('rejects unknown fields, unknown/duplicate/unsorted capabilities and malformed request bindings', () => {
    assert.equal(parseGlobeUiDelegationClaims({ ...claims, elevated: true }), undefined);
    assert.equal(parseGlobeUiDelegationClaims({ ...claims, capabilities: ['globe.admin.everything'] }), undefined);
    assert.equal(parseGlobeUiDelegationClaims({ ...claims, capabilities: ['globe.lab.experiment.run', 'globe.lab.experiment.run'] }), undefined);
    assert.equal(parseGlobeUiDelegationClaims({ ...claims, capabilities: [...claims.capabilities].reverse() }), undefined);
    assert.equal(parseGlobeUiDelegationClaims({ ...claims, request: { ...request, path: 'https://private.example/v1' } }), undefined);
    assert.equal(parseGlobeUiDelegationClaims({ ...claims, request: { ...request, bodySha256: 'not-a-hash' } }), undefined);
  });

  it('rejects non-ui purpose/surface and TTL fields with the wrong representation', () => {
    assert.equal(parseGlobeUiDelegationClaims({ ...claims, purpose: 'http' }), undefined);
    assert.equal(parseGlobeUiDelegationClaims({ ...claims, surface: 'http' }), undefined);
    assert.equal(parseGlobeUiDelegationClaims({ ...claims, iat: String(claims.iat) }), undefined);
  });
});
