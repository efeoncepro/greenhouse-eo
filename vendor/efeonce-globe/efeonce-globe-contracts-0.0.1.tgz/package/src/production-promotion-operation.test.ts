import assert from 'node:assert/strict';
import { describe, it } from 'node:test';

import { GLOBE_CAPABILITIES, parseGlobeCapabilities } from './capabilities.ts';
import {
  GLOBE_PRODUCTION_PROMOTION_CAPABILITIES,
  GLOBE_PRODUCTION_PROMOTION_COMMANDS,
  GLOBE_PRODUCTION_PROMOTION_READERS,
  PRODUCTION_PROMOTION_OPERATION_STATES,
} from './production-promotion-operation.ts';

describe('production promotion operation contract', () => {
  it('publishes every least-privilege capability through the canonical registry', () => {
    const capabilities = Object.values(GLOBE_PRODUCTION_PROMOTION_CAPABILITIES);
    for (const capability of capabilities) assert.ok(GLOBE_CAPABILITIES.includes(capability));
    assert.deepEqual(parseGlobeCapabilities([...capabilities, 'unknown']), capabilities);
  });

  it('keeps phase commands and recovery readers explicit', () => {
    assert.equal(GLOBE_PRODUCTION_PROMOTION_COMMANDS.stage, 'globe.production-promotion.operation.stage');
    assert.equal(GLOBE_PRODUCTION_PROMOTION_COMMANDS.promote, 'globe.production-promotion.operation.promote');
    assert.equal(GLOBE_PRODUCTION_PROMOTION_COMMANDS.activate, 'globe.production-promotion.operation.activate');
    assert.equal(GLOBE_PRODUCTION_PROMOTION_COMMANDS.canaryConfirm, 'globe.production-promotion.operation.canary-confirm');
    assert.equal(GLOBE_PRODUCTION_PROMOTION_READERS.stalled, 'globe.production-promotion.operation.stalled');
    assert.ok(PRODUCTION_PROMOTION_OPERATION_STATES.includes('rollback_failed'));
    assert.ok(PRODUCTION_PROMOTION_OPERATION_STATES.includes('canary_passed'));
  });
});
