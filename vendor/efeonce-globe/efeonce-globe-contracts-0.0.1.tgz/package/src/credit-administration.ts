import type { GlobeCapability } from './capabilities.ts';
import type { CreditFundingBreakdownV1, StudioCredits } from './credits.ts';

export const GLOBE_CREDIT_ADMIN_CAPABILITIES = {
  poolRead:'globe.credits.pool.read', poolManage:'globe.credits.pool.manage',
  grantRead:'globe.credits.grant.read', grantIssue:'globe.credits.grant.issue', grantCorrect:'globe.credits.grant.correct',
  policyRead:'globe.credits.policy.read', policyManage:'globe.credits.policy.manage',
  budgetRead:'globe.credits.budget.read', budgetManage:'globe.credits.budget.manage',
  forecastRead:'globe.credits.forecast.read',
} as const satisfies Readonly<Record<string, GlobeCapability>>;

export const GLOBE_CREDIT_ADMIN_COMMANDS = {
  createPool:'globe.credits.pool.create', activatePool:'globe.credits.pool.activate', pausePool:'globe.credits.pool.pause', resumePool:'globe.credits.pool.resume', closePool:'globe.credits.pool.close',
  issueGrant:'globe.credits.grant.issue', cancelPendingGrant:'globe.credits.grant.cancel', correctGrant:'globe.credits.grant.correct',
  publishPolicy:'globe.credits.policy.publish', supersedePolicy:'globe.credits.policy.supersede',
  assignProjectBudget:'globe.credits.budget.assign', reviseProjectBudget:'globe.credits.budget.revise', pauseProjectBudget:'globe.credits.budget.pause',
  acknowledgeAlert:'globe.credits.alert.acknowledge',
} as const;

export const GLOBE_CREDIT_ADMIN_READERS = {
  pool:'globe.credits.pool.get', pools:'globe.credits.pool.list', grant:'globe.credits.grant.get', grants:'globe.credits.grant.list',
  policy:'globe.credits.policy.effective.get', budgets:'globe.credits.budget.list', evaluate:'globe.credits.budget.evaluate',
  availability:'globe.credits.budget.availability.get', forecast:'globe.credits.forecast.get', alerts:'globe.credits.alert.list',
} as const;

export type CreditAdminApprovalV1 = Readonly<{ proposedBy:string; proposalDigest:string; proposedAt:string; expiresAt:string }>;
export type CreditPoolStatusV1 = 'draft'|'active'|'paused'|'closed';
export type CreditPoolV1 = Readonly<{ schemaVersion:'1'; poolId:string; workspaceId:string; name:string; status:CreditPoolStatusV1; priority:number; periodStart:string; periodEnd:string; capabilityScopes:readonly string[]; version:number; createdBy:string; createdAt:string; updatedAt:string }>;
export type CreditGrantKindV1 = 'internal'|'engagement'|'promotional'|'corrective';
export type CreditGrantStatusV1 = 'pending'|'posted'|'cancelled'|'corrected';
export type CreditGrantV1 = Readonly<{ schemaVersion:'1'; grantId:string; workspaceId:string; poolId:string; kind:CreditGrantKindV1; credits:StudioCredits; periodStart:string; periodEnd:string; status:CreditGrantStatusV1; sourceId:string; reasonCode:string; proposedBy:string; confirmedBy?:string; allocationEntryId?:string; correctionEntryId?:string; createdAt:string; updatedAt:string }>;
export type CreditBudgetPolicyV1 = Readonly<{ schemaVersion:'1'; policyId:string; workspaceId:string; version:number; status:'active'|'superseded'; monthlyCap:StudioCredits; lowBalanceThreshold:StudioCredits; fundingPriority:readonly string[]; effectiveAt:string; proposedBy:string; confirmedBy:string; createdAt:string; supersededAt?:string }>;
export type ProjectBudgetV1 = Readonly<{ schemaVersion:'1'; budgetId:string; workspaceId:string; projectId:string; version:number; status:'active'|'paused'|'superseded'; capCredits:StudioCredits; periodStart:string; periodEnd:string; proposedBy:string; confirmedBy:string; createdAt:string; updatedAt:string }>;
export type CreditBudgetEvaluationV1 = Readonly<{ schemaVersion:'1'; workspaceId:string; projectId?:string; requestedCredits:StudioCredits; allowed:boolean; policyVersion:string; reason?:'pool_paused'|'pool_exhausted'|'project_cap_exceeded'|'month_cap_exceeded'|'policy_unavailable'; fundingBreakdown:readonly CreditFundingBreakdownV1[]; evaluatedAt:string; authoritative:false }>;
export type CreditBudgetAvailabilityV1 = Readonly<{ schemaVersion:'1'; workspaceId:string; projectId?:string; ledgerAvailable:StudioCredits; policyAvailable:StudioCredits; effectiveAvailable:StudioCredits; reserved:StudioCredits; spentInPeriod:StudioCredits; policyVersion:string; asOf:string }>;
export type CreditExhaustionForecastV1 = Readonly<{ schemaVersion:'1'; workspaceId:string; projectId?:string; status:'available'|'insufficient-data'; observedDays:number; averageDailyCredits?:number; effectiveAvailable:StudioCredits; estimatedDaysRemaining?:number; confidence:'low'|'medium'; coverageStart?:string; coverageEnd?:string; computedAt:string; freshnessSeconds:number }>;
export type CreditBudgetAlertV1 = Readonly<{ schemaVersion:'1'; alertId:string; workspaceId:string; projectId?:string; kind:'low_balance'|'exhausted'|'expiry_policy_disabled'|'usage_anomaly'|'projection_drift'; severity:'info'|'warning'|'critical'; status:'open'|'acknowledged'; policyVersion?:string; evidence:Readonly<Record<string,string|number|boolean>>; createdAt:string; acknowledgedAt?:string; acknowledgedBy?:string }>;

export type CreateCreditPoolPayloadV1 = Readonly<{ name:string; priority:number; periodStart:string; periodEnd:string; capabilityScopes?:readonly string[] }>;
export type CreditPoolTransitionPayloadV1 = Readonly<{ poolId:string; expectedVersion:number; reasonCode:string }>;
export type IssueCreditGrantPayloadV1 = Readonly<{ poolId:string; kind:CreditGrantKindV1; credits:StudioCredits; periodStart:string; periodEnd:string; sourceId:string; reasonCode:string; approval:CreditAdminApprovalV1 }>;
export type CancelPendingCreditGrantPayloadV1 = Readonly<{ grantId:string; reasonCode:string }>;
export type PostCreditGrantCorrectionPayloadV1 = Readonly<{ grantId:string; credits:StudioCredits; reasonCode:string; approval:CreditAdminApprovalV1 }>;
export type PublishCreditBudgetPolicyPayloadV1 = Readonly<{ monthlyCap:StudioCredits; lowBalanceThreshold:StudioCredits; fundingPriority:readonly string[]; effectiveAt:string; approval:CreditAdminApprovalV1 }>;
export type SupersedeCreditBudgetPolicyPayloadV1 = PublishCreditBudgetPolicyPayloadV1 & Readonly<{ expectedPolicyId:string; expectedVersion:number }>;
export type AssignProjectBudgetPayloadV1 = Readonly<{ projectId:string; capCredits:StudioCredits; periodStart:string; periodEnd:string; approval:CreditAdminApprovalV1 }>;
export type ReviseProjectBudgetPayloadV1 = AssignProjectBudgetPayloadV1 & Readonly<{ budgetId:string; expectedVersion:number }>;
export type PauseProjectBudgetPayloadV1 = Readonly<{ budgetId:string; expectedVersion:number; reasonCode:string }>;
export type AcknowledgeCreditBudgetAlertPayloadV1 = Readonly<{ alertId:string }>;
export type CreditAdminListQueryV1 = Readonly<{ limit?:number; status?:string; projectId?:string }>;
export type EvaluateCreditBudgetQueryV1 = Readonly<{ projectId?:string; requestedCredits:StudioCredits; at?:string }>;
export type CreditForecastQueryV1 = Readonly<{ projectId?:string; at?:string; lookbackDays?:number }>;
