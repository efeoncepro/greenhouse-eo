import type { GlobeCapability } from './capabilities.ts';
import type { CreditBalanceV1, CreditFundingBreakdownV1, StudioCredits } from './credits.ts';

export const GLOBE_CREDIT_ADMIN_CAPABILITIES = {
  poolRead:'globe.credits.pool.read', poolManage:'globe.credits.pool.manage',
  grantRead:'globe.credits.grant.read', grantIssue:'globe.credits.grant.issue', grantCorrect:'globe.credits.grant.correct',
  policyRead:'globe.credits.policy.read', policyManage:'globe.credits.policy.manage',
  budgetRead:'globe.credits.budget.read', budgetManage:'globe.credits.budget.manage',
  forecastRead:'globe.credits.forecast.read',
} as const satisfies Readonly<Record<string, GlobeCapability>>;

export const GLOBE_CREDIT_ADMIN_COMMANDS = {
  createPool:'globe.credits.pool.create', activatePool:'globe.credits.pool.activate', pausePool:'globe.credits.pool.pause', resumePool:'globe.credits.pool.resume', closePool:'globe.credits.pool.close',
  issueGrant:'globe.credits.grant.issue', cancelPendingGrant:'globe.credits.grant.cancel', correctGrant:'globe.credits.grant.correct',
  publishPolicy:'globe.credits.policy.publish', supersedePolicy:'globe.credits.policy.supersede',
  assignProjectBudget:'globe.credits.budget.assign', reviseProjectBudget:'globe.credits.budget.revise', pauseProjectBudget:'globe.credits.budget.pause',
  acknowledgeAlert:'globe.credits.alert.acknowledge',
} as const;

export const GLOBE_CREDIT_ADMIN_READERS = {
  pool:'globe.credits.pool.get', pools:'globe.credits.pool.list', grant:'globe.credits.grant.get', grants:'globe.credits.grant.list',
  policy:'globe.credits.policy.effective.get', budgets:'globe.credits.budget.list', evaluate:'globe.credits.budget.evaluate',
  availability:'globe.credits.budget.availability.get', forecast:'globe.credits.forecast.get', alerts:'globe.credits.alert.list',
} as const;

export type CreditAdminApprovalV1 = Readonly<{ proposedBy:string; proposalDigest:string; proposedAt:string; expiresAt:string }>;

/**
 * Por que existe una fase, si el codigo canonico ya dice `conflict`.
 *
 * El transporte colapsa TODA negacion de credito en `conflict` a proposito: la taxonomia es
 * compartida y no debe filtrar saldos, politica ni payload. La consecuencia medida (ISSUE-124) es
 * que una aprobacion vencida, un digest que no calza y un pool pausado son INDISTINGUIBLES desde
 * afuera, asi que el operador no puede saber si tiene que renovar la aprobacion, conseguir un
 * segundo actor o activar un pool. Peor: "la aprobacion era valida" no queda PROBADO por el 409,
 * porque una aprobacion invalida devuelve exactamente el mismo codigo.
 *
 * La fase resuelve eso y nada mas: nombra QUE control rechazo, nunca CUANTO habia ni QUE politica
 * regia. Es un enum CERRADO — una fase nueva rompe el build hasta que alguien decida su nombre —
 * porque prosa libre en este campo es como vuelve a filtrarse el detalle que el colapso protege.
 *
 * REGLA DURA: ningun valor de este union puede contener un monto, un id de politica, un saldo, un
 * fragmento de SQL ni nada derivado del payload. Si una fase nueva necesita un numero para ser
 * util, la fase esta mal nombrada. Hay un test que lo verifica sobre el union completo.
 */
export type CreditDenialPhaseV1 =
  // Evidencia de aprobacion (maker/checker). Las tres son acciones DISTINTAS del operador:
  // conseguir un segundo actor, renovar la propuesta, o re-firmarla.
  | 'approval_self_confirmed'
  | 'approval_expired'
  | 'approval_invalid'
  // Estado del agregado administrado.
  | 'pool_not_active'
  | 'pool_transition_illegal'
  | 'grant_state_conflict'
  | 'budget_state_conflict'
  | 'policy_already_active'
  | 'version_conflict'
  // Reintento con la misma clave de idempotencia y distinto cuerpo. No es un error del dominio: es
  // el guard de replay funcionando, y decirlo evita que el operador salga a "arreglar" el pool.
  | 'replay_fingerprint_mismatch'
  // Negaciones del ledger y del ciclo de vida comercial. REUSAN el `code` que esas clases ya
  // exponen; se declaran aca para que exista UN solo vocabulario de fase en el cable.
  | 'insufficient_balance'
  | 'budget_denied'
  | 'hard_cap_exceeded'
  | 'approval_stale';

/**
 * El union completo, en runtime, para que un test pueda recorrerlo. Un valor nuevo en el type sin
 * su entrada aca rompe el build (`satisfies` exhaustivo en ambas direcciones).
 */
export const CREDIT_DENIAL_PHASES = [
  'approval_self_confirmed','approval_expired','approval_invalid',
  'pool_not_active','pool_transition_illegal','grant_state_conflict','budget_state_conflict',
  'policy_already_active','version_conflict','replay_fingerprint_mismatch',
  'insufficient_balance','budget_denied','hard_cap_exceeded','approval_stale',
] as const satisfies readonly CreditDenialPhaseV1[];

/**
 * `satisfies` solo prueba que cada elemento del array es una fase valida. Esto prueba la direccion
 * que falta — que cada fase del union esta en el array — asi que agregar un valor al type sin su
 * entrada aca ROMPE EL BUILD. Sin este alias, el test de "ninguna fase filtra un monto" recorreria
 * un array incompleto y pasaria en verde sin haber mirado la fase nueva.
 */
type CreditDenialPhaseCoverage = CreditDenialPhaseV1 extends (typeof CREDIT_DENIAL_PHASES)[number] ? true : never;
export type CreditDenialPhaseCoverageV1 = CreditDenialPhaseCoverage;
export type CreditPoolStatusV1 = 'draft'|'active'|'paused'|'closed';
export type CreditPoolV1 = Readonly<{ schemaVersion:'1'; poolId:string; workspaceId:string; name:string; status:CreditPoolStatusV1; priority:number; periodStart:string; periodEnd:string; capabilityScopes:readonly string[]; version:number; createdBy:string; createdAt:string; updatedAt:string }>;
export type CreditGrantKindV1 = 'internal'|'engagement'|'promotional'|'corrective';
export type CreditGrantStatusV1 = 'pending'|'posted'|'cancelled'|'corrected';
export type CreditGrantV1 = Readonly<{ schemaVersion:'1'; grantId:string; workspaceId:string; poolId:string; kind:CreditGrantKindV1; credits:StudioCredits; periodStart:string; periodEnd:string; status:CreditGrantStatusV1; sourceId:string; reasonCode:string; proposedBy:string; confirmedBy?:string; allocationEntryId?:string; correctionEntryId?:string; createdAt:string; updatedAt:string }>;
export type CreditBudgetPolicyV1 = Readonly<{ schemaVersion:'1'; policyId:string; workspaceId:string; version:number; status:'active'|'superseded'; monthlyCap:StudioCredits; lowBalanceThreshold:StudioCredits; fundingPriority:readonly string[]; effectiveAt:string; proposedBy:string; confirmedBy:string; createdAt:string; supersededAt?:string }>;
export type ProjectBudgetV1 = Readonly<{ schemaVersion:'1'; budgetId:string; workspaceId:string; projectId:string; version:number; status:'active'|'paused'|'superseded'; capCredits:StudioCredits; periodStart:string; periodEnd:string; proposedBy:string; confirmedBy:string; createdAt:string; updatedAt:string }>;
export type CreditPeriodV1 = Readonly<{
  schemaVersion: '1';
  timezone: 'UTC';
  start: string;
  end: string;
}>;
export type CreditDecisionBlockerV1 =
  | 'pool_paused'
  | 'pool_exhausted'
  | 'project_cap_exceeded'
  | 'month_cap_exceeded'
  | 'policy_unavailable';
export type CreditDecisionSnapshotV2 = Readonly<{
  schemaVersion: '2';
  workspaceId: string;
  projectId?: string;
  capabilityScope?: string;
  requestedCredits: StudioCredits;
  allowed: boolean;
  policyVersion: string;
  lowBalanceThreshold?: StudioCredits;
  period: CreditPeriodV1;
  ledgerAvailable: StudioCredits;
  monthly: Readonly<{ cap: StudioCredits; spent: StudioCredits; held: StudioCredits; remaining: StudioCredits }>;
  project?: Readonly<{ cap: StudioCredits; spent: StudioCredits; held: StudioCredits; remaining: StudioCredits }>;
  eligibleFunding: StudioCredits;
  effectiveAvailable: StudioCredits;
  /** Primer pool elegible segun el mismo orden canonico usado para asignar funding. */
  recommendedFundingPoolId?: string;
  blockers: readonly CreditDecisionBlockerV1[];
  fundingBreakdown: readonly CreditFundingBreakdownV1[];
  coverage: Readonly<{ periodStart: string; periodEnd: string; candidateCount: number }>;
  freshnessSeconds: number;
  asOf: string;
}>;
export type CreditCapacityStatusV1 = Readonly<{
  schemaVersion: '1';
  audience: 'operator';
  state: 'ready' | 'limited' | 'blocked' | 'unknown';
  decision?: CreditDecisionSnapshotV2;
  unavailable?: Readonly<{
    period: CreditPeriodV1;
    blockers: readonly CreditDecisionBlockerV1[];
    coverage: CreditDecisionSnapshotV2['coverage'];
    freshnessSeconds: number;
    asOf: string;
  }>;
  historicalLedger: Pick<CreditBalanceV1, 'allocated' | 'reserved' | 'spent' | 'adjusted' | 'available' | 'asOf'>;
}>;
export type CreditCapacitySelfStatusV1 = Readonly<{
  schemaVersion: '1';
  audience: 'workspace-member';
  state: 'ready' | 'low' | 'limited' | 'blocked' | 'unknown';
  coverage: 'complete' | 'unavailable';
  period: CreditPeriodV1;
  effectiveAvailable?: StudioCredits;
  monthly?: Readonly<{ cap: StudioCredits; spent: StudioCredits; held: StudioCredits; remaining: StudioCredits }>;
  funding?: Readonly<{ eligible: StudioCredits; sourceCount: number }>;
  historicalLedger: Pick<CreditBalanceV1, 'available' | 'reserved' | 'spent' | 'asOf'>;
  dailyFence?: Readonly<{ day: string; cap: StudioCredits; committed: StudioCredits; remaining: StudioCredits; asOf: string }>;
  blockers: readonly CreditDecisionBlockerV1[];
  freshnessSeconds: number;
  asOf: string;
}>;
export type CreditCapacitySelfQueryV1 = Readonly<{
  projectId?: string;
  capabilityScope?: string;
  at?: string;
}>;
export type CreditCapacityQueryV1 = Readonly<{
  requestedCredits: StudioCredits;
  projectId?: string;
  capabilityScope?: string;
  at?: string;
}>;
export type CreditBudgetEvaluationV1 = Readonly<{ schemaVersion:'1'; workspaceId:string; projectId?:string; requestedCredits:StudioCredits; allowed:boolean; policyVersion:string; reason?:'pool_paused'|'pool_exhausted'|'project_cap_exceeded'|'month_cap_exceeded'|'policy_unavailable'; fundingBreakdown:readonly CreditFundingBreakdownV1[]; evaluatedAt:string; authoritative:false }>;
export type CreditBudgetAvailabilityV1 = Readonly<{ schemaVersion:'1'; workspaceId:string; projectId?:string; ledgerAvailable:StudioCredits; policyAvailable:StudioCredits; effectiveAvailable:StudioCredits; reserved:StudioCredits; spentInPeriod:StudioCredits; policyVersion:string; asOf:string }>;
export type CreditExhaustionForecastV1 = Readonly<{ schemaVersion:'1'; workspaceId:string; projectId?:string; status:'available'|'insufficient-data'; observedDays:number; averageDailyCredits?:number; effectiveAvailable:StudioCredits; estimatedDaysRemaining?:number; confidence:'low'|'medium'; coverageStart?:string; coverageEnd?:string; computedAt:string; freshnessSeconds:number }>;
export type CreditBudgetAlertV1 = Readonly<{ schemaVersion:'1'; alertId:string; workspaceId:string; projectId?:string; kind:'low_balance'|'exhausted'|'expiry_policy_disabled'|'usage_anomaly'|'projection_drift'; severity:'info'|'warning'|'critical'; status:'open'|'acknowledged'; policyVersion?:string; evidence:Readonly<Record<string,string|number|boolean>>; createdAt:string; acknowledgedAt?:string; acknowledgedBy?:string }>;

export type CreateCreditPoolPayloadV1 = Readonly<{ name:string; priority:number; periodStart:string; periodEnd:string; capabilityScopes?:readonly string[] }>;
export type CreditPoolTransitionPayloadV1 = Readonly<{ poolId:string; expectedVersion:number; reasonCode:string }>;
export type IssueCreditGrantPayloadV1 = Readonly<{ poolId:string; kind:CreditGrantKindV1; credits:StudioCredits; periodStart:string; periodEnd:string; sourceId:string; reasonCode:string; approval:CreditAdminApprovalV1 }>;
export type CancelPendingCreditGrantPayloadV1 = Readonly<{ grantId:string; reasonCode:string }>;
export type PostCreditGrantCorrectionPayloadV1 = Readonly<{ grantId:string; credits:StudioCredits; reasonCode:string; approval:CreditAdminApprovalV1 }>;
export type PublishCreditBudgetPolicyPayloadV1 = Readonly<{ monthlyCap:StudioCredits; lowBalanceThreshold:StudioCredits; fundingPriority:readonly string[]; effectiveAt:string; approval:CreditAdminApprovalV1 }>;
export type SupersedeCreditBudgetPolicyPayloadV1 = PublishCreditBudgetPolicyPayloadV1 & Readonly<{ expectedPolicyId:string; expectedVersion:number }>;
export type AssignProjectBudgetPayloadV1 = Readonly<{ projectId:string; capCredits:StudioCredits; periodStart:string; periodEnd:string; approval:CreditAdminApprovalV1 }>;
export type ReviseProjectBudgetPayloadV1 = AssignProjectBudgetPayloadV1 & Readonly<{ budgetId:string; expectedVersion:number }>;
export type PauseProjectBudgetPayloadV1 = Readonly<{ budgetId:string; expectedVersion:number; reasonCode:string }>;
export type AcknowledgeCreditBudgetAlertPayloadV1 = Readonly<{ alertId:string }>;
export type CreditAdminListQueryV1 = Readonly<{ limit?:number; status?:string; projectId?:string }>;
export type EvaluateCreditBudgetQueryV1 = Readonly<{ projectId?:string; capabilityScope?:string; requestedCredits:StudioCredits; at?:string }>;
export type CreditForecastQueryV1 = Readonly<{ projectId?:string; at?:string; lookbackDays?:number }>;

/*
 * ── Fondeo del mes como UNA intencion gobernada (TASK-1566 / ADR-015 Slice B) ────────────────────
 *
 * Hoy fondear el mes son TRES actos (emitir grant, mover el tope, y antes de eso conseguir una
 * firma) y ningun cliente puede completarlos: el secreto de aprobacion solo lo lee el runtime, asi
 * que la operacion terminaba pasando por break-glass — cuatro veces para la misma clase de acto.
 *
 * El arreglo NO es ampliar el radio del secreto. Es mover la firma ADENTRO: el runtime ya tiene el
 * secreto y ya tiene el verificador cableado; lo unico que faltaba era una superficie que firmara.
 *
 * Por que DOS comandos y no uno: sin propuesta durable el usuario confirmaria un payload, no un plan
 * evaluado — no veria el tope resultante, el disponible resultante ni la razon actual de
 * `budget.evaluate`, que es justo lo que evita proponer a ciegas y comerse un 409. Y desaparece la
 * ventana de expiracion, que es lo que impide confirmar sobre un estado que ya cambio.
 */
export const GLOBE_CREDIT_FUNDING_CAPABILITIES = {
  propose: 'globe.credits.funding.propose',
  confirm: 'globe.credits.funding.confirm',
  read: 'globe.credits.funding.read',
  reconcile: 'globe.credits.funding.reconcile',
  selfRead: 'globe.credits.capacity.self.read',
} as const satisfies Readonly<Record<string, GlobeCapability>>;

export const GLOBE_CREDIT_FUNDING_COMMANDS = {
  propose: 'globe.credits.month.fund.propose',
  ensure: 'globe.credits.month.ensure.propose',
  confirm: 'globe.credits.month.fund.confirm',
  reconcile: 'globe.credits.funding.operation.reconcile',
} as const;

export const GLOBE_CREDIT_FUNDING_READERS = {
  proposal: 'globe.credits.month.fund.proposal.get',
  capacity: 'globe.credits.capacity.status.get',
  capacitySelf: 'globe.credits.capacity.self.get',
  operation: 'globe.credits.funding.operation.get',
  operations: 'globe.credits.funding.operation.list',
} as const;

/**
 * Usuario autenticado que Greenhouse manda ATRIBUIDO. Puede representar a una persona o a un
 * usuario agente delegado; nunca a la identidad tecnica/workload que transporta la solicitud.
 * Greenhouse autentica la sesion y aplica delegacion, scopes, entitlements y limites. Globe
 * conserva este shape estable como evidencia y rechaza principals tecnicos conocidos.
 *
 * `entitlement` viaja porque el audit de Globe tiene que poder reconstruir CON QUE derecho se
 * confirmo, no solo quien. Sin eso el audit dice "alguien" y la evidencia no sirve en una revision.
 */
export type AuthenticatedUserAttributionV1 = Readonly<{
  principalId: string;
  entitlement: string;
  at: string;
}>;

/** @deprecated Usa `AuthenticatedUserAttributionV1`; se conserva para compatibilidad source-level. */
export type HumanAttributionV1 = AuthenticatedUserAttributionV1;

/** Que se va a hacer, en terminos que un usuario autenticado puede revisar antes de confirmar. */
export type CreditFundingPlanV1 = Readonly<{
  schemaVersion: '1';
  workspaceId: string;
  /** Ausente cuando el plan solo aumenta el tope y no emite un grant. */
  poolId?: string;
  grantCredits: StudioCredits;
  /** Ausente = el tope no se mueve. Presente = la politica vigente se supersede a este valor. */
  monthlyCapAfter?: StudioCredits;
  /** Ausente = la prioridad no cambia. Presente = el rollover interno publica este orden exacto. */
  fundingPriorityAfter?: readonly string[];
  monthlyCapBefore: StudioCredits;
  spentInPeriod: StudioCredits;
  policyAvailableBefore: StudioCredits;
  /** El disponible que la POLITICA va a permitir despues del fondeo, no el del ledger. */
  policyAvailableAfter: StudioCredits;
  /** La razon vigente de `budget.evaluate` al momento de proponer, o ausente si ya permite. */
  currentDenialReason?: CreditBudgetEvaluationV1['reason'];
  periodStart: string;
  periodEnd: string;
}>;

export type CreditFundingInternalCycleV1 = Readonly<{
  schemaVersion: '1';
  poolId: string;
  name: string;
  priority: number;
  periodStart: string;
  periodEnd: string;
  capabilityScopes: readonly string[];
}>;

export type CreditFundingEnsureSnapshotV1 = Readonly<{
  schemaVersion: '1';
  policyId: string;
  policyVersion: number;
  periodStart: string;
  periodEnd: string;
  ledgerAvailable: StudioCredits;
  eligibleFunding: StudioCredits;
  effectiveAvailable: StudioCredits;
  monthlyCap: StudioCredits;
  spentInPeriod: StudioCredits;
  heldInPeriod: StudioCredits;
  recommendedPoolId?: string;
}>;

export type CreditFundingEnsureIntentV1 = Readonly<{
  schemaVersion: '1';
  targetAvailableCredits: StudioCredits;
  maxGrantCredits: StudioCredits;
  maxResultingCapCredits: StudioCredits;
  sourceId: string;
  reasonCode: string;
  snapshot: CreditFundingEnsureSnapshotV1;
  /** Sólo existe cuando el período interno todavía no tiene un pool activo utilizable. */
  cycle?: CreditFundingInternalCycleV1;
}>;

export type CreditFundingProposalStateV1 = 'proposed' | 'confirmed' | 'completed' | 'expired' | 'confirm_failed';

export type CreditFundingProposalV1 = Readonly<{
  schemaVersion: '1';
  proposalId: string;
  workspaceId: string;
  state: CreditFundingProposalStateV1;
  plan: CreditFundingPlanV1;
  /** Intencion acotada que permite detectar drift antes de confirmar un `ensure`. */
  ensureIntent?: CreditFundingEnsureIntentV1;
  /** Digest estable del payload propuesto. Confirmar con otro cuerpo es `replay_fingerprint_mismatch`. */
  fingerprint: string;
  proposedBy: AuthenticatedUserAttributionV1;
  confirmedBy?: AuthenticatedUserAttributionV1;
  expiresAt: string;
  createdAt: string;
  updatedAt: string;
  /** Ids resultantes, poblados al completar. Evidencia de que la mutacion ocurrio. */
  grantId?: string;
  policyId?: string;
  allocationEntryId?: string;
}>;

export type ProposeCreditMonthFundingPayloadV1 = Readonly<{
  poolId: string;
  grantCredits: StudioCredits;
  monthlyCap?: StudioCredits;
  periodStart: string;
  periodEnd: string;
  sourceId: string;
  reasonCode: string;
  proposedBy: AuthenticatedUserAttributionV1;
}>;

export type EnsureCreditMonthFundingPayloadV1 = Readonly<{
  targetAvailableCredits: StudioCredits;
  maxGrantCredits: StudioCredits;
  maxResultingCapCredits: StudioCredits;
  periodStart: string;
  periodEnd: string;
  sourceId: string;
  reasonCode: string;
  proposedBy: AuthenticatedUserAttributionV1;
}>;

export type EnsureCreditMonthFundingOutcomeV1 =
  | Readonly<{ schemaVersion: '1'; status: 'already_funded'; effectiveAvailable: StudioCredits; asOf: string; operation: CreditFundingOperationV1 }>
  | Readonly<{ schemaVersion: '1'; status: 'proposed'; proposal: CreditFundingProposalV1 }>;

export type ConfirmCreditMonthFundingPayloadV1 = Readonly<{
  proposalId: string;
  /** Digest que el confirmador vio. Si no calza el guardado, se rechaza en vez de mutar otra cosa. */
  fingerprint: string;
  confirmedBy: AuthenticatedUserAttributionV1;
}>;

export type CreditFundingProposalQueryV1 = Readonly<{ proposalId: string }>;
export type CreditFundingOperationStateV1 =
  | CreditFundingProposalStateV1
  | 'outcome_unknown'
  | 'reconciled';
export type CreditFundingOperationReceiptV1 = Readonly<{
  schemaVersion: '1';
  outcome: 'completed' | 'expired' | 'no_effect' | 'outcome_unknown';
  grantId?: string;
  policyId?: string;
  allocationEntryId?: string;
  reconciledAt?: string;
  reasonCode?: 'proposal_expired' | 'confirmed_effects_complete' | 'confirmed_no_effect' | 'partial_effects';
}>;
export type CreditFundingOperationV1 = Readonly<{
  schemaVersion: '1';
  operationId: string;
  proposalId: string;
  workspaceId: string;
  state: CreditFundingOperationStateV1;
  fingerprint: string;
  plan: CreditFundingPlanV1;
  proposedBy: AuthenticatedUserAttributionV1;
  confirmedBy?: AuthenticatedUserAttributionV1;
  receipt?: CreditFundingOperationReceiptV1;
  expiresAt: string;
  createdAt: string;
  updatedAt: string;
}>;
export type CreditFundingOperationQueryV1 = Readonly<{ operationId: string }>;
export type CreditFundingOperationListQueryV1 = Readonly<{
  limit?: number;
  state?: CreditFundingOperationStateV1;
  cursor?: string;
}>;
export type CreditFundingOperationPageV1 = Readonly<{
  schemaVersion: '1';
  items: readonly CreditFundingOperationV1[];
  nextCursor?: string;
}>;
export type ReconcileCreditFundingOperationPayloadV1 = Readonly<{ operationId: string }>;
