import type { LabInputMediaType, LabInputRights } from './index.js';
import type { AssetGovernanceStateV1 } from './asset-governance.js';

export const GLOBE_ASSET_PROVENANCE_COMMANDS = {
  initiateIngest: 'globe.asset.ingest.initiate',
  completeIngest: 'globe.asset.ingest.complete',
  submitRightsEvidence: 'globe.asset.rights.submit',
  registerRegionalEditMask: 'globe.asset.regional-edit-mask.register',
} as const;

export const GLOBE_ASSET_PROVENANCE_READERS = {
  status: 'globe.asset.ingest.status',
  get: 'globe.asset.provenance.get',
  list: 'globe.asset.provenance.list',
  regionalEditMaskGet: 'globe.asset.regional-edit-mask.get',
  regionalEditMaskLatest: 'globe.asset.regional-edit-mask.latest',
  regionalEditMaskTarget: 'globe.asset.regional-edit-mask.target',
} as const;

export type AssetSourceKindV1 = 'private-ingest' | 'generated' | 'derived';
export type AssetRetentionClassV1 = 'ephemeral-7d' | 'working-30d' | 'project-1y' | 'legal-hold';
export type AssetLifecycleStateV1 = 'quarantined' | 'active' | 'rejected' | 'expired' | 'deleted';
export type AssetScanStateV1 = 'pending' | 'clean' | 'rejected' | 'failed';
export type AssetRightsVerdictV1 = 'pending' | 'verified' | 'rejected';
export type AssetConsentVerdictV1 = 'not-required' | 'pending' | 'verified' | 'rejected';
export type AssetC2paStateV1 = 'unavailable' | 'unsupported' | 'pending' | 'verified' | 'failed';
export type AssetRightsClassV1 = LabInputRights | 'derived-internal';

export type RegionalEditMaskStateV1 = 'pending' | 'ready' | 'rejected';

/**
 * Target-bound, client-safe authority for a regional edit mask. The caller chooses only the
 * source upload and parent experiment. Attempt/output identity, dimensions, normalized digest
 * and rights are all server-derived. In particular, this is not a generic governed asset with
 * a UI-selected rights label.
 */
export type RegionalEditMaskTargetV1 = Readonly<{
  experimentId: string;
  attemptId: string;
  outputSha256: string;
  width: number;
  height: number;
}>;

export type RegionalEditMaskV1 = Readonly<{
  schemaVersion: '1';
  maskId: string;
  sourceAssetId: string;
  target: RegionalEditMaskTargetV1;
  state: RegionalEditMaskStateV1;
  normalizedIntegrity?: AssetIntegrityV1;
  rights?: Readonly<{ rightsClass: 'internal-owned'; issuedBy: 'globe:regional-edit-mask-authority'; issuedAt: string }>;
  safeCode?: string;
  createdAt: string;
  updatedAt: string;
}>;

export type RegisterRegionalEditMaskPayloadV1 = Readonly<{
  sourceAssetId: string;
  targetExperimentId: string;
}>;

export type RegionalEditMaskQueryV1 = Readonly<{ maskId: string }>;
export type LatestRegionalEditMaskQueryV1 = Readonly<{
  targetExperimentId: string;
}>;
export type RegionalEditMaskTargetQueryV1 = Readonly<{ targetExperimentId: string }>;
export type RegionalEditMaskTargetDataV1 = Readonly<{ schemaVersion: '1'; target: RegionalEditMaskTargetV1 }>;

export type AssetIntegrityV1 = Readonly<{
  sha256: string;
  byteSize: number;
  mimeType: string;
}>;

export type AssetRightsV1 = Readonly<{
  verdict: AssetRightsVerdictV1;
  rightsClass?: AssetRightsClassV1;
  parentRights?: LabInputRights;
  consent: AssetConsentVerdictV1;
  evidenceId?: string;
  verifiedAt?: string;
}>;

export type AssetC2paV1 = Readonly<{
  state: AssetC2paStateV1;
  evidenceDigest?: string;
  signer?: string;
  verifiedAt?: string;
}>;

/**
 * Honest client-safe view of the durable asynchronous governance workflow. A terminal job does
 * not by itself assert that the asset projection is operationally ready: `eligibleForGeneration`
 * remains the authoritative materialized readiness gate.
 */
export type AssetGovernanceProjectionV1 = Readonly<{
  jobId: string;
  state: AssetGovernanceStateV1;
  terminal: boolean;
  lastSafeErrorCode?: string;
}>;

/** Client-safe projection. It intentionally has no bucket, object key, provider URL or scan error. */
export type GovernedAssetV1 = Readonly<{
  schemaVersion: '1';
  assetId: string;
  ownerActorId: string;
  sourceKind: AssetSourceKindV1;
  mediaType: LabInputMediaType;
  integrity: AssetIntegrityV1;
  lifecycle: AssetLifecycleStateV1;
  scan: AssetScanStateV1;
  rights: AssetRightsV1;
  c2pa: AssetC2paV1;
  retentionClass: AssetRetentionClassV1;
  retentionExpiresAt?: string;
  parentAssetIds: readonly string[];
  eligibleForGeneration: boolean;
  governance?: AssetGovernanceProjectionV1;
  createdAt: string;
  updatedAt: string;
}>;

export type InitiatePrivateIngestPayloadV1 = Readonly<{
  mediaType: LabInputMediaType;
  expectedMimeType: string;
  expectedByteSize: number;
  /** Optional client hint for retry diagnostics only; server-observed SHA-256 is authoritative. */
  expectedSha256?: string;
  retentionClass: AssetRetentionClassV1;
}>;

export type InitiatePrivateIngestOutcomeV1 = Readonly<{
  schemaVersion: '1';
  ingestSessionId: string;
  /** Opaque handle for a same-origin upload transport. Never a storage URL. */
  uploadHandle: string;
  expiresAt: string;
  state: 'awaiting-upload' | 'completed' | 'rejected';
  asset?: GovernedAssetV1;
}>;

export type CompletePrivateIngestPayloadV1 = Readonly<{ ingestSessionId: string }>;

export type SubmitAssetRightsEvidencePayloadV1 = Readonly<{
  assetId: string;
  /** Opaque reference to evidence already held by a trusted evidence adapter. */
  evidenceRef: string;
}>;

export type AssetIngestStatusQueryV1 = Readonly<{ ingestSessionId: string }>;
export type AssetProvenanceQueryV1 = Readonly<{ assetId: string }>;
export type ListGovernedAssetsQueryV1 = Readonly<{
  cursor?: string;
  limit?: number;
  mediaType?: LabInputMediaType;
  lifecycle?: AssetLifecycleStateV1;
}>;

export type GovernedAssetPageV1 = Readonly<{
  schemaVersion: '1';
  items: readonly GovernedAssetV1[];
  nextCursor?: string;
}>;

export type AssetProvenanceDataV1 = Readonly<{
  schemaVersion: '1';
  asset: GovernedAssetV1;
  ancestors: readonly GovernedAssetV1[];
}>;
