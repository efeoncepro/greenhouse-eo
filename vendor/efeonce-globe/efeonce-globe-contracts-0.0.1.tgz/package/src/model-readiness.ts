import type { CreativeCapability, FidelityContract, GlobeCapability, HumanCriterionV1 } from './index.js';

export const GLOBE_MODEL_READINESS_CAPABILITIES = {
  read: 'globe.model-readiness.read' as GlobeCapability,
  review: 'globe.model-readiness.review' as GlobeCapability,
  propose: 'globe.model-readiness.propose' as GlobeCapability,
  promote: 'globe.model-readiness.promote' as GlobeCapability,
  pause: 'globe.model-readiness.pause' as GlobeCapability,
  retire: 'globe.model-readiness.retire' as GlobeCapability,
} as const;

export const GLOBE_MODEL_READINESS_COMMANDS = {
  review: 'globe.model-readiness.review.record',
  propose: 'globe.model-readiness.route.propose',
  promote: 'globe.model-readiness.route.promote',
  pause: 'globe.model-readiness.route.pause',
  retire: 'globe.model-readiness.route.retire',
} as const;

export const GLOBE_MODEL_READINESS_READERS = {
  get: 'globe.model-readiness.route.get',
  list: 'globe.model-readiness.route.list',
  history: 'globe.model-readiness.route.history',
  review: 'globe.model-readiness.review.get',
  resolvePromoted: 'globe.model-readiness.route.resolve-promoted',
} as const;

export type ModelReadinessStateV1 = 'candidate' | 'promoted' | 'paused' | 'retired';

/** Exact executable identity. Marketing aliases are deliberately not representable. */
export type ModelRouteIdentityV1 = Readonly<{
  routeId: string;
  capability: CreativeCapability;
  fidelityContract: FidelityContract;
  providerId: string;
  modelId: string;
  modelVersion: string;
}>;

export type ModelReadinessCriterionDecisionV1 = Readonly<{
  criterionId: string;
  pass: boolean;
  note: string;
}>;

/**
 * Immutable human decision over one durable evaluation report. The signature is emitted by a
 * server-side signer over every field except itself; an identifier alone is never evidence.
 */
export type ModelReadinessReviewV1 = Readonly<{
  schemaVersion: '1';
  reviewId: string;
  workspaceId: string;
  route: ModelRouteIdentityV1;
  evaluationReportId: string;
  evaluationReportDigest: string;
  attemptId: string;
  provenanceDigest: string;
  rightsPolicyVersion: string;
  rightsEvidenceDigest: string;
  criteria: readonly ModelReadinessCriterionDecisionV1[];
  decision: 'approved' | 'rejected';
  reviewer: Readonly<{ principalId: string; principalType: 'human' }>;
  correlationId: string;
  createdAt: string;
  attestationSignature: string;
}>;

/** Server-derived evidence projection. None of these digests are accepted from a caller. */
export type ModelReadinessEvidenceV1 = Readonly<{
  evaluationReportId: string;
  reviewId: string;
  attemptId: string;
  evaluationReportDigest: string;
  provenanceDigest: string;
  rightsPolicyVersion: string;
  rightsEvidenceDigest: string;
  reviewAttestationDigest: string;
}>;

export type ModelReadinessRevisionV1 = Readonly<{
  schemaVersion: '1';
  workspaceId: string;
  route: ModelRouteIdentityV1;
  revision: number;
  state: ModelReadinessStateV1;
  evidence: ModelReadinessEvidenceV1;
  reasonCode: string;
  changedBy: Readonly<{ principalId: string; principalType: 'human' | 'service' }>;
  correlationId: string;
  createdAt: string;
}>;

export type RecordModelReadinessReviewPayloadV1 = Readonly<{
  route: ModelRouteIdentityV1;
  evaluationReportId: string;
  rightsPolicyVersion: string;
  criteria: readonly ModelReadinessCriterionDecisionV1[];
  decision: 'approved' | 'rejected';
}>;

export type ProposeModelRoutePayloadV1 = Readonly<{
  route: ModelRouteIdentityV1;
  reviewId: string;
  reasonCode: string;
}>;

export type TransitionModelRoutePayloadV1 = Readonly<{
  routeId: string;
  modelVersion: string;
  expectedRevision: number;
  /** Required for promotion. Pause/retire reuse the current signed evidence to stay fail-safe. */
  reviewId?: string;
  reasonCode: string;
}>;

export type ModelReadinessReviewQueryV1 = Readonly<{ reviewId: string }>;
export type ModelReadinessQueryV1 = Readonly<{ routeId: string; modelVersion: string }>;
export type ModelReadinessListQueryV1 = Readonly<{
  capability?: CreativeCapability;
  state?: ModelReadinessStateV1;
  limit?: number;
  cursor?: string;
}>;
export type ModelReadinessPageV1 = Readonly<{
  schemaVersion: '1';
  items: readonly ModelReadinessRevisionV1[];
  nextCursor?: string;
}>;
export type ModelReadinessHistoryV1 = Readonly<{
  schemaVersion: '1';
  routeId: string;
  modelVersion: string;
  revisions: readonly ModelReadinessRevisionV1[];
}>;

// Compile-time reminder that review criteria are the exact rubric criteria, not free-form votes.
export type ModelReadinessRequiredCriterionV1 = HumanCriterionV1;
