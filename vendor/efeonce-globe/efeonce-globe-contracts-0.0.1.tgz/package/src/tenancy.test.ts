import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { GLOBE_TENANCY_COMMANDS, GLOBE_TENANCY_READERS, type BrokerTenancySnapshotV2 } from './tenancy.ts';

describe('persisted tenancy contract', () => {
  it('uses commands/readers and never places workspace authority in broker payloads', () => {
    assert.equal(GLOBE_TENANCY_COMMANDS.reconcile, 'globe.tenancy.projection.reconcile');
    assert.equal(GLOBE_TENANCY_READERS.effectiveAccess, 'globe.tenancy.access.effective');
    const snapshot = {
      schemaVersion: '1', brokerBindingId: 'binding-a', bindingState: 'active', brokerRevision: 1,
      issuedAt: '2026-07-22T00:00:00.000Z', expiresAt: '2026-07-22T01:00:00.000Z',
      member: { identityIssuer: 'greenhouse', identitySubject: 'subject-a', state: 'active', expiresAt: '2026-07-22T01:00:00.000Z' },
      desiredCapabilities: ['globe.project.read'],
    };
    assert.equal('workspaceId' in snapshot, false);
  });
  it('versions the complete multi-member snapshot without changing the command id',()=>{
    const snapshot:BrokerTenancySnapshotV2={schemaVersion:'2',brokerBindingId:'binding-a',bindingState:'active',workspaceRevision:3,reconciliationId:'receipt-a',issuedAt:'2026-07-22T00:00:00.000Z',expiresAt:'2026-07-22T00:15:00.000Z',members:[{identityIssuer:'greenhouse',identitySubject:'subject-a',state:'active',memberRevision:2,desiredCapabilities:['globe.project.read'],expiresAt:'2026-07-22T00:15:00.000Z'}]};
    assert.equal(GLOBE_TENANCY_COMMANDS.reconcile,'globe.tenancy.projection.reconcile');
    assert.equal(snapshot.members.length,1);
    assert.equal('workspaceId' in snapshot,false);
  });
});
