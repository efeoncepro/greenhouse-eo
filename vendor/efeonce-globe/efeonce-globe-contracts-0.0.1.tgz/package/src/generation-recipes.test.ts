import assert from 'node:assert/strict';
import { describe,it } from 'node:test';
import { GLOBE_GENERATION_RECIPE_COMMANDS,type LabEffectiveGenerationRecipeV1 } from './generation-recipes.ts';

describe('generation recipe contract',()=>{
  it('keeps relaunch and variation on explicit commands',()=>{assert.equal(GLOBE_GENERATION_RECIPE_COMMANDS.relaunch,'globe.lab.experiment.relaunch');assert.equal(GLOBE_GENERATION_RECIPE_COMMANDS.variate,'globe.lab.experiment.variate');});
  it('separates effective evidence from unsupported knobs',()=>{const value:LabEffectiveGenerationRecipeV1={recipe:{seed:42,guidanceScale:7},unsupportedKnobs:['sampler']};assert.equal(value.recipe.seed,42);assert.deepEqual(value.unsupportedKnobs,['sampler']);});
});
