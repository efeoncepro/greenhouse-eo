import type { CreativeCapability, GlobeCapability } from './index.ts';

// TASK-1493 — transport-neutral structured briefs, immutable recipes and prompt evolution.
// Provider prompts, provider slugs and vendor economics are deliberately not representable here.

export const BRIEF_INGREDIENT_KINDS = [
  'subject',
  'style',
  'light',
  'framing',
  'mood',
  'palette',
] as const;

export type BriefIngredientKind = (typeof BRIEF_INGREDIENT_KINDS)[number];

/** A normalized weight is greater than zero and at most one; validation is server-side. */
export type BriefIngredientV1 = Readonly<{
  kind: BriefIngredientKind;
  value: string;
  weight: number;
}>;

export type StructuredBriefV1 = Readonly<{
  schemaVersion: '1';
  ingredients: readonly BriefIngredientV1[];
  notes?: string;
}>;

export const GLOBE_RECIPE_MANAGE_CAPABILITY = 'globe.lab.recipe.author' satisfies GlobeCapability;

export const GLOBE_RECIPE_COMMANDS = {
  save: 'globe.lab.recipe.save',
} as const;

export const GLOBE_RECIPE_READERS = {
  list: 'globe.lab.recipe.list',
  get: 'globe.lab.recipe.get',
  materialize: 'globe.lab.recipe.materialize',
} as const;

export const GLOBE_PROMPT_COMMANDS = {
  enhance: 'globe.lab.prompt.enhance',
  acceptEnhancement: 'globe.lab.prompt.enhancement.accept',
  rejectEnhancement: 'globe.lab.prompt.enhancement.reject',
} as const;

export const GLOBE_PROMPT_READERS = {
  history: 'globe.lab.prompt.history',
  enhancement: 'globe.lab.prompt.enhancement.get',
} as const;

export type CreativeRecipeReferenceV1 = Readonly<{
  recipeId: string;
  version: number;
}>;

/**
 * An immutable, workspace-owned recipe version. A new edit is a new positive integer version;
 * an already-published `(workspaceId, recipeId, version)` is never overwritten.
 */
export type CreativeRecipeV1 = Readonly<{
  schemaVersion: '1';
  recipeId: string;
  version: number;
  workspaceId: string;
  title: string;
  capability: CreativeCapability;
  referenceRoute?: string;
  brief: StructuredBriefV1;
  createdAt: string;
}>;

export type SaveCreativeRecipePayloadV1 = Readonly<{
  /** Stable client-generated identifier, making retries and offline drafts naturally idempotent. */
  recipeId: string;
  version: number;
  title: string;
  capability: CreativeCapability;
  referenceRoute?: string;
  brief: StructuredBriefV1;
}>;

export type CreativeRecipeListQueryV1 = Readonly<{
  limit?: number;
  cursor?: string;
  capability?: CreativeCapability;
}>;

export type CreativeRecipeListDataV1 = Readonly<{
  schemaVersion: '1';
  recipes: readonly CreativeRecipeV1[];
  nextCursor?: string;
}>;

export type CreativeRecipeGetQueryV1 = CreativeRecipeReferenceV1;

export type CreativeRecipeGetDataV1 = Readonly<{
  schemaVersion: '1';
  recipe: CreativeRecipeV1;
}>;

export type MaterializedCreativeRecipeV1 = Readonly<{
  schemaVersion: '1';
  source: CreativeRecipeReferenceV1;
  capability: CreativeCapability;
  referenceRoute?: string;
  brief: StructuredBriefV1;
}>;

export type PromptInputV1 =
  | Readonly<{ kind: 'text'; prompt: string }>
  | Readonly<{ kind: 'structured'; brief: StructuredBriefV1 }>;

export type PromptHistorySourceV1 =
  | Readonly<{ kind: 'direct' }>
  | Readonly<{ kind: 'recipe'; recipe: CreativeRecipeReferenceV1 }>
  | Readonly<{
      kind: 'enhancement';
      proposalId: string;
      methodVersion: string;
      policyVersion: string;
      /** Pinned when enhancement was based on a published recipe version. */
      recipe?: CreativeRecipeReferenceV1;
    }>;

/** Client-safe accepted input evidence. It never contains the provider's compiled prompt. */
export type PromptHistoryEntryV1 = Readonly<{
  schemaVersion: '1';
  historyId: string;
  input: PromptInputV1;
  source: PromptHistorySourceV1;
  correlationId: string;
  createdAt: string;
}>;

export type PromptHistoryQueryV1 = Readonly<{
  limit?: number;
  cursor?: string;
}>;

export type PromptHistoryDataV1 = Readonly<{
  schemaVersion: '1';
  entries: readonly PromptHistoryEntryV1[];
  nextCursor?: string;
}>;

export type EnhancePromptPayloadV1 = Readonly<{
  input: PromptInputV1;
  recipe?: CreativeRecipeReferenceV1;
  intent?: string;
}>;

export type PromptEnhancementEvidenceV1 = Readonly<{
  method: string;
  methodVersion: string;
  model: string;
  modelVersion?: string;
  policyVersion: string;
}>;

/** A reviewable proposal. Producing it never mutates input and never dispatches a creative run. */
export type PromptEnhancementProposalV1 = Readonly<{
  schemaVersion: '1';
  proposalId: string;
  status: 'proposed' | 'accepted' | 'rejected';
  source: PromptInputV1;
  proposed: PromptInputV1;
  recipe?: CreativeRecipeReferenceV1;
  evidence: PromptEnhancementEvidenceV1;
  createdAt: string;
  decidedAt?: string;
}>;

export type PromptEnhancementDecisionPayloadV1 = Readonly<{ proposalId: string }>;
export type PromptEnhancementGetQueryV1 = Readonly<{ proposalId: string }>;

export type PromptEnhancementDataV1 = Readonly<{
  schemaVersion: '1';
  proposal: PromptEnhancementProposalV1;
}>;
