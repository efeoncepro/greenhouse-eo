import type { CreativeCapability, FidelityContract, GlobeCapability, LabInputMediaType } from './index.ts';

// --- Creative Producer route catalog contract (TASK-1500) ----------------------
// The governed route/model catalog is the SSOT of "what a route admits": its
// semantic capability, its output-shape constraints (discriminated by modality),
// its specialty, its supported input modes and its display identity. Three
// identities stay deliberately separate:
//
//   1. `routeId`      — the stable wire key that feeds `referenceRoute` (the
//                       fidelity contract the runner verifies live).
//   2. `model`+`house`— display only, never routes. `model` (name + optional
//                       version) is the CLIENT-FACING quality anchor — a route's
//                       real model IS a positioning asset, so it is public. `house`
//                       is Efeonce's own internal taxonomy for grouping routes,
//                       operator-only. Neither is the provider's wire slug.
//   3. provider slug  — lives ONLY inside the provider adapters; it is never
//                       representable in this contract, and the domain-side
//                       drift guards reject any value that looks like one.
//
// The catalog itself is versioned DATA in the domain package; these are the wire
// types every surface (UI, SDK, MCP, in-process consumers) shares.

/** The capability grant a principal needs to read the producer route catalog. */
export const GLOBE_PRODUCER_CATALOG_CAPABILITY = 'globe.producer.catalog.read' satisfies GlobeCapability;

/**
 * The operator authority that reveals a route's internal HOUSE classification. The
 * model identity (name + version) is a client-facing quality anchor and needs no
 * grant; the `house` is Efeonce's own internal taxonomy for grouping routes, so it
 * is gated. Without this grant the projection fail-closes to the client audience
 * (model only). Deliberately a dedicated capability, not a reuse of the Lab grant.
 */
export const GLOBE_PRODUCER_REVEAL_HOUSE_CAPABILITY = 'globe.producer.route.reveal_house' satisfies GlobeCapability;

/** Canonical producer-catalog reader names (wire identifiers). */
export const GLOBE_PRODUCER_READERS = {
  list: 'globe.producer.catalog.list',
  get: 'globe.producer.catalog.get',
  /** Availability-aware fleet projection (TASK-1554): catalog × readiness/binding → per-route availability. */
  fleet: 'globe.producer.fleet.list',
} as const;

/** The modality a route's constraints are discriminated by. */
export type ProducerRouteModality = 'image' | 'video' | 'audio';

/**
 * The input modes a route can accept. The catalog only DECLARES them; how each
 * mode materializes in the run contract is TASK-1501, and the capabilities that
 * serve the richer modes (frames, motion-source, source-audio) land with
 * TASK-1504 as new data entries — never as new reader code.
 */
export type RouteInputMode =
  | 'prompt'
  | 'reference'
  | 'elements'
  | 'frames'
  | 'motion-source'
  | 'edit-target'
  | 'voice-script'
  | 'source-audio'
  | 'mention';

/**
 * Output-shape constraints, discriminated by modality. The discrimination is a
 * compile-time fail-closed: an image route structurally cannot carry a
 * sample rate, and an audio route cannot carry a resolution. Adding a modality
 * is a new union branch plus data entries — the reader engine never changes.
 */
export type ImageRouteConstraintsV1 = Readonly<{
  modality: 'image';
  quality: readonly string[];
  aspectRatio: readonly string[];
  count: Readonly<{ min: number; max: number }>;
}>;

export type VideoRouteConstraintsV1 = Readonly<{
  modality: 'video';
  resolution: readonly string[];
  duration: Readonly<{ minSeconds: number; maxSeconds: number; stepSeconds?: number }>;
  aspectRatio: readonly string[];
  audioMode: readonly string[];
}>;

export type AudioRouteConstraintsV1 = Readonly<{
  modality: 'audio';
  sampleRate: readonly number[];
  format: readonly string[];
  speed: Readonly<{ min: number; max: number }>;
  volume: Readonly<{ min: number; max: number }>;
  pitch: Readonly<{ min: number; max: number }>;
}>;

export type RouteConstraintsV1 =
  | ImageRouteConstraintsV1
  | VideoRouteConstraintsV1
  | AudioRouteConstraintsV1;

/** Declarative specialty flags. Data, never derived from a provider at runtime. */
export type RouteSpecialtyV1 = Readonly<{
  multiSpeaker?: boolean;
  emotionTags?: boolean;
  hd?: boolean;
  longForm?: boolean;
  languages?: readonly string[];
}>;

export type RouteReferencePolicyV1 = Readonly<{
  minReferences: number;
  maxReferences: number;
  mediaTypes: readonly LabInputMediaType[];
}>;

/**
 * The client-facing model identity: the quality anchor a client surface shows
 * ("Seedance" · "2.0"). `version` is a free display label (it holds "2.0", "5 Pro",
 * "v2") and is optional — some models have no meaningful public version. Neither
 * field is ever the provider's wire slug; that never leaves the adapter, and the
 * load-time drift guards reject any value that looks like one.
 */
export type RouteModelIdentityV1 = Readonly<{
  name: string;
  version?: string;
}>;

/** Human-readable model guidance for the Producer selector. Never contains provider slugs. */
export type ProducerModelGuidanceV1 = Readonly<{
  cost: string;
  speed: string;
  bestFor: string;
}>;

/**
 * A catalog entry: everything the platform declares about one route. This is the
 * full (server-side) descriptor; the wire projection is {@link ProducerCatalogViewV1},
 * which trims `house` to the caller's resolved audience.
 */
export type ProducerRouteDescriptorV1 = Readonly<{
  schemaVersion: '1';
  routeId: string;
  capability: CreativeCapability;
  /** Client-facing quality anchor (public: name + optional version). */
  model: RouteModelIdentityV1;
  /** Client-facing decision support, governed with the route instead of inferred in the browser. */
  modelGuidance?: ProducerModelGuidanceV1;
  /** Efeonce's internal taxonomy for grouping routes (operator-only). */
  house: string;
  constraints: RouteConstraintsV1;
  specialty: RouteSpecialtyV1;
  audioCapable: boolean;
  inputModes: readonly RouteInputMode[];
  /** Exact reference affordance enforced before spend and mirrored by the provider route. */
  referencePolicy?: RouteReferencePolicyV1;
  fidelityContract?: FidelityContract;
}>;

/**
 * The audience a caller's authority resolves to. Fail-closed default: `client`.
 * `operator` additionally sees the internal `house` classification.
 */
export type ProducerRouteAudience = 'operator' | 'client';

/**
 * The wire projection of a catalog entry. `model` is always present (the public
 * quality anchor). `house` is present ONLY for an operator-authorized caller — a
 * client projection OMITS it (the property is absent, never null; with
 * `exactOptionalPropertyTypes` that is the only representable shape), so the
 * internal taxonomy cannot leak by serialization.
 */
export type ProducerCatalogViewV1 = Readonly<{
  schemaVersion: '1';
  routeId: string;
  capability: CreativeCapability;
  model: RouteModelIdentityV1;
  modelGuidance?: ProducerModelGuidanceV1;
  house?: string;
  constraints: RouteConstraintsV1;
  specialty: RouteSpecialtyV1;
  audioCapable: boolean;
  inputModes: readonly RouteInputMode[];
  referencePolicy?: RouteReferencePolicyV1;
  fidelityContract?: FidelityContract;
}>;

export type ProducerCatalogListQueryV1 = Readonly<{
  capability?: CreativeCapability;
  modality?: ProducerRouteModality;
}>;

export type ProducerCatalogGetQueryV1 = Readonly<{
  routeId: string;
}>;

/**
 * List projection. Carries the catalog version so a consumer (e.g. the Producer
 * surface) can invalidate a cached catalog when the data changes.
 */
export type ProducerCatalogListDataV1 = Readonly<{
  schemaVersion: '1';
  catalogVersion: string;
  routes: readonly ProducerCatalogViewV1[];
}>;

export type ProducerCatalogGetDataV1 = Readonly<{
  schemaVersion: '1';
  catalogVersion: string;
  route: ProducerCatalogViewV1;
}>;
