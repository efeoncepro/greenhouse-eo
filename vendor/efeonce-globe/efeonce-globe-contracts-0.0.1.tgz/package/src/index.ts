export const GLOBE_API_VERSION = 'v1' as const;

export type GlobeApiVersion = typeof GLOBE_API_VERSION;

export { GLOBE_CAPABILITIES, parseGlobeCapabilities, type GlobeCapability } from './capabilities.ts';
export * from './creative-review.ts';
export * from './asset-governance.ts';
export * from './governed-runs.ts';
export * from './producer-live-feed.ts';
export * from './production-promotion-operation.ts';
import type { GlobeCapability } from './capabilities.ts';
import type { StructuredBriefV1 } from './structured-briefs.ts';
import type { LabGenerationRecipeKnobV1, LabGenerationRecipeV1 } from './generation-recipes.ts';
import type { AppliedStyleEvidenceV1, ProducerStyleSelectorV1 } from './reference-intelligence.ts';

/**
 * Semantic creative-capability vocabulary. This is the wire-level SSOT that both
 * the Model Lab experiment contract and the provider boundary consume. Provider
 * model identifiers never appear here — the domain routes by fidelity contract,
 * not by vendor model name.
 */
export const CREATIVE_CAPABILITIES = [
  'image-generate',
  'image-edit',
  'image-vectorize',
  'image-upscale',
  'video-generate',
  'video-extend',
  'video-frames',
  'video-motion-control',
  'video-upscale',
  'audio-generate',
  'audio-change-voice',
  'audio-translate',
  'speech-synthesize',
  'model-3d-generate',
] as const;

export type CreativeCapability = (typeof CREATIVE_CAPABILITIES)[number];

/**
 * Trusted principal context produced by Globe authentication middleware.
 * It is never accepted as a caller-provided request body or header.
 *
 * `capabilities` and `workspaceBindings` are the authority surface: capabilities
 * are the namespaced grants, and `workspaceBindings` enumerates the workspace ids
 * this principal may operate. A caller-provided workspace selection is validated
 * against `workspaceBindings`; it never extends them.
 */
export type AuthenticatedPrincipalV1 = Readonly<{
  schemaVersion: '1';
  principalId: string;
  principalType: 'human' | 'service';
  issuer: 'greenhouse' | 'google-cloud';
  subject: string;
  authenticationMethod: 'greenhouse-session' | 'google-id-token';
  capabilities: readonly GlobeCapability[];
  workspaceBindings: readonly string[];
}>;

export type GlobeApiErrorCode =
  | 'authentication_required'
  | 'access_denied'
  | 'policy_blocked'
  | 'invalid_request'
  | 'not_found'
  | 'conflict'
  | 'rate_limited'
  | 'dependency_unavailable'
  | 'internal_error';

export type GlobeApiErrorV1 = Readonly<{
  schemaVersion: '1';
  error: Readonly<{
    code: GlobeApiErrorCode;
    message: string;
    retryable: boolean;
    correlationId: string;
  }>;
}>;

export type GlobeHealthV1 = Readonly<{
  schemaVersion: '1';
  service: 'efeonce-globe';
  apiVersion: GlobeApiVersion;
  status: 'ok' | 'degraded';
  checkedAt: string;
}>;

export type ArtifactManifestV1 = Readonly<{
  schemaVersion: '1';
  artifactId: string;
  workspaceId: string;
  compositionId: string;
  runId: string;
  mediaType: 'image' | 'video' | 'audio' | 'document' | 'vector';
  objectUri: string;
  sha256: string;
  reviewStatus: 'candidate' | 'approved' | 'rejected';
  createdAt: string;
}>;

/**
 * Untrusted command request as it arrives from any transport (HTTP body, SDK
 * call, MCP tool). It intentionally carries NO actor, capability or authoritative
 * workspace field. `workspaceSelection` only declares which workspace the caller
 * wishes to operate; the server validates it against the trusted principal's
 * bindings and derives the authoritative workspace server-side.
 */
export type CommandRequestEnvelopeV1<TPayload = unknown> = Readonly<{
  schemaVersion: '1';
  apiVersion: GlobeApiVersion;
  command: string;
  idempotencyKey: string;
  correlationId: string;
  workspaceSelection?: string;
  payload: TPayload;
}>;

/**
 * Untrusted reader request. Reads are policy-filtered projections; like commands
 * they never carry authority context, only an optional workspace selection.
 */
export type ReaderRequestEnvelopeV1<TQuery = unknown> = Readonly<{
  schemaVersion: '1';
  apiVersion: GlobeApiVersion;
  reader: string;
  correlationId: string;
  workspaceSelection?: string;
  query: TQuery;
}>;

/**
 * Canonical command result. The same shape is returned for every transport so a
 * consumer never has to reconcile per-surface response formats.
 */
export type CommandResultV1<TOutcome = unknown> = Readonly<{
  schemaVersion: '1';
  command: string;
  status: 'accepted' | 'completed';
  correlationId: string;
  idempotencyKey: string;
  workspaceId: string;
  outcome: TOutcome;
}>;

export type ReaderResultV1<TData = unknown> = Readonly<{
  schemaVersion: '1';
  reader: string;
  correlationId: string;
  workspaceId: string;
  data: TData;
}>;

/**
 * The canonical Full API Parity surfaces. Every executable capability must
 * declare a coverage state for each surface; a `Record` over this tuple makes an
 * omitted surface a compile error rather than a silent gap.
 */
export const GLOBE_SURFACES = [
  'ui',
  'http',
  'sdk',
  'mcp',
  'cli',
  'worker',
  'sister-platform',
  'e2e',
] as const;

export type GlobeSurface = (typeof GLOBE_SURFACES)[number];

/**
 * Valid per-surface coverage states. `missing` is deliberately not representable:
 * an executable capability that omits a surface fails to typecheck, and the
 * conformance harness rejects any coverage that is not one of these three.
 */
export type SurfaceCoverageState = 'available' | 'policy-blocked' | 'not-applicable';

export type CapabilityKind = 'command' | 'reader';

export type CapabilityDescriptorV1 = Readonly<{
  capability: string;
  kind: CapabilityKind;
  summary: string;
  coverage: Readonly<Record<GlobeSurface, SurfaceCoverageState>>;
}>;

export type CapabilityCoverageManifestV1 = Readonly<{
  schemaVersion: '1';
  apiVersion: GlobeApiVersion;
  capabilities: readonly CapabilityDescriptorV1[];
}>;

// --- Operating modes and responsibility assignments (TASK-1466) ---------------

export type OperatingModeV1 = 'client-operated' | 'co-operated' | 'efeonce-managed';

export type ResponsibilityScopeV1 =
  | Readonly<{ kind: 'workspace' }>
  | Readonly<{ kind: 'run'; runId: string }>;

/**
 * Accountability reference only. It never grants membership or a capability;
 * authorization continues to come exclusively from the authenticated principal.
 */
export type ResponsibleActorV1 = Readonly<{
  party: 'client' | 'efeonce';
  actorId: string;
}>;

export type ResponsibilityAssignmentsV1 = Readonly<{
  briefAuthority: ResponsibleActorV1;
  operatorOfRecord: ResponsibleActorV1;
  creativeApprover: ResponsibleActorV1;
  budgetApprover: ResponsibleActorV1;
  templateAuthority: ResponsibleActorV1;
  rightsAuthority: ResponsibleActorV1;
  deliveryOwner: ResponsibleActorV1;
  deliveryApprover: ResponsibleActorV1;
}>;

export type DeliveryModelV1 = 'managed-squad' | 'staff-augmentation' | 'studio-access' | 'hybrid';
export type EngagementFormV1 = 'on-going' | 'on-demand' | 'sample-sprint';

/** Immutable commercial classification snapshot. Deliberately excludes price, currency and margin. */
export type ResponsibilityCommercialContextV1 = Readonly<{
  deliveryModel: DeliveryModelV1;
  engagementForm: EngagementFormV1;
  engagementRef: string;
}>;

export type OperatingResponsibilityAssignmentV1 = Readonly<{
  schemaVersion: '1';
  assignmentId: string;
  workspaceId: string;
  scope: ResponsibilityScopeV1;
  version: number;
  operatingMode: OperatingModeV1;
  responsibilities: ResponsibilityAssignmentsV1;
  commercialContext: ResponsibilityCommercialContextV1;
  changeReason: string;
  changedBy: Readonly<{ principalId: string; principalType: 'human' | 'service' }>;
  correlationId: string;
  createdAt: string;
}>;

export const GLOBE_RESPONSIBILITY_MANAGE_CAPABILITY = 'globe.responsibility.manage' as const;
export const GLOBE_RESPONSIBILITY_READ_CAPABILITY = 'globe.responsibility.read' as const;

export const GLOBE_RESPONSIBILITY_COMMANDS = {
  assign: 'globe.responsibility.assignment.assign',
  change: 'globe.responsibility.assignment.change',
} as const;

export const GLOBE_RESPONSIBILITY_READERS = {
  get: 'globe.responsibility.assignment.get',
  effective: 'globe.responsibility.assignment.effective',
  history: 'globe.responsibility.assignment.history',
} as const;

export type AssignResponsibilityPayloadV1 = Readonly<{
  scope: ResponsibilityScopeV1;
  operatingMode: OperatingModeV1;
  responsibilities: ResponsibilityAssignmentsV1;
  commercialContext: ResponsibilityCommercialContextV1;
  changeReason: string;
}>;

export type ChangeResponsibilityPayloadV1 = AssignResponsibilityPayloadV1 &
  Readonly<{ expectedVersion: number }>;

export type ResponsibilityAssignmentQueryV1 = Readonly<{ scope: ResponsibilityScopeV1 }>;

export type EffectiveResponsibilityQueryV1 = Readonly<{ runId?: string }>;

export type ResponsibilityHistoryV1 = Readonly<{
  scope: ResponsibilityScopeV1;
  assignments: readonly OperatingResponsibilityAssignmentV1[];
}>;

// --- Model Lab experiment contract (TASK-1457) ---------------------------------
// A Model Lab experiment tests a real (or, until infra lands, a deterministic fake)
// provider route under a hard spend cap, private inputs and a per-attempt manifest.
// It never enables production, external clients or autonomous spend.

/** The capability grant a principal needs to operate the Model Lab. */
export const GLOBE_LAB_EXPERIMENT_CAPABILITY = 'globe.lab.experiment.run' as const;

/** Canonical Model Lab command names (wire identifiers). */
export const GLOBE_LAB_COMMANDS = {
  prepare: 'globe.lab.experiment.prepare',
  execute: 'globe.lab.experiment.execute',
  cancel: 'globe.lab.experiment.cancel',
  relaunch: 'globe.lab.experiment.relaunch',
  variate: 'globe.lab.experiment.variate',
} as const;

/** Canonical Model Lab reader names (wire identifiers). */
export const GLOBE_LAB_READERS = {
  get: 'globe.lab.experiment.get',
  status: 'globe.lab.experiment.status',
  evidence: 'globe.lab.experiment.evidence',
  // Previewable credit estimate (TASK-1502): read-only `✨N` for a prospective (route × shape)
  // tuple, before any experiment is created or credit reserved.
  estimate: 'globe.lab.experiment.estimate',
  list: 'globe.lab.experiment.list',
  children: 'globe.lab.experiment.children',
  tree: 'globe.lab.experiment.tree',
} as const;

/**
 * Experiment lifecycle. `estimated` carries a route + credit quote; `reserved`
 * means the hard cap has been fenced; `running` means the runner is executing the
 * provider attempt; `candidate_ready` is a technical candidate, never an approval.
 */
export type LabExperimentState =
  | 'prepared'
  | 'estimated'
  | 'reserved'
  | 'running'
  | 'candidate_ready'
  | 'failed'
  | 'cancelled';

export type LabInputMediaType = 'image' | 'video' | 'audio' | 'text';

export type LabInputRights = 'internal-owned' | 'licensed' | 'test-fixture';

/**
 * An authorized experiment input. Only a content hash + rights posture crosses the
 * contract; raw bytes are ingested privately server-side, never through the API.
 */
export type LabAuthorizedInputV1 = Readonly<{
  inputId: string;
  sha256: string;
  mediaType: LabInputMediaType;
  rights: LabInputRights;
}>;

/**
 * `derived-internal` is the posture of a Lab-produced candidate re-used as the base of an
 * edit. It is deliberately NOT a `LabInputRights`: a caller can never declare it, because
 * only the platform can certify that bytes came out of a governed run of its own. It exists
 * so a derivative is not laundered as `internal-owned` — the parent's own rights constraints
 * are carried alongside it in `LabEditSourceV1.parentRights`.
 */
export type LabDerivedRights = 'derived-internal';

/**
 * A reference certified by Globe from a retained Producer output. Unlike a caller-declared
 * input, its `derived-internal` posture can only be minted by the platform. `parentRights`
 * preserves the most restrictive posture of the source run across every subsequent reuse.
 */
export type LabDerivedReferenceInputV1 = Readonly<{
  schemaVersion: '1';
  referenceId: string;
  sourceExperimentId: string;
  sourceAttemptId: string;
  sha256: string;
  mediaType: LabInputMediaType;
  rights: LabDerivedRights;
  parentRights: LabInputRights;
  createdAt: string;
}>;

export type LabDeclaredInputV1 = LabAuthorizedInputV1 | LabDerivedReferenceInputV1;

export type LabResolvableRights = LabInputRights | LabDerivedRights;

/**
 * Anything the input resolver can be asked to turn back into bytes: a caller-declared
 * authorized input, or a platform-derived edit base. A `LabAuthorizedInputV1` is a
 * `LabResolvableInputV1`; the reverse does not hold, which is exactly the point.
 */
export type LabResolvableInputV1 = Readonly<{
  inputId: string;
  sha256: string;
  mediaType: LabInputMediaType;
  rights: LabResolvableRights;
}>;

/**
 * The canonical, transport-neutral edit intent: "refine the candidate that experiment X
 * produced". It names NO provider mechanism — whether that becomes a stateful provider-side
 * chain or a re-injected output reference is decided server-side from what the parent
 * candidate actually affords and what the executing model natively supports.
 *
 * The caller still states `capability`, `referenceRoute` and `hardCapCredits` for the edit
 * itself: that is precisely what makes CROSS-MODEL refinement possible (refine a Veo
 * candidate with Seedream), which inheriting them from the parent would forbid.
 */
export type LabNormalizedRectV1 = Readonly<{ x: number; y: number; width: number; height: number }>;
export type LabEditIntent = 'replace' | 'add' | 'remove';
/** Browser-safe reference. Hash, dimensions and rights deliberately cannot be declared here. */
export type LabEditMaskV1 = Readonly<{ maskId: string }>;
/** Server-only materialization persisted in a prepared experiment. */
export type LabResolvedEditMaskV1 = Readonly<{
  maskId: string;
  inputId: string;
  sha256: string;
  mediaType: 'image';
  rights: 'internal-owned';
  width: number;
  height: number;
  targetExperimentId: string;
  targetAttemptId: string;
  targetOutputSha256: string;
}>;
export type LabEditRegionV1 = Readonly<{
  intent: LabEditIntent;
  mask?: LabEditMaskV1 | LabResolvedEditMaskV1;
  bbox?: LabNormalizedRectV1;
  invert?: boolean;
}>;
export type LabEditFromV1 = Readonly<{ experimentId: string; region?: LabEditRegionV1 }>;

/** How an edit was actually carried out. Evidence, so no paradigm switch is silent. */
export type LabEditMode = 'stateful' | 'reference';
export type LabEditScope = 'full' | 'regional';

/**
 * The server-derived description of the parent candidate an edit refines. NEVER accepted
 * from a caller: every field is read out of the parent's own stored experiment and attempt
 * manifest, inside the caller's workspace.
 */
export type LabEditSourceV1 = Readonly<{
  parentExperimentId: string;
  parentAttemptId: string;
  parentProvider: string;
  parentLineage: readonly string[];
  /** The parent's retained output, resolvable to bytes — the base of a reference-based edit. */
  parentOutput?: LabResolvableInputV1;
  /** The parent's rights posture, inherited as the most restrictive over its own inputs. */
  parentRights: LabInputRights;
  /** A provider-side chain handle, present only when the parent's ref is actually chainable. */
  parentProviderRunRef?: string;
}>;

// --- Modality-discriminated output shape (TASK-1501) ---------------------------
// The run's output shape, a discriminated union by `modality`. It carries ONLY
// output-shape params + non-byte selectors — never bytes, never the provider slug.
// Every param is validated in `prepare` against the constraints of the selected
// `referenceRoute` in the governed catalog (TASK-1500), FAIL-CLOSED before the spend
// fence reserves. The contract is designed for all three modalities from day one;
// implementation is incremental image -> video -> audio. `prompt` stays top-level on
// the payload (the creative instruction / voiceover script / edit instruction); the
// shape only adds the FORM of the output plus which input mode is in play.

export type ImageOutputShapeV1 = Readonly<{
  modality: 'image';
  quality: string; // ∈ route.constraints.quality
  aspectRatio: string; // ∈ route.constraints.aspectRatio (absorbs TASK-1495 for image)
  count: number; // ∈ [route.constraints.count.min, route.constraints.count.max]
}>;

/**
 * The video input mode. A SELECTOR ONLY — it carries no bytes. `create` is prompt-driven;
 * `elements`/`frames`/`motion` reference inputs already declared in `authorizedInputs`; `edit` refines a
 * prior candidate via `editFrom` — NEVER through `authorizedInputs`. The capability-specific
 * execution of each mode (keyframes, motion transfer) is wired by TASK-1504; this contract
 * only declares and validates the selector.
 */
export type VideoInputModeV1 =
  | Readonly<{ kind: 'create' }>
  | Readonly<{ kind: 'elements' }>
  | Readonly<{ kind: 'frames'; hasEndFrame: boolean }>
  | Readonly<{ kind: 'motion' }>
  | Readonly<{ kind: 'edit' }>;

export type VideoOutputShapeV1 = Readonly<{
  modality: 'video';
  inputMode: VideoInputModeV1;
  resolution: string; // ∈ route.constraints.resolution
  durationSeconds: number; // ∈ [route.constraints.duration.minSeconds, .maxSeconds]
  aspectRatio: string; // ∈ route.constraints.aspectRatio
  audioMode: 'silent' | 'with-audio'; // ∈ route.constraints.audioMode
}>;

/**
 * The audio mode. A SELECTOR ONLY. Foley instructions and `voiceover`'s script use `prompt`;
 * `change-voice`/`translate` reference a source clip by hash via `authorizedInputs`.
 * `voicePreset` is a declared id resolved against the registry (TASK-1504).
 */
export type AudioModeV1 =
  | Readonly<{ kind: 'foley' }>
  | Readonly<{ kind: 'voiceover' }>
  | Readonly<{ kind: 'change-voice' }>
  | Readonly<{ kind: 'translate'; targetLang: string }>;

export type AudioOutputShapeV1 = Readonly<{
  modality: 'audio';
  mode: AudioModeV1;
  voicePreset?: string;
  sampleRate: number; // ∈ route.constraints.sampleRate
  format: string; // ∈ route.constraints.format
  speed: number; // ∈ [route.constraints.speed.min, .max]
  volume: number; // ∈ [route.constraints.volume.min, .max]
  pitch: number; // ∈ [route.constraints.pitch.min, .max]
}>;

export type OutputShapeV1 = ImageOutputShapeV1 | VideoOutputShapeV1 | AudioOutputShapeV1;

export type PrepareExperimentPayloadV1 = Readonly<{
  capability: CreativeCapability;
  referenceRoute: string;
  authorizedInputs: readonly LabDeclaredInputV1[];
  hardCapCredits: number;
  prompt?: string;
  /** Structured alternative to `prompt`; the server compiles it deterministically. */
  structuredBrief?: StructuredBriefV1;
  // The output shape (TASK-1501), discriminated by modality. Additive-optional: a caller
  // without `output` keeps the prior behavior (adapter defaults). When present it is validated
  // fail-closed in `prepare` against the route's catalog constraints, before any spend.
  output?: OutputShapeV1;
  // Refine a prior candidate. The prompt becomes the edit instruction. This is the ONLY
  // edit vocabulary a caller uses, for every editable model: the paradigm (stateful chain vs
  // re-injected output reference) is resolved server-side, never named here.
  editFrom?: LabEditFromV1;
  /**
   * @deprecated Provider vocabulary that predates `editFrom`; a raw Gemini Omni interaction
   * id, which only ever worked for one model on one surface. Still accepted so an in-flight
   * caller does not break, but it is mutually exclusive with `editFrom` — sending both is
   * rejected rather than silently resolved by precedence. Prefer `editFrom`.
   */
  previousInteractionId?: string;
  /** Provider-neutral reproducibility controls, validated server-side before spend. */
  recipe?: LabGenerationRecipeV1;
  /** Pinned workspace style selector. Materialization and conditioning are server-only. */
  style?: ProducerStyleSelectorV1;
}>;

export type ExecuteExperimentPayloadV1 = Readonly<{
  experimentId: string;
  /** Opaque, short-lived server approval binding the previewed commercial quote. */
  approvalToken?: string;
}>;

/**
 * A PROSPECTIVE, non-persisted estimate input (TASK-1502). The credit estimate is a pure
 * function of `(route × output-shape)`, so it needs only the fidelity route, the output shape
 * and the reference hashes (never bytes) — not a stored experiment. It is the single input of
 * `LabRunnerPort.estimate`, shared by both the previewable estimate reader (before any spend)
 * and the `execute` command (which derives it from its stored experiment). `outputShape` is
 * optional (a shapeless quote keeps the prior capability-keyed pricing); `hardCapCredits` is a
 * budget signal only — the estimate is non-billable and does not consume it.
 */
export type LabQuoteInputV1 = Readonly<{
  capability: CreativeCapability;
  route: string;
  outputShape?: OutputShapeV1;
  inputHashes: readonly string[];
  hardCapCredits?: number;
  regionalEdit?: Readonly<{ intent: LabEditIntent; hasMask: boolean; hasBbox: boolean; invert: boolean }>;
  /** Server-derived style evidence; never accepted directly by the estimate reader. */
  style?: AppliedStyleEvidenceV1;
}>;

/**
 * The curated preview projection of a credit estimate (TASK-1502). Client-safe: it exposes the
 * credit number (`✨N`), the fidelity route and the output-shape duration, plus read-only budget
 * signals — and deliberately OMITS `provider`, the model slug, vendor cost and margin. The
 * real-model view is resolved by the catalog (TASK-1500), never leaked through the estimate.
 */
export type LabEstimatePreviewV1 = Readonly<{
  schemaVersion: '1';
  capability: CreativeCapability;
  referenceRoute: string;
  estimatedCredits: number;
  estimatedDurationSeconds?: number;
  // Budget signal, not a rejection: true/false when a hard cap was declared, undefined when not.
  // An over-cap preview still RETURNS the estimate (a preview tells the truth; it never spends).
  withinHardCap?: boolean;
  // Reserved for the durable spend fence (TASK-1468). The in-memory per-process fence cannot give
  // a reliable cross-replica day-cap signal, so this stays absent until the durable ledger lands.
  withinDayCap?: boolean;
  estimateExpiresAt?: string;
  /** Opaque approval proof; contains no provider secret, price, margin or authority grant. */
  approvalToken?: string;
  /** Exact immutable style version used to validate this quote. */
  style?: AppliedStyleEvidenceV1;
}>;

/**
 * The prospective estimate query a caller sends to the previewable estimate reader (TASK-1502).
 * `outputShape` is optional and, when present, validated fail-closed against the route's catalog
 * constraints before the estimate is returned. References travel as hashes (form/count), never
 * bytes. `hardCapCredits` drives the `withinHardCap` budget signal only.
 */
export type EstimateExperimentQueryV1 = Readonly<{
  capability: CreativeCapability;
  referenceRoute: string;
  outputShape?: OutputShapeV1;
  referenceHashes?: readonly LabDeclaredInputV1[];
  hardCapCredits?: number;
  /** Pinned workspace style selector; arbitrary conditioning is intentionally absent. */
  style?: ProducerStyleSelectorV1;
}>;

export type CancelExperimentPayloadV1 = Readonly<{
  experimentId: string;
  reason: string;
}>;

export type GetExperimentQueryV1 = Readonly<{
  experimentId: string;
}>;

/** Allowlisted, deterministic orderings for the unified Producer candidate feed. */
export type LabExperimentSortV1 =
  | 'created-desc'
  | 'created-asc'
  | 'updated-desc'
  | 'updated-asc';

/**
 * Tenant scope is deliberately absent: it comes from trusted context. `search` is a bounded
 * prefix search over opaque experiment ids and public route labels, never arbitrary SQL.
 */
export type ListExperimentsQueryV1 = Readonly<{
  cursor?: string;
  limit?: number;
  state?: LabExperimentState;
  capability?: CreativeCapability;
  modality?: 'image' | 'video' | 'audio' | 'model-3d' | 'text';
  favorite?: boolean;
  collectionId?: string;
  search?: string;
  sort?: LabExperimentSortV1;
}>;

export type ExperimentChildrenQueryV1 = Readonly<{
  experimentId: string;
}>;

export type ExperimentTreeQueryV1 = Readonly<{
  experimentId: string;
  maxDepth?: number;
}>;

export type LabPublicRouteLabelV1 = Readonly<{
  routeId: string;
  model?: Readonly<{ name: string; version?: string }>;
}>;

export type LabRecipeRefV1 = Readonly<{
  recipeId: string;
  version?: string;
}>;

export type LabCandidateOutputRefV1 = Readonly<{
  sha256: string;
  mediaType: LabOutputMediaType;
  retained: boolean;
}>;

/**
 * Client-safe feed item. Optional collection/approval/recipe fields are projection seams owned
 * by their authoritative domains; absence means "not projected", never a fabricated default.
 */
export type LabExperimentSummaryV1 = Readonly<{
  schemaVersion: '1';
  experimentId: string;
  /** Client-safe, bounded creative title projected from authorized intent; never raw provider data. */
  displayTitle?: string;
  state: LabExperimentState;
  capability: CreativeCapability;
  modality: 'image' | 'video' | 'audio' | 'model-3d' | 'text';
  route: LabPublicRouteLabelV1;
  spentCredits: number;
  createdAt: string;
  updatedAt: string;
  favorite: boolean;
  collectionIds?: readonly string[];
  approvalState?: 'pending' | 'in-review' | 'approved' | 'changes-requested';
  recipe?: LabRecipeRefV1;
  parentExperimentId?: string;
  childExperimentIds: readonly string[];
  outputs: readonly LabCandidateOutputRefV1[];
}>;

export type LabExperimentPageV1 = Readonly<{
  schemaVersion: '1';
  items: readonly LabExperimentSummaryV1[];
  nextCursor?: string;
}>;

export type LabExperimentChildRefV1 = Readonly<{
  experimentId: string;
  state: LabExperimentState;
  editMode?: LabEditMode;
}>;

export type LabExplorationNodeV1 = Readonly<{
  experimentId: string;
  state: LabExperimentState;
  capability: CreativeCapability;
  modality: 'image' | 'video' | 'audio' | 'model-3d' | 'text';
  createdAt: string;
}>;

export type LabExplorationEdgeV1 = Readonly<{
  parent: string;
  child: string;
  editMode?: LabEditMode;
}>;

export type LabExplorationGraphV1 = Readonly<{
  schemaVersion: '1';
  root: string;
  nodes: readonly LabExplorationNodeV1[];
  edges: readonly LabExplorationEdgeV1[];
  truncated: boolean;
  /** Count only: reports broken/archived ancestry without disclosing a foreign identifier. */
  unresolvedAncestors: number;
}>;

/**
 * What a provider run can emit. A superset of `ProducerOutputMediaType` (which describes what
 * the output side SERVES) because the hermetic reference adapter emits `text`, and a manifest
 * has to be able to declare honestly what actually came back — including in the zero-spend path.
 */
export type LabOutputMediaType = 'image' | 'video' | 'audio' | 'text' | 'model-3d';

/**
 * One output of an attempt, declared individually.
 *
 * Retention is PER OUTPUT because it genuinely fails per output: the store can accept the video
 * of a `{video, audio}` run and reject the audio. Collapsing that into one flag forces a choice
 * between claiming bytes that are missing and disowning bytes that are there — and the run was
 * paid for either way.
 *
 * (`retained`, not `outputsRetained`: the plural belongs to the whole-attempt flag above. A
 * per-output field named for the set it is not would misread at every call site.)
 */
export type LabOutputDescriptorV1 = Readonly<{
  sha256: string;
  mediaType: LabOutputMediaType;
  mimeType: string;
  /** Authoritative retained byte length, populated by the content-addressed ingest boundary. */
  byteSize?: number;
  retained: boolean;
}>;

/**
 * Immutable per-attempt manifest. Records proposed vs actual route, cost, input and
 * output hashes and lineage. A fallback that runs a different route shows both the
 * proposed and actual route without rewriting history. Never carries secrets, raw
 * bytes, vendor-confidential cost or a public asset URL.
 */
export type ExperimentAttemptManifestV1 = Readonly<{
  schemaVersion: '1';
  attemptId: string;
  experimentId: string;
  workspaceId: string;
  capability: CreativeCapability;
  provider: string;
  proposedRoute: string;
  actualRoute: string;
  model: string;
  modelVersion: string;
  estimatedCredits: number;
  actualCredits: number;
  // What the CALLER declared and was authorized to use. A platform-derived edit base is
  // deliberately NOT folded in here: this field stays pure rights evidence, and its
  // meaning does not drift between a generate and an edit.
  authorizedInputHashes: readonly string[];
  outputHashes: readonly string[];
  // The experiment chain that produced this attempt, oldest first, ending in this
  // experiment. A refined candidate chains onto its parent's lineage, so provenance is
  // readable end to end from any attempt.
  lineage: readonly string[];
  /** Provider-reported effective recipe; absent when no requested knob was honored. */
  recipe?: LabGenerationRecipeV1;
  /** Requested recipe knobs the selected provider could not honor. */
  recipeUnsupportedKnobs?: readonly LabGenerationRecipeKnobV1[];
  /** Exact server-materialized style evidence applied to the effective creative recipe. */
  style?: AppliedStyleEvidenceV1;
  // How an edit actually executed. Absent on a plain generate. Recorded because an edit can
  // legitimately fall back from a stateful chain to a reference-based one (e.g. it routed to
  // a different model than the parent), and that must be evidence, never a silent switch.
  editMode?: LabEditMode;
  /** Full-canvas vs masked edit evidence. Absent on plain generation and legacy manifests. */
  editScope?: LabEditScope;
  /** Hash-only region evidence; raw mask bytes/object coordinates never enter a manifest. */
  editRegion?: Readonly<{
    intent: LabEditIntent;
    maskSha256?: string;
    bbox?: LabNormalizedRectV1;
    invert?: boolean;
  }>;
  startedAt: string;
  completedAt: string;
  outcome: 'candidate_ready' | 'failed';
  // A provider-side run reference (e.g. a Gemini Omni interaction id) that a later stateful
  // edit chains from. Never a secret or a public URL.
  providerRunRef?: string;
  // The provider surface that minted `providerRunRef` — evidence of WHERE the ref lives.
  providerRunSurface?: string;
  // Whether the adapter certifies that ref as chainable by a later stateful edit. The
  // adapter owns this judgement because only it knows its surfaces: a keyless Vertex
  // interaction id, for instance, exists but is NOT editable anywhere. Without it the
  // domain would have to guess, and would discover the mismatch as a provider-side 400
  // only after the spend fence had already reserved.
  providerRunChainable?: boolean;
  // True when this attempt's output bytes were retained in the content-addressed store, so
  // `outputHashes` resolve back to bytes and this candidate can be refined BY REFERENCE.
  // False/absent means only a stateful chain (if `providerRunRef` exists) can refine it.
  //
  // FLAT and whole-attempt. Kept for compatibility, and true only when EVERY output was
  // retained — a partial success reported as `true` here would promise bytes that are not there.
  outputsRetained?: boolean;
  /**
   * Every output this attempt produced, one descriptor each (TASK-1504).
   *
   * `outputHashes` + a single `outputsRetained` cannot describe a run that emits more than one
   * medium: a `{video, audio}` run collapses to a flat hash list with no way to say which hash
   * is which, and one boolean cannot record that the video was retained and the audio was not.
   * The consequence was not cosmetic — an edit over such a candidate picked `outputHashes[0]`,
   * so refining "the video" could hand a model the audio track instead.
   *
   * Additive and optional: manifests written before this field is populated stay readable
   * through `outputHashes`, and nothing rewrites history.
   */
  outputs?: readonly LabOutputDescriptorV1[];
}>;

/**
 * Reader projection of an experiment. Exposes proposed/actual route, readiness and
 * spend against the hard cap; excludes provider credentials, privileged endpoints,
 * confidential vendor cost and Efeonce margin.
 */
export type LabExperimentV1 = Readonly<{
  schemaVersion: '1';
  experimentId: string;
  workspaceId: string;
  /** Client-safe, bounded creative title projected from authorized intent; never raw provider data. */
  displayTitle?: string;
  capability: CreativeCapability;
  state: LabExperimentState;
  provider: string;
  proposedRoute: string;
  model: string;
  modelVersion: string;
  hardCapCredits: number;
  estimatedCredits: number;
  reservedCredits: number;
  spentCredits: number;
  attempts: readonly ExperimentAttemptManifestV1[];
  /** Explicit terminal-source lineage for a safe retry materialized as a new experiment. */
  retryOfExperimentId?: string;
  failureReason?: string;
  createdAt: string;
  updatedAt: string;
}>;

// --- Golden Briefs & Evaluation Harness (TASK-1458) ----------------------------
// Versioned fixtures + rubrics + reports that turn a Model Lab attempt into
// repeatable, comparable evidence PER FIDELITY CONTRACT. It never declares a model
// globally "better", and it separates objective (automatic) metrics from human
// creative judgment — a report is never auto-marked as a creative pass.

/** Capability grant to operate the evaluation harness. */
export const GLOBE_EVAL_CAPABILITY = 'globe.lab.evaluation.run' as const;

export const GLOBE_EVAL_COMMANDS = {
  evaluate: 'globe.lab.evaluation.evaluate',
} as const;

export const GLOBE_EVAL_READERS = {
  report: 'globe.lab.evaluation.report',
  fixtures: 'globe.lab.evaluation.fixtures',
} as const;

/**
 * The fidelity contract a fixture tests. Evaluation is always per-contract (set
 * continuity, human action, exact text, flexible style, foley, speech, voice transform,
 * voice translation); a model is judged against the contract it claims to serve, never globally.
 *
 * `voice-transform` and `voice-translation` are the fidelity contracts of the two audio
 * *transformation* routes (voice change, dubbing): unlike a generative contract, they own a
 * source recording and are judged on what must be PRESERVED across the transform (meaning,
 * timing, speaker identity) versus what may change (timbre, language). Additive members —
 * every consumer validates membership, none exhaustively switches on the union.
 */
export const FIDELITY_CONTRACTS = [
  'preserve-set',
  'human-action',
  'exact-text',
  'flexible-style',
  'audio-foley',
  'audio-speech',
  'voice-transform',
  'voice-translation',
] as const;

export type FidelityContract = (typeof FIDELITY_CONTRACTS)[number];

/** Rights posture of a fixture's inputs — license, consent and permitted use. */
export type FixtureRightsV1 = Readonly<{
  license: string;
  consent: string;
  permittedUse: string;
}>;

/** A golden brief: a versioned, rights-declared creative test case. */
export type GoldenBriefFixtureV1 = Readonly<{
  schemaVersion: '1';
  fixtureId: string;
  version: string;
  title: string;
  capability: CreativeCapability;
  fidelityContract: FidelityContract;
  referenceRoute: string;
  authorizedInputs: readonly LabAuthorizedInputV1[];
  hardCapCredits: number;
  prompt?: string;
  /** Optional validated output shape for input-bearing/provider-specific evaluations. */
  output?: OutputShapeV1;
  rights: FixtureRightsV1;
}>;

/** An objective (automatic, reproducible) check the rubric runs on an attempt manifest. */
export type ObjectiveCheckId =
  | 'output_present'
  | 'within_hard_cap'
  | 'input_lineage_intact'
  | 'route_stable'
  | 'outcome_candidate';

/** A human judgment dimension. Declared for the reviewer; NEVER auto-scored. */
export type HumanCriterionV1 = Readonly<{
  criterionId: string;
  question: string;
}>;

export type EvaluationRubricV1 = Readonly<{
  schemaVersion: '1';
  rubricId: string;
  version: string;
  fidelityContract: FidelityContract;
  objectiveChecks: readonly ObjectiveCheckId[];
  humanCriteria: readonly HumanCriterionV1[];
}>;

export type EvaluateAttemptPayloadV1 = Readonly<{
  fixtureId: string;
  rubricId: string;
}>;

/** Durable receipt returned when a real-provider evaluation is accepted by the worker lane. */
export type EvaluationRunHandleV1 = Readonly<{
  schemaVersion: '1';
  experimentId: string;
  reportId: string;
  fixtureId: string;
  rubricId: string;
  routeId: string;
  state: 'accepted' | 'running' | 'completed' | 'failed' | 'cancelled';
  createdAt: string;
  updatedAt: string;
  failureReason?: string;
}>;

export type ObjectiveCheckResultV1 = Readonly<{
  checkId: ObjectiveCheckId;
  pass: boolean;
  detail: string;
}>;

/**
 * The verdict is deliberately never a creative "passed": objective checks can only
 * fail the attempt or clear it for mandatory human review. Craft is a human call.
 */
export type EvaluationVerdict = 'objective_fail' | 'objective_pass_pending_human';

export type EvaluationReportV1 = Readonly<{
  schemaVersion: '1';
  reportId: string;
  workspaceId: string;
  fixtureId: string;
  fixtureVersion: string;
  rubricId: string;
  rubricVersion: string;
  capability: CreativeCapability;
  fidelityContract: FidelityContract;
  attempt: ExperimentAttemptManifestV1;
  objectiveResults: readonly ObjectiveCheckResultV1[];
  humanCriteria: readonly HumanCriterionV1[];
  verdict: EvaluationVerdict;
  limitations: readonly string[];
  createdAt: string;
}>;

// Creative Producer route catalog (TASK-1500). Re-exported last so the module can
// import the vocabulary types above without a load-time cycle (type-only imports).
export * from './producer-catalog.ts';
export * from './producer-fleet.ts';
// Creative Producer output side (TASK-1503): governed retrieval + asset actions. Same
// type-only import discipline as the catalog above.
export * from './producer-assets.ts';
// Voice preset registry (TASK-1504): reusable and cloned voices. Same discipline.
export * from './voice-presets.ts';
// Human BFF -> private API request-bound delegation (TASK-1519).
export * from './ui-delegation.ts';
// Studio Credits shadow ledger (TASK-1468): versioned rates and safe economic DTOs.
export * from './credits.ts';
export * from './structured-briefs.ts';
export * from './reference-intelligence.ts';
export * from './asset-library.ts';
export * from './credit-administration.ts';
export * from './generation-recipes.ts';
export * from './tenancy.ts';
export * from './model-readiness.ts';
export * from './model-commercial-rights.ts';
export * from './production-routing-control.ts';
export * from './media-derivatives.ts';
