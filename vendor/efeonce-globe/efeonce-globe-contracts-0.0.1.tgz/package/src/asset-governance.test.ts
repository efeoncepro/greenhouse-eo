import assert from 'node:assert/strict';
import { describe, it } from 'node:test';

import { ASSET_GOVERNANCE_STATES } from './asset-governance.ts';

describe('asset governance contract', () => {
  it('exposes only the approved honest lifecycle', () => {
    assert.deepEqual(ASSET_GOVERNANCE_STATES, [
      'pending', 'inspecting', 'malware_scan', 'c2pa_verify',
      'rights_reconcile', 'eligible', 'rejected', 'failed',
    ]);
  });
});
