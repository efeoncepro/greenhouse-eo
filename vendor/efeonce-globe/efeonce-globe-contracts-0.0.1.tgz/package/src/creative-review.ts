import type { GlobeCapability, ProducerOutputMediaType } from './index.js';

export const GLOBE_REVIEW_READ_CAPABILITY = 'globe.producer.review.read' as GlobeCapability;
export const GLOBE_REVIEW_DECIDE_CAPABILITY = 'globe.producer.review.decide' as GlobeCapability;
export const GLOBE_COMMENT_MANAGE_CAPABILITY = 'globe.producer.comment.manage' as GlobeCapability;
export const GLOBE_SHARE_MANAGE_CAPABILITY = 'globe.producer.share.manage' as GlobeCapability;

export const GLOBE_REVIEW_COMMANDS = {
  decide: 'globe.producer.review.decide',
  commentCreate: 'globe.producer.review.comment.create',
  commentEdit: 'globe.producer.review.comment.edit',
  commentDelete: 'globe.producer.review.comment.delete',
  shareCreate: 'globe.producer.review.share.create',
  shareRevoke: 'globe.producer.review.share.revoke',
} as const;

export const GLOBE_REVIEW_READERS = {
  thread: 'globe.producer.review.thread.get',
  share: 'globe.producer.review.share.get',
} as const;

/** Immutable output identity. A decision never applies to later derivatives. */
export type ReviewTargetV1 = Readonly<{ experimentId: string; sha256: string }>;
export type ReviewDecisionKindV1 = 'approved' | 'changes_requested';
export type CreativeReviewDecisionV1 = Readonly<{
  schemaVersion: '1'; reviewId: string; target: ReviewTargetV1; revision: number;
  decision: ReviewDecisionKindV1; reason: string; decidedBy: string; decidedAt: string;
}>;
export type DecideCreativeReviewPayloadV1 = Readonly<{
  target: ReviewTargetV1; expectedRevision: number; decision: ReviewDecisionKindV1; reason: string;
}>;

export type CreativeReviewCommentV1 = Readonly<{
  schemaVersion: '1'; commentId: string; target: ReviewTargetV1; body: string;
  authorId: string; version: number; createdAt: string; updatedAt: string; deletedAt?: string;
}>;
export type CreateCreativeReviewCommentPayloadV1 = Readonly<{ target: ReviewTargetV1; body: string }>;
export type EditCreativeReviewCommentPayloadV1 = Readonly<{ commentId: string; expectedVersion: number; body: string }>;
export type DeleteCreativeReviewCommentPayloadV1 = Readonly<{ commentId: string; expectedVersion: number }>;

export type CreativeReviewThreadV1 = Readonly<{
  schemaVersion: '1'; target: ReviewTargetV1; decision?: CreativeReviewDecisionV1;
  comments: readonly CreativeReviewCommentV1[];
}>;

export type ShareProjectionFieldV1 = 'media-preview' | 'model-label' | 'review-status' | 'comments';
export type CreativeShareGrantV1 = Readonly<{
  schemaVersion: '1'; shareId: string; target: ReviewTargetV1; fields: readonly ShareProjectionFieldV1[];
  createdBy: string; createdAt: string; expiresAt: string; revokedAt?: string;
}>;
export type CreateCreativeSharePayloadV1 = Readonly<{
  target: ReviewTargetV1; fields: readonly ShareProjectionFieldV1[]; expiresAt: string;
}>;
export type RevokeCreativeSharePayloadV1 = Readonly<{ shareId: string }>;
export type CreatedCreativeShareV1 = Readonly<{ schemaVersion: '1'; grant: CreativeShareGrantV1; shareToken: string }>;

/** Fixed public-safe source projection. It never carries storage coordinates, workspace id or download authority. */
export type CreativeShareSourceV1 = Readonly<{
  target: ReviewTargetV1; mediaType: ProducerOutputMediaType;
  modelLabel?: string; reviewStatus?: ReviewDecisionKindV1; comments?: readonly Readonly<{ body: string; createdAt: string }>[];
}>;
export type CreativeShareBoardV1 = Readonly<{
  schemaVersion: '1'; shareId: string; expiresAt: string; asset: Readonly<{
    mediaType: ProducerOutputMediaType; previewPath: string; modelLabel?: string;
    reviewStatus?: ReviewDecisionKindV1; comments?: readonly Readonly<{ body: string; createdAt: string }>[];
  }>;
}>;
