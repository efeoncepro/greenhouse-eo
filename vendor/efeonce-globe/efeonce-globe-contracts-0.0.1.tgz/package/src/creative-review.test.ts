import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { GLOBE_REVIEW_COMMANDS, GLOBE_REVIEW_READERS } from './creative-review.ts';
import { parseGlobeCapabilities } from './capabilities.ts';

describe('creative review contracts', () => {
  it('publishes stable commands/readers and narrows the new grants', () => {
    assert.equal(GLOBE_REVIEW_COMMANDS.decide, 'globe.producer.review.decide');
    assert.equal(GLOBE_REVIEW_READERS.thread, 'globe.producer.review.thread.get');
    assert.deepEqual(parseGlobeCapabilities(['globe.producer.review.read', 'unknown']), ['globe.producer.review.read']);
  });
});
