import type { GlobeCapability } from './capabilities.js';

export const GLOBE_PRODUCTION_ROUTING_CAPABILITIES = {
  read: 'globe.production-routing.read' as GlobeCapability,
  manage: 'globe.production-routing.manage' as GlobeCapability,
} as const;

export const GLOBE_PRODUCTION_ROUTING_COMMANDS = {
  appendRoute: 'globe.production-routing.route.append',
  transitionCircuit: 'globe.production-routing.circuit.transition',
} as const;

export const GLOBE_PRODUCTION_ROUTING_READERS = {
  route: 'globe.production-routing.route.get',
  routeHistory: 'globe.production-routing.route.history',
  circuit: 'globe.production-routing.circuit.get',
  circuitHistory: 'globe.production-routing.circuit.history',
} as const;

export type ProductionCompletionDriverV1 = 'webhook-and-poll' | 'poll';
export type ProviderCircuitStateV1 = 'closed' | 'open' | 'half-open';

/** Exact executable identity. Aliases and provider URLs are deliberately absent. */
export type ProductionRouteIdentityV1 = Readonly<{
  routeId: string;
  providerId: string;
  modelId: string;
  modelVersion: string;
}>;

export type ProductionRouteBindingV1 = ProductionRouteIdentityV1 & Readonly<{
  endpointId: string;
  region: string;
  completionDriver: ProductionCompletionDriverV1;
  enabled: boolean;
}>;

export type ProductionRouteBindingRevisionV1 = ProductionRouteBindingV1 & Readonly<{
  schemaVersion: '1';
  workspaceId: string;
  revision: number;
  changedBy: string;
  correlationId: string;
  createdAt: string;
}>;

export type ProviderCircuitIdentityV1 = Readonly<{
  providerId: string;
  endpointId: string;
  region: string;
}>;

export type ProviderCircuitStateRevisionV1 = ProviderCircuitIdentityV1 & Readonly<{
  schemaVersion: '1';
  workspaceId: string;
  revision: number;
  state: ProviderCircuitStateV1;
  reasonCode: string;
  changedBy: string;
  correlationId: string;
  createdAt: string;
}>;

export type AppendProductionRoutePayloadV1 = Readonly<{
  expectedRevision: number;
  binding: ProductionRouteBindingV1;
}>;

export type TransitionProviderCircuitPayloadV1 = ProviderCircuitIdentityV1 & Readonly<{
  expectedRevision: number;
  state: ProviderCircuitStateV1;
  reasonCode: string;
}>;

export type ProductionRouteQueryV1 = ProductionRouteIdentityV1;
export type ProviderCircuitQueryV1 = ProviderCircuitIdentityV1;
export type ProductionRouteHistoryV1 = Readonly<{
  schemaVersion: '1';
  revisions: readonly ProductionRouteBindingRevisionV1[];
}>;
export type ProviderCircuitHistoryV1 = Readonly<{
  schemaVersion: '1';
  revisions: readonly ProviderCircuitStateRevisionV1[];
}>;
