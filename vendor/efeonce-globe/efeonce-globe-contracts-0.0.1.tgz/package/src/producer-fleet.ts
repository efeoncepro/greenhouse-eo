import type { CreativeCapability } from './index.ts';
import type { ProducerCatalogViewV1, ProducerRouteModality } from './producer-catalog.ts';

// --- Producer Model Fleet availability projection contract (TASK-1554) ----------
// A governed, availability-aware projection of the producer route catalog. Where
// `globe.producer.catalog.list` is PURE reference data ("what routes exist and
// their constraints"), this fleet reader answers "which of those routes can this
// workspace actually use RIGHT NOW", by deriving `availability` from model
// readiness (`state === 'promoted'`) + the production route binding
// (`enabled === true`) for the trusted `workspaceId`. It is the single primitive
// (Full API Parity) that the Producer model selector, Nexa and MCP consume so the
// whole fleet renders data-driven — promoting a route makes it appear everywhere
// without any per-model hand-edit.
//
// The provider wire slug NEVER appears here: the projection extends the PUBLIC
// `ProducerCatalogViewV1` (model name + version only), plus an `availability` enum.
// The ADR-010 tenancy `kind` ceiling is INHERITED from promotion (a binding is
// only `enabled` for a workspace after the promotion lane cleared the ceiling), so
// this read path never re-derives `kind` — it cannot mark `available` anything that
// was not actually promoted+enabled for the workspace.

/**
 * Whether a route is usable in this workspace right now:
 * - `available` — readiness `promoted` AND binding `enabled` for the workspace.
 * - `gated`     — declared in the catalog but not (yet) promoted/enabled. Promotable.
 * - `blocked`   — cannot be promoted due to an external dependency (see `gateReason`).
 */
export type ProducerRouteAvailabilityV1 = 'available' | 'gated' | 'blocked';

/** A catalog route view enriched with its per-workspace availability. */
export type ProducerFleetRouteViewV1 = ProducerCatalogViewV1 &
  Readonly<{
    availability: ProducerRouteAvailabilityV1;
    /**
     * Why the route is not `available`. Stable machine token, never a raw error:
     * `not_promoted` for `gated`; an external-gate token (e.g.
     * `provider_verifier_pending`, `provider_allowlist_pending`) for `blocked`.
     * Absent when `available`.
     */
    gateReason?: string;
  }>;

/** Optional filter for the fleet reader (mirrors the catalog list query). */
export type ProducerFleetListQueryV1 = Readonly<{
  capability?: CreativeCapability;
  modality?: ProducerRouteModality;
}>;

/** The fleet reader payload: availability-aware routes + per-capability recommended defaults. */
export type ProducerFleetListDataV1 = Readonly<{
  schemaVersion: '1';
  catalogVersion: string;
  routes: readonly ProducerFleetRouteViewV1[];
  /**
   * Per-capability recommended default route (TASK-1553). Names a route, never a
   * slug. A consumer MAY preselect it; if that route is not `available`, the
   * consumer sees so via the route's `availability` and does not execute it.
   */
  recommendedDefaults: Readonly<Partial<Record<CreativeCapability, string>>>;
}>;
