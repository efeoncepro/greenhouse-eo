import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import {
  GLOBE_REFERENCE_INTELLIGENCE_COMMANDS,
  GLOBE_REFERENCE_INTELLIGENCE_READERS,
  REFERENCE_ANALYSIS_MODEL_VERSION_V1,
  type ReferenceProfileV1,
  type AppliedStyleEvidenceV1,
  type ProducerStyleSelectorV1,
} from './reference-intelligence.ts';

describe('reference intelligence wire contract', () => {
  it('uses stable command and reader names', () => {
    assert.equal(GLOBE_REFERENCE_INTELLIGENCE_COMMANDS.analyze, 'globe.lab.reference.analyze');
    assert.equal(GLOBE_REFERENCE_INTELLIGENCE_READERS.profileGet, 'globe.lab.reference.profile.get');
    assert.equal(REFERENCE_ANALYSIS_MODEL_VERSION_V1, 'style-dna-gemini-2.5-flash-v1');
  });

  it('requires explicit confidence and analysis/palette versions', () => {
    const profile: ReferenceProfileV1 = {
      schemaVersion: '1', profileRef: 'ref_1', referenceAssetId: 'asset_1',
      referenceSha256: `sha256:${'a'.repeat(64)}`, referenceRights: 'licensed',
      analysisModel: 'vision-analysis', analysisModelVersion: '2026-07-22',
      paletteAlgorithmVersion: 'median-cut-v1',
      palette: [{ color: '#112233', rgb: [17, 34, 51], weight: 1 }],
      styleDescriptors: [{ label: 'editorial', score: 0.82 }],
      composition: { framing: 'medium', layout: 'asymmetric', focalPlacement: 'left', depth: 'shallow', negativeSpace: 'right', ruleOfThirds: 'present' },
      producedAt: '2026-07-22T00:00:00.000Z',
    };
    assert.equal(profile.styleDescriptors[0]?.score, 0.82);
    assert.equal(profile.referenceRights, 'licensed');
  });

  it('keeps generation input to a pinned selector and effective evidence server-derived', () => {
    const selector: ProducerStyleSelectorV1 = { styleId: 'style-editorial', version: 3 };
    const evidence: AppliedStyleEvidenceV1 = {
      schemaVersion: '1', materializationVersion: 'style-materializer-v1',
      styleId: selector.styleId, styleVersion: selector.version, profileRef: 'ref_1',
      analysisModelVersion: 'vision-v2', paletteAlgorithmVersion: 'palette-v1',
      modes: ['match-palette'], styleStrength: 0.7,
    };
    assert.deepEqual(Object.keys(selector), ['styleId', 'version']);
    assert.equal(evidence.styleVersion, 3);
  });
});
