import type { GlobeCapability, ProducerOutputMediaType } from './index.js';

export const GLOBE_LIBRARY_READ_CAPABILITY = 'globe.producer.library.read' as GlobeCapability;
export const GLOBE_LIBRARY_MANAGE_CAPABILITY = 'globe.producer.library.manage' as GlobeCapability;
export const GLOBE_LIBRARY_EXPORT_CAPABILITY = 'globe.producer.library.export' as GlobeCapability;
export const GLOBE_LIBRARY_DELETE_CAPABILITY = 'globe.producer.library.delete' as GlobeCapability;

export const GLOBE_LIBRARY_COMMANDS = {
  createContainer: 'globe.producer.library.container.create',
  updateContainer: 'globe.producer.library.container.update',
  bulkPrepare: 'globe.producer.library.bulk.prepare',
  bulkExecute: 'globe.producer.library.bulk.execute',
  exportRequest: 'globe.producer.library.export.request',
  purgeRequest: 'globe.producer.library.purge.request',
} as const;

export const GLOBE_LIBRARY_READERS = {
  assets: 'globe.producer.library.asset.list',
  containers: 'globe.producer.library.container.list',
  container: 'globe.producer.library.container.get',
  operation: 'globe.producer.library.operation.get',
  exportStatus: 'globe.producer.library.export.status',
  exportDownload: 'globe.producer.library.export.download',
} as const;

export type LibraryContainerKindV1 = 'collection' | 'series';
export type LibraryContainerV1 = Readonly<{
  schemaVersion: '1'; containerId: string; kind: LibraryContainerKindV1; name: string;
  description?: string; version: number; itemCount: number; createdBy: string;
  createdAt: string; updatedAt: string; trashedAt?: string;
}>;
export type CreateLibraryContainerPayloadV1 = Readonly<{ kind: LibraryContainerKindV1; name: string; description?: string }>;
export type UpdateLibraryContainerPayloadV1 = Readonly<{ containerId: string; expectedVersion: number; name?: string; description?: string; trashed?: boolean }>;
export type LibraryContainerOutcomeV1 = Readonly<{ schemaVersion: '1'; container: LibraryContainerV1 }>;
export type LibraryContainerQueryV1 = Readonly<{ containerId: string }>;
export type LibraryContainerListQueryV1 = Readonly<{ cursor?: string; limit?: number; kind?: LibraryContainerKindV1; search?: string; state?: 'active' | 'trashed' }>;
export type LibraryContainerPageV1 = Readonly<{ schemaVersion: '1'; items: readonly LibraryContainerV1[]; nextCursor?: string }>;

/** Exact output identity. A hash alone is not ownership authority. */
export type LibraryAssetKeyV1 = Readonly<{ experimentId: string; sha256: string }>;
export type LibraryBulkActionV1 = 'add-to-container' | 'remove-from-container' | 'move-to-container' | 'trash' | 'restore';
export type LibraryOperationActionV1 = LibraryBulkActionV1 | 'purge-request';
export type PrepareLibraryBulkPayloadV1 = Readonly<{
  action: LibraryBulkActionV1; items: readonly LibraryAssetKeyV1[];
  destinationContainerId?: string; sourceContainerId?: string;
}>;
export type PreparedLibraryBulkV1 = Readonly<{
  schemaVersion: '1'; operationId: string; confirmationToken: string; action: LibraryBulkActionV1;
  items: readonly LibraryAssetKeyV1[]; destinationContainerId?: string; sourceContainerId?: string;
  expiresAt: string;
}>;
export type ExecuteLibraryBulkPayloadV1 = Readonly<{ operationId: string; confirmationToken: string; retryFailed?: boolean }>;
export type LibraryItemOutcomeV1 = Readonly<{
  item: LibraryAssetKeyV1; status: 'succeeded' | 'failed'; code: 'applied' | 'already-applied' | 'not-found' | 'conflict' | 'retention-blocked' | 'dependency-unavailable'; retryable: boolean;
}>;
export type LibraryBulkOperationV1 = Readonly<{
  schemaVersion: '1'; operationId: string; action: LibraryOperationActionV1;
  state: 'prepared' | 'running' | 'partially-succeeded' | 'succeeded' | 'failed';
  requested: number; succeeded: number; failed: number; items: readonly LibraryItemOutcomeV1[];
  createdBy: string; createdAt: string; updatedAt: string;
}>;
export type LibraryOperationQueryV1 = Readonly<{ operationId: string }>;

export type RequestLibraryExportPayloadV1 = Readonly<{ items: readonly LibraryAssetKeyV1[]; format: 'zip' | 'manifest-only' }>;
export type LibraryExportV1 = Readonly<{
  schemaVersion: '1'; exportId: string; state: 'queued' | 'running' | 'ready' | 'failed' | 'expired';
  format: 'zip' | 'manifest-only'; itemCount: number; manifestSha256?: string;
  artifactSha256?: string; artifactByteSize?: number; artifactMimeType?: 'application/zip' | 'application/json';
  failureCode?: 'dependency-unavailable' | 'asset-unavailable' | 'integrity-failed';
  createdBy: string; createdAt: string; updatedAt: string; expiresAt?: string;
}>;
export type LibraryExportQueryV1 = Readonly<{ exportId: string }>;
export type LibraryExportDownloadV1 = Readonly<{
  schemaVersion: '1'; exportId: string; artifactSha256: string; byteSize: number;
  mimeType: 'application/zip' | 'application/json'; retrievalGrant: string; grantExpiresAt: string;
}>;
export type RequestPurgePayloadV1 = Readonly<{ items: readonly LibraryAssetKeyV1[]; approvalRef: string }>;

/** Safe projection used by the library/feed. Never carries bytes, object coordinates or URLs. */
export type LibraryAssetProjectionV1 = Readonly<{
  schemaVersion: '1'; item: LibraryAssetKeyV1; mediaType: ProducerOutputMediaType;
  favorite: boolean; trashedAt?: string; containerIds: readonly string[];
  createdAt: string;
}>;
export type LibraryAssetListQueryV1 = Readonly<{
  cursor?: string; limit?: number; mediaType?: ProducerOutputMediaType;
  containerId?: string; state?: 'active' | 'trashed'; favorite?: boolean; search?: string;
  sort?: 'created-desc' | 'created-asc';
}>;
export type LibraryAssetPageV1 = Readonly<{
  schemaVersion: '1'; items: readonly LibraryAssetProjectionV1[]; nextCursor?: string;
}>;
