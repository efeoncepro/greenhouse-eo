import assert from 'node:assert/strict';
import { describe, it } from 'node:test';

import { GLOBE_CAPABILITIES, parseGlobeCapabilities } from './capabilities.ts';
import { GLOBE_PRODUCTION_ROUTING_CAPABILITIES, GLOBE_PRODUCTION_ROUTING_COMMANDS, GLOBE_PRODUCTION_ROUTING_READERS } from './production-routing-control.ts';

describe('production routing control contract', () => {
  it('uses dedicated operator authority and stable command/reader ids', () => {
    assert.ok(GLOBE_CAPABILITIES.includes(GLOBE_PRODUCTION_ROUTING_CAPABILITIES.read));
    assert.ok(GLOBE_CAPABILITIES.includes(GLOBE_PRODUCTION_ROUTING_CAPABILITIES.manage));
    assert.deepEqual(parseGlobeCapabilities(['globe.production-routing.read', 'unknown']), ['globe.production-routing.read']);
    assert.equal(GLOBE_PRODUCTION_ROUTING_COMMANDS.appendRoute, 'globe.production-routing.route.append');
    assert.equal(GLOBE_PRODUCTION_ROUTING_READERS.circuit, 'globe.production-routing.circuit.get');
  });
});
