export const GLOBE_CAPABILITIES = [
  'globe.studio.access',
  'globe.project.read',
  'globe.run.prepare',
  'globe.run.approve',
  'globe.delivery.release',
  'globe.lab.experiment.run',
  'globe.lab.evaluation.run',
  'globe.producer.catalog.read',
  'globe.producer.route.reveal_house',
  'globe.producer.assets.operate',
  'globe.producer.library.read',
  'globe.producer.library.manage',
  'globe.producer.library.export',
  'globe.producer.library.delete',
  'globe.producer.review.read',
  'globe.producer.review.decide',
  'globe.producer.comment.manage',
  'globe.producer.share.manage',
  'globe.voice.preset.manage',
  'globe.responsibility.manage',
  'globe.responsibility.read',
  'globe.credits.read',
  'globe.credits.estimate',
  'globe.credits.allocate',
  'globe.credits.reserve',
  'globe.credits.settle',
  'globe.credits.adjust',
  'globe.credits.pool.read',
  'globe.credits.pool.manage',
  'globe.credits.grant.read',
  'globe.credits.grant.issue',
  'globe.credits.grant.correct',
  'globe.credits.policy.read',
  'globe.credits.policy.manage',
  'globe.credits.budget.read',
  'globe.credits.budget.manage',
  'globe.credits.forecast.read',
  'globe.lab.recipe.author',
  'globe.tenancy.reconcile',
  'globe.tenancy.manage',
  'globe.tenancy.read',
  'globe.model-readiness.read',
  'globe.model-readiness.review',
  'globe.model-readiness.propose',
  'globe.model-readiness.promote',
  'globe.model-readiness.pause',
  'globe.model-readiness.retire',
  'globe.production-routing.read',
  'globe.production-routing.manage',
  'globe.asset-rights-policy.manage',
  'globe.asset-rights-policy.read',
] as const;

export type GlobeCapability = (typeof GLOBE_CAPABILITIES)[number];

/** Narrows untrusted broker grants to Globe's namespaced authority vocabulary. */
export function parseGlobeCapabilities(raw: readonly string[]): readonly GlobeCapability[] {
  const known = new Set<string>(GLOBE_CAPABILITIES);
  const seen = new Set<GlobeCapability>();
  for (const value of raw) if (known.has(value)) seen.add(value as GlobeCapability);
  return [...seen];
}
