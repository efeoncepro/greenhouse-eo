import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { GLOBE_LIBRARY_COMMANDS, GLOBE_LIBRARY_READERS, type LibraryBulkOperationV1 } from './asset-library.ts';

describe('Producer asset library contract', () => {
  it('keeps writes and reads on stable primitives', () => {
    assert.equal(GLOBE_LIBRARY_COMMANDS.bulkExecute, 'globe.producer.library.bulk.execute');
    assert.equal(GLOBE_LIBRARY_READERS.operation, 'globe.producer.library.operation.get');
    assert.equal(GLOBE_LIBRARY_READERS.exportDownload, 'globe.producer.library.export.download');
  });
  it('represents partial results per exact asset identity', () => {
    const operation: LibraryBulkOperationV1 = { schemaVersion: '1', operationId: 'op-a', action: 'trash', state: 'partially-succeeded', requested: 2, succeeded: 1, failed: 1, items: [
      { item: { experimentId: 'e1', sha256: `sha256:${'a'.repeat(64)}` }, status: 'succeeded', code: 'applied', retryable: false },
      { item: { experimentId: 'e2', sha256: `sha256:${'b'.repeat(64)}` }, status: 'failed', code: 'retention-blocked', retryable: false },
    ], createdBy: 'actor-a', createdAt: '2026-07-22T00:00:00.000Z', updatedAt: '2026-07-22T00:00:00.000Z' };
    assert.equal(operation.items[1]?.code, 'retention-blocked');
  });
});
