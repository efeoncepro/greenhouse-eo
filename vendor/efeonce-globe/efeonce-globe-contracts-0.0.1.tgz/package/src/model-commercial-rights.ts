import type { GlobeCapability } from './index.js';

export const GLOBE_MODEL_COMMERCIAL_RIGHTS_CAPABILITIES = {
  read: 'globe.model-rights.read' as GlobeCapability,
  attest: 'globe.model-rights.attest' as GlobeCapability,
} as const;

export const GLOBE_MODEL_COMMERCIAL_RIGHTS_COMMANDS = {
  attest: 'globe.model-rights.attest.record',
} as const;

export const GLOBE_MODEL_COMMERCIAL_RIGHTS_READERS = {
  get: 'globe.model-rights.get',
  list: 'globe.model-rights.list',
} as const;

/**
 * The exact executable model identity a license attestation is scoped to. Matches the model
 * fields of `ModelRouteIdentityV1`, so one attestation applies to every route that uses this
 * exact provider/model/version. Marketing aliases are deliberately not representable.
 */
export type CommercialRightsModelIdentityV1 = Readonly<{
  providerId: string;
  modelId: string;
  modelVersion: string;
}>;

/**
 * What the provider license ACTUALLY grants — never Efeonce opinion. Each flag is a real term
 * read from the attested evidence. `clientDelivery` is the flag the per-workspace ceiling gates
 * a `client` workspace on; `commercialUse` gates any paid internal/commercial use.
 */
export type CommercialRightsGrantV1 = Readonly<{
  commercialUse: boolean;
  clientDelivery: boolean;
  sublicensable: boolean;
}>;

/**
 * Immutable human attestation of what a model's provider license grants. Signed server-side over
 * every field except the signature; an identifier alone is never evidence. Immutable per
 * `(providerId, modelId, modelVersion, providerTermsDigest)` — a license change is a NEW
 * attestation under a new digest, never an edit.
 */
export type ModelCommercialRightsAttestationV1 = Readonly<{
  schemaVersion: '1';
  attestationId: string;
  model: CommercialRightsModelIdentityV1;
  /** Scrubbed source URL of the provider license terms. */
  providerTermsRef: string;
  /** `sha256:…` digest of the durable terms evidence. The immutability anchor. */
  providerTermsDigest: string;
  grant: CommercialRightsGrantV1;
  reasonCode: string;
  reviewer: Readonly<{ principalId: string; principalType: 'human' }>;
  correlationId: string;
  createdAt: string;
  attestationSignature: string;
}>;

export type RecordModelCommercialRightsPayloadV1 = Readonly<{
  model: CommercialRightsModelIdentityV1;
  providerTermsRef: string;
  providerTermsDigest: string;
  grant: CommercialRightsGrantV1;
  reasonCode: string;
}>;

export type ModelCommercialRightsQueryV1 = Readonly<{
  providerId: string;
  modelId: string;
  modelVersion: string;
}>;

export type ModelCommercialRightsListQueryV1 = Readonly<{
  providerId?: string;
  limit?: number;
  cursor?: string;
}>;

export type ModelCommercialRightsPageV1 = Readonly<{
  schemaVersion: '1';
  items: readonly ModelCommercialRightsAttestationV1[];
  nextCursor?: string;
}>;
