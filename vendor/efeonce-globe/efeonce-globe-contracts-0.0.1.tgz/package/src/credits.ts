import type { GlobeCapability } from './capabilities.ts';

export const GLOBE_CREDIT_CAPABILITIES = {
  read: 'globe.credits.read',
  estimate: 'globe.credits.estimate',
  allocate: 'globe.credits.allocate',
  reserve: 'globe.credits.reserve',
  settle: 'globe.credits.settle',
  adjust: 'globe.credits.adjust',
} as const satisfies Readonly<Record<string, GlobeCapability>>;

export const GLOBE_CREDIT_COMMANDS = {
  allocate: 'globe.credits.allocate',
  estimate: 'globe.credits.estimate',
  reserve: 'globe.credits.reserve',
  settle: 'globe.credits.settle',
  release: 'globe.credits.release',
  expire: 'globe.credits.expire',
  adjust: 'globe.credits.adjust',
} as const;

export const GLOBE_CREDIT_READERS = {
  balance: 'globe.credits.balance.get',
  estimate: 'globe.credits.estimate.get',
  reservation: 'globe.credits.reservation.get',
  entries: 'globe.credits.ledger.list',
  rates: 'globe.credits.rates.get',
  usage: 'globe.credits.usage.get',
} as const;

export type StudioCredits = number;
export type CreditOutputShapeV1 =
  | Readonly<{ modality:'image'; quality:string; aspectRatio:string; count:number }>
  | Readonly<{ modality:'video'; resolution:string; durationSeconds:number; aspectRatio:string; audioMode:string }>
  | Readonly<{ modality:'audio'; sampleRate:number; format:string; speed:number; volume:number; pitch:number }>;
export type CreditRouteEvidenceV1 = Readonly<{
  routeId: string;
  modelName: string;
  modelVersion?: string;
}>;

export type CreditRateV1 = Readonly<{
  schemaVersion: '1';
  rateId: string;
  catalogVersion: string;
  routeId: string;
  outputShapeKey: string;
  credits: StudioCredits;
  effectiveAt: string;
}>;

export type CreditRateCatalogV1 = Readonly<{
  schemaVersion: '1';
  catalogVersion: string;
  publishedAt: string;
  rates: readonly CreditRateV1[];
}>;

export type CreditEstimateV1 = Readonly<{
  schemaVersion: '1';
  estimateId: string;
  workspaceId: string;
  projectId?: string;
  runId?: string;
  route: CreditRouteEvidenceV1;
  outputShape: CreditOutputShapeV1;
  outputShapeKey: string;
  credits: StudioCredits;
  rateId: string;
  rateCatalogVersion: string;
  withinDayCap: boolean;
  createdAt: string;
  expiresAt: string;
}>;

export type CreditBalanceV1 = Readonly<{
  schemaVersion: '1';
  workspaceId: string;
  allocated: StudioCredits;
  reserved: StudioCredits;
  spent: StudioCredits;
  adjusted: StudioCredits;
  available: StudioCredits;
  asOf: string;
}>;

export type CreditFundingSourceV1 = Readonly<{
  sourceType: 'grant' | 'manual-allocation';
  sourceId: string;
  poolId?: string;
  grantId?: string;
}>;

export type CreditFundingBreakdownV1 = Readonly<{
  sourceType: CreditFundingSourceV1['sourceType'];
  sourceId: string;
  poolId?: string;
  grantId?: string;
  credits: StudioCredits;
}>;

export type CreditReservationStatusV1 = 'held' | 'settled' | 'released' | 'expired';

export type CreditReservationV1 = Readonly<{
  schemaVersion: '1';
  reservationId: string;
  workspaceId: string;
  projectId?: string;
  runId: string;
  estimateId: string;
  credits: StudioCredits;
  rateId: string;
  rateCatalogVersion: string;
  proposedRoute: CreditRouteEvidenceV1;
  fundingBreakdown: readonly CreditFundingBreakdownV1[];
  budgetPolicyVersion: string;
  status: CreditReservationStatusV1;
  createdAt: string;
  expiresAt: string;
  settledAt?: string;
  releasedAt?: string;
}>;

export type CreditProviderAttemptV1 = Readonly<{
  attempt: number;
  route: CreditRouteEvidenceV1;
  outcome: 'succeeded' | 'failed';
}>;

export type CreditLedgerEntryKindV1 =
  | 'allocation'
  | 'reservation'
  | 'settlement'
  | 'release'
  | 'expiration'
  | 'adjustment';

export type CreditLedgerEntryV1 = Readonly<{
  schemaVersion: '1';
  entryId: string;
  workspaceId: string;
  projectId?: string;
  runId?: string;
  reservationId?: string;
  kind: CreditLedgerEntryKindV1;
  allocatedDelta: StudioCredits;
  reservedDelta: StudioCredits;
  spentDelta: StudioCredits;
  adjustmentDelta: StudioCredits;
  reasonCode: string;
  sourceRef?: CreditFundingSourceV1;
  proposedRoute?: CreditRouteEvidenceV1;
  executedRoute?: CreditRouteEvidenceV1;
  attempts?: readonly CreditProviderAttemptV1[];
  rateId?: string;
  rateCatalogVersion?: string;
  budgetPolicyVersion?: string;
  correlationId: string;
  actor: Readonly<{ principalId: string; principalType: 'human' | 'service' }>;
  createdAt: string;
}>;

export type AllocateCreditsPayloadV1 = Readonly<{
  credits: StudioCredits;
  source: CreditFundingSourceV1;
  periodStart: string;
  periodEnd: string;
  reasonCode: string;
}>;

export type EstimateCreditsPayloadV1 = Readonly<{
  route: CreditRouteEvidenceV1;
  outputShape: CreditOutputShapeV1;
  projectId?: string;
  runId?: string;
}>;

export type ReserveCreditsPayloadV1 = Readonly<{
  estimateId: string;
  runId: string;
  projectId?: string;
  ttlSeconds: number;
}>;

export type SettleCreditsPayloadV1 = Readonly<{
  reservationId: string;
  actualCredits: StudioCredits;
  executedRoute: CreditRouteEvidenceV1;
  attempts: readonly CreditProviderAttemptV1[];
  reasonCode: string;
}>;

export type ReleaseCreditReservationPayloadV1 = Readonly<{
  reservationId: string;
  reasonCode: string;
}>;

export type ExpireCreditReservationPayloadV1 = Readonly<{
  reservationId: string;
}>;

export type PostCreditAdjustmentPayloadV1 = Readonly<{
  credits: StudioCredits;
  projectId?: string;
  runId?: string;
  reservationId?: string;
  reasonCode: string;
}>;

export type CreditLedgerListQueryV1 = Readonly<{
  limit?: number;
  before?: Readonly<{ createdAt: string; entryId: string }>;
  projectId?: string;
  runId?: string;
  kind?: CreditLedgerEntryKindV1;
}>;

export type CreditUsageSummaryQueryV1 = Readonly<{
  periodStart: string;
  periodEnd: string;
  projectId?: string;
}>;

export type CreditUsageSummaryV1 = Readonly<{
  schemaVersion: '1';
  workspaceId: string;
  periodStart: string;
  periodEnd: string;
  projectId?: string;
  allocated: StudioCredits;
  spent: StudioCredits;
  adjusted: StudioCredits;
  reservationCount: number;
  settlementCount: number;
}>;
