import type { GlobeCapability, LabDerivedReferenceInputV1 } from './index.ts';

// --- Creative Producer output side: retrieval + asset actions (TASK-1503) -------
// TASK-1490 closed the WRITE half of the content-addressed store: a run's outputs are
// persisted under their `sha256` so a candidate can be refined by reference. This is the
// READ half made SERVABLE — the contract that lets a consumer download or preview a piece
// it already produced, and act on it (favorite, reuse as a reference).
//
// Two properties of that store make this a security surface rather than a convenience:
//
//   1. It is TENANT-BLIND. The object name IS the hash, one bucket for every workspace, so
//      the store cannot answer "may this caller read this?". The authority comes from the
//      DOMAIN, gating retrieval against the output hashes the caller's workspace actually
//      OWNS in its own experiments.
//   2. It holds BOTH output bytes and private-ingest INPUT reference bytes. Retrieval matches
//      only `outputHashes` of a retained candidate — never `authorizedInputHashes` — so a
//      declared input reference can never be read back out through this contract.
//
// Bytes NEVER travel in a reader result. The reader returns a DESCRIPTOR plus a short-lived,
// server-minted grant; the bytes are streamed by a dedicated transport route that redeems it.

/**
 * The authority to read and annotate a workspace's own producer outputs. Deliberately NOT a
 * reuse of `globe.lab.experiment.run`: that grant authorizes SPEND and lives on the workload
 * (api-mode) principal, while retrieval and annotation are zero-spend actions that must be
 * reachable by a human without ever conferring the ability to bill a provider.
 */
export const GLOBE_PRODUCER_ASSETS_CAPABILITY = 'globe.producer.assets.operate' satisfies GlobeCapability;

/**
 * Canonical producer asset reader names (wire identifiers). Kept separate from
 * `GLOBE_PRODUCER_READERS` (the route catalog): they answer to a different capability, so
 * folding them into one map would conflate two authorities in a single vocabulary.
 */
export const GLOBE_PRODUCER_ASSET_READERS = {
  output: 'globe.producer.output.get',
  assets: 'globe.producer.asset.list',
} as const;

/** Canonical producer asset command names (wire identifiers). */
export const GLOBE_PRODUCER_ASSET_COMMANDS = {
  favorite: 'globe.producer.asset.favorite',
  copyAsReference: 'globe.producer.asset.copyAsReference',
} as const;

/**
 * How the byte stream is presented: `inline` previews in place (an `<img>`/`<video>` source),
 * `attachment` downloads. It is part of the grant claims, so a grant minted for a preview
 * cannot be replayed to force a download (and vice versa).
 */
export type OutputDisposition = 'inline' | 'attachment';

/**
 * The media a producer output can be. A superset of `LabInputMediaType` on one axis (a mesh
 * can be produced) and a subset on another (`text` is not a retrievable creative output),
 * which is exactly why it is its own type rather than a reuse.
 */
export type ProducerOutputMediaType = 'image' | 'video' | 'audio' | 'model-3d';

export type GetOutputQueryV1 = Readonly<{
  experimentId: string;
  sha256: string;
  /** Defaults to `inline` when absent. */
  disposition?: OutputDisposition;
}>;

/**
 * A servable descriptor for one retained output. It NEVER carries bytes, a signed storage URL,
 * a bucket name, a provider slug, vendor cost or margin.
 *
 * `mediaType` is derived from the run's semantic capability — the only evidence the attempt
 * manifest carries. The authoritative content type of the bytes is resolved from the stored
 * object at serve time, so a multi-output run whose secondary output is another medium is
 * still streamed with its true `Content-Type` rather than a wrong one.
 */
export type ProducerOutputHandleV1 = Readonly<{
  schemaVersion: '1';
  experimentId: string;
  attemptId: string;
  sha256: string;
  mediaType: ProducerOutputMediaType;
  mimeType: string;
  disposition: OutputDisposition;
  /**
   * Opaque, server-minted, HMAC-signed and bound to (workspace, experiment, sha256,
   * disposition) with a short TTL. It is NOT a standalone bearer: the serving route
   * authenticates the caller first and re-checks ownership, so a leaked grant on its own
   * opens nothing. Never logged, never persisted, never echoed into an audit event.
   */
  retrievalGrant: string;
  grantExpiresAt: string;
}>;

export type FavoriteAssetPayloadV1 = Readonly<{
  experimentId: string;
  sha256: string;
  /** The DESIRED state, explicitly. Never a blind toggle: a retried command is idempotent. */
  favorite: boolean;
}>;

export type CopyAsReferencePayloadV1 = Readonly<{
  experimentId: string;
  sha256: string;
}>;

/**
 * A platform-certified reference to the caller's own prior output. Bytes NEVER cross the API:
 * a reference travels as `hash + rights`, exactly like a private-ingest input.
 *
 * `rights` is always `derived-internal` — a posture a caller cannot declare, because only the
 * platform can certify that bytes came out of a governed run of its own. `parentRights` carries
 * the parent's own most-restrictive posture forward, so a `licensed` ancestor keeps constraining
 * its descendants instead of being laundered into `internal-owned`.
 */
export type ProducerReferenceHandleV1 = LabDerivedReferenceInputV1;

export type ProducerFavoriteV1 = Readonly<{
  experimentId: string;
  sha256: string;
  favoritedAt: string;
}>;

/** The workspace's own annotations, for the producer feed. Scoped server-side, never filtered client-side. */
export type AssetAnnotationsDataV1 = Readonly<{
  schemaVersion: '1';
  favorites: readonly ProducerFavoriteV1[];
  references: readonly ProducerReferenceHandleV1[];
}>;

/** The outcome of a favorite command: the resulting desired state, echoed for confirmation. */
export type FavoriteAssetOutcomeV1 = Readonly<{
  schemaVersion: '1';
  experimentId: string;
  sha256: string;
  favorite: boolean;
  favoritedAt?: string;
}>;
