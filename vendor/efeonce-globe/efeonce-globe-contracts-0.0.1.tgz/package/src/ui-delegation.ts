import { GLOBE_CAPABILITIES, type GlobeCapability } from './capabilities.ts';

export const GLOBE_UI_DELEGATION_VERSION = 'v1' as const;
export const GLOBE_UI_DELEGATION_PURPOSE = 'ui' as const;
export const GLOBE_UI_DELEGATION_SURFACE = 'ui' as const;
export const GLOBE_UI_DELEGATION_MAX_TTL_SECONDS = 30 as const;

const BODY_SHA256 = /^sha256:[0-9a-f]{64}$/;
// This field carries the exact command/reader id, not only an authorization capability.
// The canonical registry includes legacy camelCase operation ids such as
// `globe.producer.asset.copyAsReference`; rejecting uppercase here makes the BFF unable to mint
// a delegation for an operation that the API itself publishes. Keep the namespace and alphabet
// strict while accepting the complete operation-id grammar used by the contract spine.
const OPERATION_ID = /^globe\.[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/;
const METHOD = /^[A-Z]{3,10}$/;
const SAFE_ID = /^[A-Za-z0-9][A-Za-z0-9._:@/-]{0,255}$/;
// Context identifiers may carry a canonical route id (for example
// `ref/still/nanobanana-pro-v1`) inside an idempotency key. Route ids are
// intentionally path-shaped, so `/` is safe here and remains bounded by the
// same strict alphabet/length contract.
const SAFE_CONTEXT_ID = /^[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}$/;

/** The exact private-API request a UI delegation authorizes. */
export type GlobeUiDelegationRequestV1 = Readonly<{
  method: string;
  path: string;
  bodySha256: string;
  capability: string;
  correlationId: string;
  idempotencyKey?: string;
}>;

/**
 * Short-lived, request-bound authority minted by the same-origin BFF for the IAM-private API.
 * It is evidence, not a workload credential: Cloud Run IAM still authenticates `caller`.
 */
export type GlobeUiDelegationClaimsV1 = Readonly<{
  schemaVersion: '1';
  iss: string;
  aud: string;
  purpose: typeof GLOBE_UI_DELEGATION_PURPOSE;
  caller: string;
  actorId: string;
  workspaceId: string;
  capabilities: readonly GlobeCapability[];
  surface: typeof GLOBE_UI_DELEGATION_SURFACE;
  request: GlobeUiDelegationRequestV1;
  fingerprint: string;
  iat: number;
  exp: number;
  jti: string;
}>;

export type CanonicalJsonValue =
  | null
  | boolean
  | number
  | string
  | readonly CanonicalJsonValue[]
  | Readonly<{ [key: string]: CanonicalJsonValue }>;

/** Deterministic JSON: object keys sorted recursively, arrays kept in declared order. */
export function canonicalJson(value: CanonicalJsonValue): string {
  if (value === null || typeof value === 'boolean' || typeof value === 'string') return JSON.stringify(value);
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) throw new Error('globe_ui_delegation_non_finite_number');
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) return `[${value.map(entry => canonicalJson(entry)).join(',')}]`;

  const record = value as Readonly<Record<string, CanonicalJsonValue>>;
  return `{${Object.keys(record)
    .sort()
    .map(key => `${JSON.stringify(key)}:${canonicalJson(record[key] as CanonicalJsonValue)}`)
    .join(',')}}`;
}

export function normalizeGlobeUiDelegationRequest(
  input: GlobeUiDelegationRequestV1,
): GlobeUiDelegationRequestV1 {
  const method = input.method.toUpperCase();
  if (!METHOD.test(method)) throw new Error('globe_ui_delegation_method_invalid');
  if (!validPath(input.path)) throw new Error('globe_ui_delegation_path_invalid');
  if (!BODY_SHA256.test(input.bodySha256)) throw new Error('globe_ui_delegation_body_hash_invalid');
  if (!OPERATION_ID.test(input.capability)) throw new Error('globe_ui_delegation_capability_invalid');
  if (!SAFE_CONTEXT_ID.test(input.correlationId)) throw new Error('globe_ui_delegation_correlation_invalid');
  if (input.idempotencyKey !== undefined && !SAFE_CONTEXT_ID.test(input.idempotencyKey)) {
    throw new Error('globe_ui_delegation_idempotency_invalid');
  }
  return {
    method,
    path: input.path,
    bodySha256: input.bodySha256,
    capability: input.capability,
    correlationId: input.correlationId,
    ...(input.idempotencyKey !== undefined ? { idempotencyKey: input.idempotencyKey } : {}),
  };
}

export function canonicalizeGlobeUiDelegationRequest(input: GlobeUiDelegationRequestV1): string {
  const request = normalizeGlobeUiDelegationRequest(input);
  return canonicalJson(request as CanonicalJsonValue);
}

export function canonicalizeGlobeUiDelegationClaims(claims: GlobeUiDelegationClaimsV1): string {
  return canonicalJson(claims as CanonicalJsonValue);
}

/** Strict parser for authenticated payloads. Unknown fields and non-canonical sets fail closed. */
export function parseGlobeUiDelegationClaims(raw: unknown): GlobeUiDelegationClaimsV1 | undefined {
  if (!isRecord(raw) || !hasExactKeys(raw, CLAIM_KEYS)) return undefined;
  if (raw.schemaVersion !== '1') return undefined;
  if (!safeId(raw.iss) || !safeId(raw.aud) || !safeId(raw.caller)) return undefined;
  if (raw.purpose !== GLOBE_UI_DELEGATION_PURPOSE || raw.surface !== GLOBE_UI_DELEGATION_SURFACE) return undefined;
  if (!safeId(raw.actorId) || !safeId(raw.workspaceId)) return undefined;
  if (typeof raw.jti !== 'string' || !SAFE_CONTEXT_ID.test(raw.jti)) return undefined;
  if (typeof raw.iat !== 'number' || !Number.isSafeInteger(raw.iat)) return undefined;
  if (typeof raw.exp !== 'number' || !Number.isSafeInteger(raw.exp)) return undefined;
  if (typeof raw.fingerprint !== 'string' || !BODY_SHA256.test(raw.fingerprint)) return undefined;
  const capabilities = parseCapabilities(raw.capabilities);
  const request = parseRequest(raw.request);
  if (!capabilities || !request) return undefined;

  return {
    schemaVersion: '1',
    iss: raw.iss,
    aud: raw.aud,
    purpose: GLOBE_UI_DELEGATION_PURPOSE,
    caller: raw.caller,
    actorId: raw.actorId,
    workspaceId: raw.workspaceId,
    capabilities,
    surface: GLOBE_UI_DELEGATION_SURFACE,
    request,
    fingerprint: raw.fingerprint,
    iat: raw.iat,
    exp: raw.exp,
    jti: raw.jti,
  };
}

const CLAIM_KEYS = new Set([
  'schemaVersion', 'iss', 'aud', 'purpose', 'caller', 'actorId', 'workspaceId', 'capabilities',
  'surface', 'request', 'fingerprint', 'iat', 'exp', 'jti',
]);
const REQUEST_KEYS = new Set(['method', 'path', 'bodySha256', 'capability', 'correlationId', 'idempotencyKey']);
const KNOWN_CAPABILITIES = new Set<string>(GLOBE_CAPABILITIES);

function parseRequest(raw: unknown): GlobeUiDelegationRequestV1 | undefined {
  if (!isRecord(raw) || !hasExactKeys(raw, REQUEST_KEYS, new Set(['idempotencyKey']))) return undefined;
  if (
    typeof raw.method !== 'string' || typeof raw.path !== 'string' || typeof raw.bodySha256 !== 'string' ||
    typeof raw.capability !== 'string' || typeof raw.correlationId !== 'string'
  ) return undefined;
  if (raw.idempotencyKey !== undefined && typeof raw.idempotencyKey !== 'string') return undefined;
  try {
    return normalizeGlobeUiDelegationRequest({
      method: raw.method,
      path: raw.path,
      bodySha256: raw.bodySha256,
      capability: raw.capability,
      correlationId: raw.correlationId,
      ...(raw.idempotencyKey !== undefined ? { idempotencyKey: raw.idempotencyKey } : {}),
    });
  } catch {
    return undefined;
  }
}

function parseCapabilities(raw: unknown): readonly GlobeCapability[] | undefined {
  if (!Array.isArray(raw) || raw.length === 0 || raw.length > GLOBE_CAPABILITIES.length) return undefined;
  if (!raw.every(value => typeof value === 'string' && KNOWN_CAPABILITIES.has(value))) return undefined;
  const values = raw as GlobeCapability[];
  if (new Set(values).size !== values.length) return undefined;
  const sorted = [...values].sort();
  if (!values.every((value, index) => value === sorted[index])) return undefined;
  return [...values];
}

function validPath(value: string): boolean {
  return value.length > 0 && value.length <= 2048 && value.startsWith('/') && !/[?#\u0000-\u001f\u007f]/.test(value);
}

function safeId(value: unknown): value is string {
  return typeof value === 'string' && SAFE_ID.test(value);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function hasExactKeys(record: Record<string, unknown>, allowed: ReadonlySet<string>, optional: ReadonlySet<string> = new Set()): boolean {
  const keys = Object.keys(record);
  if (keys.some(key => !allowed.has(key))) return false;
  for (const key of allowed) if (!optional.has(key) && !Object.hasOwn(record, key)) return false;
  return true;
}
