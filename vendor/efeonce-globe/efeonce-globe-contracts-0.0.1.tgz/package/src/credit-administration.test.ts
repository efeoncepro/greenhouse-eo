import assert from 'node:assert/strict';
import { describe,it } from 'node:test';
import { CREDIT_DENIAL_PHASES,GLOBE_CREDIT_ADMIN_CAPABILITIES,GLOBE_CREDIT_ADMIN_COMMANDS,GLOBE_CREDIT_ADMIN_READERS,GLOBE_CREDIT_FUNDING_CAPABILITIES,GLOBE_CREDIT_FUNDING_COMMANDS,GLOBE_CREDIT_FUNDING_READERS,type AuthenticatedUserAttributionV1,type CreditDecisionSnapshotV2,type CreditFundingOperationV1,type CreditGrantV1,type HumanAttributionV1 } from './credit-administration.ts';
describe('credit administration wire contract',()=>{
  it('publishes the complete governed surface',()=>{ assert.equal(Object.keys(GLOBE_CREDIT_ADMIN_CAPABILITIES).length,10); assert.equal(Object.keys(GLOBE_CREDIT_ADMIN_COMMANDS).length,14); assert.equal(Object.keys(GLOBE_CREDIT_ADMIN_READERS).length,10); });
  it('keeps credits distinct from money and provider units',()=>{ const text=JSON.stringify({GLOBE_CREDIT_ADMIN_CAPABILITIES,GLOBE_CREDIT_ADMIN_COMMANDS}); assert.doesNotMatch(text,/currency|usd|token|price|checkout/i); });
  /*
   * El colapso de TODA negacion de credito en `conflict` existe para no filtrar saldos ni politica
   * por una taxonomia compartida. La fase recupera el diagnostico SIN reabrir esa fuga — y este test
   * es lo que impide que alguien la reabra agregando una fase con un monto adentro.
   *
   * Recorre el union COMPLETO (el alias de cobertura del contrato garantiza que el array no quede
   * corto), asi que una fase nueva mal nombrada rompe aca y no en produccion.
   */
  it('never lets a denial phase carry an amount, an identifier or SQL',()=>{
    assert.ok(CREDIT_DENIAL_PHASES.length>=14);
    for(const phase of CREDIT_DENIAL_PHASES){
      assert.match(phase,/^[a-z][a-z_]*[a-z]$/,`${phase} debe ser un slug snake_case sin datos`);
      assert.doesNotMatch(phase,/[0-9]/,`${phase} contiene un digito`);
      assert.doesNotMatch(phase,/select|from|where|insert|update|delete|join/i,`${phase} contiene SQL`);
      // Ojo con el impulso de prohibir sustantivos: `insufficient_balance` NOMBRA el control y viene
      // del `code` que el ledger ya expone. El vector de fuga real es un VALOR o un ID, no la palabra.
      assert.doesNotMatch(phase,/_id$|_id_/,`${phase} nombra un identificador`);
      assert.ok(phase.length<=40,`${phase} es demasiado largo para ser un nombre de control`);
    }
    assert.equal(new Set(CREDIT_DENIAL_PHASES).size,CREDIT_DENIAL_PHASES.length);
  });
  it('separates the three approval failures, because they are three different operator actions',()=>{
    for(const phase of ['approval_self_confirmed','approval_expired','approval_invalid'] as const) assert.ok(CREDIT_DENIAL_PHASES.includes(phase));
  });
  it('does not admit purchased grants in V1',()=>{ const grant:CreditGrantV1={schemaVersion:'1',grantId:'g',workspaceId:'w',poolId:'p',kind:'internal',credits:10,periodStart:'2026-01-01T00:00:00Z',periodEnd:'2027-01-01T00:00:00Z',status:'pending',sourceId:'s',reasonCode:'pilot',proposedBy:'maker',createdAt:'2026-01-01T00:00:00Z',updatedAt:'2026-01-01T00:00:00Z'}; assert.equal(grant.kind,'internal'); });
  it('keeps the historical human attribution alias wire-compatible with authenticated users',()=>{
    const authenticated:AuthenticatedUserAttributionV1={principalId:'greenhouse:user:agent-codex',entitlement:'fund.confirm',at:'2026-08-01T00:00:00.000Z'};
    const legacy:HumanAttributionV1=authenticated;
    assert.deepEqual(Object.keys(legacy),['principalId','entitlement','at']);
  });
  it('publishes period, holds, remaining, coverage and freshness in the V2 decision snapshot',()=>{const snapshot:CreditDecisionSnapshotV2={schemaVersion:'2',workspaceId:'w',requestedCredits:1,allowed:true,policyVersion:'p:v1',period:{schemaVersion:'1',timezone:'UTC',start:'2026-08-01T00:00:00.000Z',end:'2026-09-01T00:00:00.000Z'},ledgerAvailable:10,monthly:{cap:10,spent:2,held:3,remaining:5},eligibleFunding:5,effectiveAvailable:5,blockers:[],fundingBreakdown:[{sourceType:'grant',sourceId:'g',poolId:'p',grantId:'g',credits:1}],coverage:{periodStart:'2026-08-01T00:00:00.000Z',periodEnd:'2026-09-01T00:00:00.000Z',candidateCount:1},freshnessSeconds:0,asOf:'2026-08-01T12:00:00.000Z'};assert.equal(snapshot.monthly.remaining,5);assert.equal(snapshot.period.timezone,'UTC');});
  it('separates operator read, recovery and redacted self authority',()=>{
    assert.deepEqual(Object.values(GLOBE_CREDIT_FUNDING_CAPABILITIES),[
      'globe.credits.funding.propose','globe.credits.funding.confirm','globe.credits.funding.read',
      'globe.credits.funding.reconcile','globe.credits.capacity.self.read',
    ]);
    assert.equal(GLOBE_CREDIT_FUNDING_COMMANDS.reconcile,'globe.credits.funding.operation.reconcile');
    assert.equal(GLOBE_CREDIT_FUNDING_READERS.capacitySelf,'globe.credits.capacity.self.get');
    assert.equal(GLOBE_CREDIT_FUNDING_READERS.operations,'globe.credits.funding.operation.list');
  });
  it('uses proposalId as the one stable funding operation identity',()=>{
    const operation:CreditFundingOperationV1={schemaVersion:'1',operationId:'proposal-a',proposalId:'proposal-a',workspaceId:'w',state:'outcome_unknown',fingerprint:'fp',plan:{schemaVersion:'1',workspaceId:'w',poolId:'p',grantCredits:10,monthlyCapBefore:20,spentInPeriod:2,policyAvailableBefore:18,policyAvailableAfter:20,periodStart:'2026-08-01T00:00:00.000Z',periodEnd:'2026-09-01T00:00:00.000Z'},proposedBy:{principalId:'u',entitlement:'fund.propose',at:'2026-08-01T00:00:00.000Z'},receipt:{schemaVersion:'1',outcome:'outcome_unknown',reasonCode:'partial_effects'},expiresAt:'2026-08-01T00:15:00.000Z',createdAt:'2026-08-01T00:00:00.000Z',updatedAt:'2026-08-01T00:01:00.000Z'};
    assert.equal(operation.operationId,operation.proposalId);
  });
});
