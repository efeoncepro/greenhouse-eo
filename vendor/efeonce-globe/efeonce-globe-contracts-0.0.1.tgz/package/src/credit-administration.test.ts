import assert from 'node:assert/strict';
import { describe,it } from 'node:test';
import { CREDIT_DENIAL_PHASES,GLOBE_CREDIT_ADMIN_CAPABILITIES,GLOBE_CREDIT_ADMIN_COMMANDS,GLOBE_CREDIT_ADMIN_READERS,type CreditGrantV1 } from './credit-administration.ts';
describe('credit administration wire contract',()=>{
  it('publishes the complete governed surface',()=>{ assert.equal(Object.keys(GLOBE_CREDIT_ADMIN_CAPABILITIES).length,10); assert.equal(Object.keys(GLOBE_CREDIT_ADMIN_COMMANDS).length,14); assert.equal(Object.keys(GLOBE_CREDIT_ADMIN_READERS).length,10); });
  it('keeps credits distinct from money and provider units',()=>{ const text=JSON.stringify({GLOBE_CREDIT_ADMIN_CAPABILITIES,GLOBE_CREDIT_ADMIN_COMMANDS}); assert.doesNotMatch(text,/currency|usd|token|price|checkout/i); });
  /*
   * El colapso de TODA negacion de credito en `conflict` existe para no filtrar saldos ni politica
   * por una taxonomia compartida. La fase recupera el diagnostico SIN reabrir esa fuga — y este test
   * es lo que impide que alguien la reabra agregando una fase con un monto adentro.
   *
   * Recorre el union COMPLETO (el alias de cobertura del contrato garantiza que el array no quede
   * corto), asi que una fase nueva mal nombrada rompe aca y no en produccion.
   */
  it('never lets a denial phase carry an amount, an identifier or SQL',()=>{
    assert.ok(CREDIT_DENIAL_PHASES.length>=14);
    for(const phase of CREDIT_DENIAL_PHASES){
      assert.match(phase,/^[a-z][a-z_]*[a-z]$/,`${phase} debe ser un slug snake_case sin datos`);
      assert.doesNotMatch(phase,/[0-9]/,`${phase} contiene un digito`);
      assert.doesNotMatch(phase,/select|from|where|insert|update|delete|join/i,`${phase} contiene SQL`);
      // Ojo con el impulso de prohibir sustantivos: `insufficient_balance` NOMBRA el control y viene
      // del `code` que el ledger ya expone. El vector de fuga real es un VALOR o un ID, no la palabra.
      assert.doesNotMatch(phase,/_id$|_id_/,`${phase} nombra un identificador`);
      assert.ok(phase.length<=40,`${phase} es demasiado largo para ser un nombre de control`);
    }
    assert.equal(new Set(CREDIT_DENIAL_PHASES).size,CREDIT_DENIAL_PHASES.length);
  });
  it('separates the three approval failures, because they are three different operator actions',()=>{
    for(const phase of ['approval_self_confirmed','approval_expired','approval_invalid'] as const) assert.ok(CREDIT_DENIAL_PHASES.includes(phase));
  });
  it('does not admit purchased grants in V1',()=>{ const grant:CreditGrantV1={schemaVersion:'1',grantId:'g',workspaceId:'w',poolId:'p',kind:'internal',credits:10,periodStart:'2026-01-01T00:00:00Z',periodEnd:'2027-01-01T00:00:00Z',status:'pending',sourceId:'s',reasonCode:'pilot',proposedBy:'maker',createdAt:'2026-01-01T00:00:00Z',updatedAt:'2026-01-01T00:00:00Z'}; assert.equal(grant.kind,'internal'); });
});
