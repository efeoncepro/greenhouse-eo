import assert from 'node:assert/strict';
import { describe,it } from 'node:test';
import { GLOBE_CREDIT_ADMIN_CAPABILITIES,GLOBE_CREDIT_ADMIN_COMMANDS,GLOBE_CREDIT_ADMIN_READERS,type CreditGrantV1 } from './credit-administration.ts';
describe('credit administration wire contract',()=>{
  it('publishes the complete governed surface',()=>{ assert.equal(Object.keys(GLOBE_CREDIT_ADMIN_CAPABILITIES).length,10); assert.equal(Object.keys(GLOBE_CREDIT_ADMIN_COMMANDS).length,14); assert.equal(Object.keys(GLOBE_CREDIT_ADMIN_READERS).length,10); });
  it('keeps credits distinct from money and provider units',()=>{ const text=JSON.stringify({GLOBE_CREDIT_ADMIN_CAPABILITIES,GLOBE_CREDIT_ADMIN_COMMANDS}); assert.doesNotMatch(text,/currency|usd|token|price|checkout/i); });
  it('does not admit purchased grants in V1',()=>{ const grant:CreditGrantV1={schemaVersion:'1',grantId:'g',workspaceId:'w',poolId:'p',kind:'internal',credits:10,periodStart:'2026-01-01T00:00:00Z',periodEnd:'2027-01-01T00:00:00Z',status:'pending',sourceId:'s',reasonCode:'pilot',proposedBy:'maker',createdAt:'2026-01-01T00:00:00Z',updatedAt:'2026-01-01T00:00:00Z'}; assert.equal(grant.kind,'internal'); });
});
