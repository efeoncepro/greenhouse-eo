import type { GlobeCapability } from './capabilities.ts';

export const GLOBE_TENANCY_CAPABILITIES = {
  reconcile: 'globe.tenancy.reconcile',
  manage: 'globe.tenancy.manage',
  read: 'globe.tenancy.read',
} as const;

export const GLOBE_TENANCY_COMMANDS = {
  reconcile: 'globe.tenancy.projection.reconcile',
  grant: 'globe.tenancy.grant.issue',
  revokeGrant: 'globe.tenancy.grant.revoke',
} as const;

export const GLOBE_TENANCY_READERS = {
  get: 'globe.tenancy.workspace.get',
  effectiveAccess: 'globe.tenancy.access.effective',
  grantHistory: 'globe.tenancy.grant.history',
} as const;

export type BrokerBindingStateV1 = 'active' | 'suspended' | 'revoked';
export type ProjectedMemberStateV1 = 'active' | 'suspended' | 'revoked';
export type ProjectedGrantStateV1 = 'active' | 'revoked' | 'expired' | 'superseded';

/** Broker statement. It deliberately has no Globe workspace id or local authority fields. */
export type BrokerTenancySnapshotV1 = Readonly<{
  schemaVersion: '1';
  brokerBindingId: string;
  bindingState: BrokerBindingStateV1;
  brokerRevision: number;
  issuedAt: string;
  expiresAt: string;
  member: Readonly<{
    identityIssuer: 'greenhouse';
    identitySubject: string;
    state: ProjectedMemberStateV1;
    expiresAt: string;
  }>;
  desiredCapabilities: readonly GlobeCapability[];
}>;

export type BrokerTenancySnapshotV2 = Readonly<{
  schemaVersion: '2';
  brokerBindingId: string;
  bindingState: BrokerBindingStateV1;
  /** Monotonic only when workspace desired state changes; lease renewal does not increment it. */
  workspaceRevision: number;
  /** Unique broker assertion/receipt id. It is not authority and may change on every renewal. */
  reconciliationId: string;
  issuedAt: string;
  expiresAt: string;
  /** Complete desired membership set for this workspace, applied atomically. */
  members: readonly Readonly<{
    identityIssuer: 'greenhouse';
    identitySubject: string;
    state: ProjectedMemberStateV1;
    /** Monotonic only when this subject's desired state/capability ceiling changes. */
    memberRevision: number;
    desiredCapabilities: readonly GlobeCapability[];
    expiresAt: string;
  }>[];
}>;

export type ReconcileTenancyProjectionPayloadV1 = Readonly<{
  snapshot: BrokerTenancySnapshotV1;
  expectedWorkspaceVersion?: number;
}>;

export type ReconcileTenancyProjectionPayloadV2 = Readonly<{
  snapshot: BrokerTenancySnapshotV2;
  expectedWorkspaceVersion?: number;
}>;

export type WorkspaceTenancyProjectionV1 = Readonly<{
  schemaVersion: '1';
  workspaceId: string;
  brokerBindingId: string;
  state: 'shadow' | 'active' | 'suspended';
  brokerState: BrokerBindingStateV1;
  brokerRevision: number;
  brokerFingerprint: string;
  brokerIssuedAt: string;
  brokerExpiresAt: string;
  version: number;
  updatedAt: string;
  contractVersion?: '1' | '2';
}>;

export type WorkspaceMemberProjectionV1 = Readonly<{
  schemaVersion: '1';
  workspaceId: string;
  memberId: string;
  identityIssuer: 'greenhouse';
  identitySubject: string;
  state: ProjectedMemberStateV1;
  brokerRevision: number;
  /** Broker-owned ceiling for this exact subject; local grants may only narrow it. */
  desiredCapabilities: readonly GlobeCapability[];
  expiresAt: string;
  version: number;
  updatedAt: string;
  contractVersion?: '1' | '2';
  memberRevision?: number;
  memberFingerprint?: string;
  absentFromFullSnapshot?: boolean;
}>;

export type WorkspaceGrantRevisionV1 = Readonly<{
  schemaVersion: '1';
  workspaceId: string;
  grantId: string;
  revision: number;
  memberId: string;
  capability: GlobeCapability;
  state: ProjectedGrantStateV1;
  brokerRevision: number;
  validFrom: string;
  expiresAt: string;
  reasonCode: string;
  supersedesRevision?: number;
  changedBy: Readonly<{ principalId: string; principalType: 'human' | 'service' }>;
  correlationId: string;
  createdAt: string;
  /** V2 grants bind to member semantic state, never to a renewable workspace lease. */
  brokerMemberRevision?: number;
}>;

export type WorkspaceTenancyAggregateV1 = Readonly<{
  schemaVersion: '1';
  workspace: WorkspaceTenancyProjectionV1;
  members: readonly WorkspaceMemberProjectionV1[];
  currentGrants: readonly WorkspaceGrantRevisionV1[];
}>;

export type IssueWorkspaceGrantPayloadV1 = Readonly<{
  memberId: string;
  capability: GlobeCapability;
  expiresAt: string;
  reasonCode: string;
  expectedRevision: number;
}>;

export type RevokeWorkspaceGrantPayloadV1 = Readonly<{
  grantId: string;
  reasonCode: string;
  expectedRevision: number;
}>;

export type EffectiveWorkspaceAccessV1 = Readonly<{
  schemaVersion: '1';
  workspaceId: string;
  identitySubject: string;
  authorized: boolean;
  capabilities: readonly GlobeCapability[];
  denialReason?: 'workspace-unavailable' | 'projection-stale' | 'member-inactive' | 'member-expired';
  brokerRevision?: number;
  memberRevision?: number;
}>;

export type WorkspaceGrantHistoryV1 = Readonly<{
  schemaVersion: '1';
  workspaceId: string;
  grantId: string;
  revisions: readonly WorkspaceGrantRevisionV1[];
}>;
