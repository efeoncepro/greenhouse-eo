import type { LabInputRights } from './index.js';

/**
 * Pinned analysis policy/model version accepted by the V1 command. Keeping this in the
 * transport-neutral contract prevents callers from inventing cache-busting model versions.
 */
export const REFERENCE_ANALYSIS_MODEL_VERSION_V1 = 'style-dna-gemini-2.5-flash-v1' as const;

export const GLOBE_REFERENCE_INTELLIGENCE_COMMANDS = {
  analyze: 'globe.lab.reference.analyze',
  createStyle: 'globe.producer.style.create',
  versionStyle: 'globe.producer.style.version.create',
  recordRouteDecision: 'globe.producer.route.decision.record',
} as const;

export const GLOBE_REFERENCE_INTELLIGENCE_READERS = {
  profileGet: 'globe.lab.reference.profile.get',
  styleGet: 'globe.producer.style.get',
  styleList: 'globe.producer.style.list',
  styleMaterialize: 'globe.producer.style.materialize',
  routeRecommend: 'globe.producer.route.recommend',
} as const;

export type ReferencePaletteColorV1 = Readonly<{
  color: `#${string}`;
  rgb: readonly [number, number, number];
  weight: number;
}>;

export type ReferenceStyleDescriptorV1 = Readonly<{
  label: string;
  /** Confidence emitted by the analysis model. There is deliberately no default. */
  score: number;
}>;

export type ReferenceCompositionV1 = Readonly<{
  framing: string;
  layout: string;
  focalPlacement: string;
  depth: string;
  negativeSpace: string;
  ruleOfThirds: 'present' | 'absent' | 'uncertain';
}>;

export type ReferenceProfileV1 = Readonly<{
  schemaVersion: '1';
  profileRef: string;
  referenceAssetId: string;
  referenceSha256: string;
  referenceRights: LabInputRights | 'derived-internal';
  analysisModel: string;
  analysisModelVersion: string;
  paletteAlgorithmVersion: string;
  palette: readonly ReferencePaletteColorV1[];
  styleDescriptors: readonly ReferenceStyleDescriptorV1[];
  composition: ReferenceCompositionV1;
  producedAt: string;
}>;

export type ReferenceConditioningModeV1 = 'match-palette' | 'match-composition';

export type ReferenceConditioningV1 = Readonly<{
  profileRef: string;
  modes: readonly ReferenceConditioningModeV1[];
  styleStrength: number;
}>;

export type AnalyzeReferencePayloadV1 = Readonly<{
  referenceAssetId: string;
  analysisModelVersion: string;
}>;

export type AnalyzeReferenceOutcomeV1 = Readonly<{
  schemaVersion: '1';
  profile: ReferenceProfileV1;
  cacheStatus: 'hit' | 'miss';
}>;

export type ReferenceProfileQueryV1 = Readonly<{ profileRef: string }>;
export type ReferenceProfileDataV1 = Readonly<{ schemaVersion: '1'; profile: ReferenceProfileV1 }>;

export type StyleCompatibilityV1 = Readonly<{
  modalities: readonly ('image' | 'video')[];
  routeIds: readonly string[];
}>;

export type StyleVersionV1 = Readonly<{
  schemaVersion: '1';
  styleId: string;
  version: number;
  name: string;
  description?: string;
  profileRef: string;
  referenceAssetId: string;
  referenceRights: ReferenceProfileV1['referenceRights'];
  conditioning: ReferenceConditioningV1;
  compatibility: StyleCompatibilityV1;
  authoredBy: string;
  createdAt: string;
}>;

export type CreateStylePayloadV1 = Readonly<{
  name: string;
  description?: string;
  profileRef: string;
  conditioning: Omit<ReferenceConditioningV1, 'profileRef'>;
  compatibility: StyleCompatibilityV1;
}>;

export type VersionStylePayloadV1 = CreateStylePayloadV1 & Readonly<{
  styleId: string;
  expectedVersion: number;
}>;

export type StyleVersionOutcomeV1 = Readonly<{ schemaVersion: '1'; style: StyleVersionV1 }>;
export type StyleGetQueryV1 = Readonly<{ styleId: string; version?: number }>;
export type StyleListQueryV1 = Readonly<{ cursor?: string; limit?: number }>;
export type StyleListDataV1 = Readonly<{
  schemaVersion: '1';
  items: readonly StyleVersionV1[];
  nextCursor?: string;
}>;
export type MaterializeStyleQueryV1 = Readonly<{ styleId: string; version: number }>;
export type MaterializedStyleV1 = Readonly<{
  schemaVersion: '1';
  styleId: string;
  styleVersion: number;
  profileRef: string;
  conditioning: ReferenceConditioningV1;
  compatibility: StyleCompatibilityV1;
}>;

/**
 * The only style input accepted by a generation/estimate surface. The browser pins an
 * immutable workspace style version; it cannot send a compiled prompt, profile, strength or
 * provider conditioning payload as part of a run.
 */
export type ProducerStyleSelectorV1 = Readonly<{
  styleId: string;
  version: number;
}>;

/**
 * Server-derived evidence for the exact style materialized into a run. This is safe to expose
 * in estimates and attempt manifests: it contains governed ids/versions and normalized
 * conditioning only, never reference bytes, provider payloads or storage coordinates.
 */
export type AppliedStyleEvidenceV1 = Readonly<{
  schemaVersion: '1';
  materializationVersion: 'style-materializer-v1';
  styleId: string;
  styleVersion: number;
  profileRef: string;
  analysisModelVersion: string;
  paletteAlgorithmVersion: string;
  modes: readonly ReferenceConditioningModeV1[];
  styleStrength: number;
}>;

export type AutoRouteCandidateV1 = Readonly<{
  routeId: string;
  catalogVersion: string;
  modalities: readonly ('image' | 'video' | 'audio')[];
  inputModes: readonly string[];
  styleCompatible: boolean;
  policyAllowed: boolean;
  estimatedCredits?: number;
}>;

export type AutoRouteRecommendationQueryV1 = Readonly<{
  policyVersion: string;
  modality: 'image' | 'video' | 'audio';
  hasPrompt: boolean;
  profileRef?: string;
  styleId?: string;
  styleVersion?: number;
  candidates: readonly AutoRouteCandidateV1[];
}>;

export type AutoRouteRecommendationV1 = Readonly<{
  schemaVersion: '1';
  policyVersion: string;
  catalogVersion: string;
  recommendedRouteId?: string;
  reasons: readonly string[];
  constraints: readonly string[];
}>;

export type RouteDecisionKindV1 = 'recommended' | 'human-selected' | 'executed';
export type RecordRouteDecisionPayloadV1 = Readonly<{
  runId: string;
  kind: RouteDecisionKindV1;
  routeId: string;
  catalogVersion: string;
  policyVersion?: string;
}>;

export type RouteDecisionFactV1 = RecordRouteDecisionPayloadV1 & Readonly<{
  schemaVersion: '1';
  decisionId: string;
  actorId: string;
  correlationId: string;
  recordedAt: string;
}>;
