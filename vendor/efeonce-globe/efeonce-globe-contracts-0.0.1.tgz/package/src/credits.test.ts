import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { GLOBE_CREDIT_CAPABILITIES, GLOBE_CREDIT_COMMANDS, GLOBE_CREDIT_READERS } from './index.ts';

describe('Studio Credits wire vocabulary', () => {
  it('keeps all writes and reads on explicit canonical primitives', () => {
    assert.equal(new Set(Object.values(GLOBE_CREDIT_COMMANDS)).size, 7);
    assert.equal(new Set(Object.values(GLOBE_CREDIT_READERS)).size, 6);
    assert.deepEqual(Object.values(GLOBE_CREDIT_CAPABILITIES).sort(), [
      'globe.credits.adjust', 'globe.credits.allocate', 'globe.credits.estimate',
      'globe.credits.read', 'globe.credits.reserve', 'globe.credits.settle',
    ]);
  });
});
