/**
 * ADR-008 / TASK-1528 — versioned media derivatives.
 *
 * A derivative is addressed by its EXACT identity:
 *   (workspace, sourceSha256, sourceObjectGeneration, profileId, profileVersion,
 *    transformerVersion, outputMime)
 * Changing any component creates a NEW record/object; nothing is ever overwritten and a
 * derivative never replaces its original. Profiles are governed DATA, not UI branches:
 * every dimension/codec/quality below is explicit and versioned — no library defaults.
 */

export const GLOBE_MEDIA_DERIVATIVE_CAPABILITIES = {
  read: 'globe.media.derivative.read',
  operate: 'globe.media.derivative.operate',
} as const;

export const GLOBE_MEDIA_DERIVATIVE_COMMANDS = {
  request: 'globe.media.derivative.request',
} as const;

export const GLOBE_MEDIA_DERIVATIVE_READERS = {
  get: 'globe.media.derivative.get',
  list: 'globe.media.derivative.list',
  ticket: 'globe.media.derivative.ticket',
} as const;

export type MediaDerivativeMediaTypeV1 = 'image' | 'video' | 'audio';

export type MediaDerivativeStateV1 =
  | 'requested'
  | 'processing'
  | 'ready'
  | 'failed'
  | 'superseded';

/**
 * Deterministic transformer identity. Bumping the pinned ffmpeg build or any invocation
 * argument that changes output bytes REQUIRES bumping this constant, which creates new
 * derivative identities instead of silently mutating existing ones.
 */
export const MEDIA_TRANSFORMER_VERSION = 'ffmpeg-static-v1' as const;

export type MediaDerivativeProfileV1 = Readonly<{
  profileId: string;
  profileVersion: number;
  mediaType: MediaDerivativeMediaTypeV1;
  outputMime: string;
  /** Explicit, exhaustive transform parameters. Nothing may rely on tool defaults. */
  params: Readonly<Record<string, string | number | boolean>>;
  summary: string;
}>;

/** Governed profile catalog v1. Values are initial-conservative; canary evidence tunes them
 * by publishing NEW profile versions (old records become superseded, never rewritten). */
export const GLOBE_MEDIA_DERIVATIVE_PROFILES: readonly MediaDerivativeProfileV1[] = [
  {
    profileId: 'image.card-thumb', profileVersion: 1, mediaType: 'image', outputMime: 'image/webp',
    params: { maxEdge: 512, quality: 75, fit: 'inside', stripMetadata: true },
    summary: 'Card thumbnail: bounded WebP for feed cards.',
  },
  {
    profileId: 'image.viewer-preview', profileVersion: 1, mediaType: 'image', outputMime: 'image/webp',
    params: { maxEdge: 1600, quality: 80, fit: 'inside', stripMetadata: true },
    summary: 'Viewer preview: bounded WebP; the original remains the governed download.',
  },
  {
    profileId: 'video.poster', profileVersion: 1, mediaType: 'video', outputMime: 'image/webp',
    params: { frameAtSeconds: 1, maxEdge: 1280, quality: 78, stripMetadata: true },
    summary: 'Poster frame extracted at a fixed offset.',
  },
  {
    profileId: 'video.preview-transcode', profileVersion: 1, mediaType: 'video', outputMime: 'video/mp4',
    params: {
      maxHeight: 720, videoCodec: 'h264', videoProfile: 'main', pixelFormat: 'yuv420p',
      videoBitrateKbps: 2000, maxFps: 30, audioCodec: 'aac', audioBitrateKbps: 128, faststart: true,
    },
    summary: 'Browser-compatible MP4/H.264/AAC playback baseline (adaptive streaming deferred).',
  },
  {
    profileId: 'audio.waveform-peaks', profileVersion: 1, mediaType: 'audio', outputMime: 'application/json',
    params: { bins: 1000, normalization: 'peak', channels: 'mono-mix' },
    summary: 'Waveform peaks as data (min/max bins); never an authority over the audio itself.',
  },
  {
    profileId: 'audio.preview-stream', profileVersion: 1, mediaType: 'audio', outputMime: 'audio/mp4',
    params: { audioCodec: 'aac', audioBitrateKbps: 128, sampleRateHz: 44100, channels: 2 },
    summary: 'Browser-compatible AAC preview stream; the original remains the governed download.',
  },
] as const;

export type MediaDerivativeIdentityV1 = Readonly<{
  sourceSha256: string;
  sourceObjectGeneration: string;
  profileId: string;
  profileVersion: number;
  transformerVersion: string;
  outputMime: string;
}>;

export type MediaDerivativeRecordV1 = Readonly<{
  schemaVersion: '1';
  workspaceId: string;
  derivativeId: string;
  identity: MediaDerivativeIdentityV1;
  mediaType: MediaDerivativeMediaTypeV1;
  state: MediaDerivativeStateV1;
  /** Present only when state is `ready`. */
  outputSha256?: string;
  byteLength?: number;
  width?: number;
  height?: number;
  durationMs?: number;
  lastSafeErrorCode?: string;
  attempts: number;
  createdAt: string;
  updatedAt: string;
}>;

export type RequestMediaDerivativesPayloadV1 = Readonly<{
  /** Experiment that owns the retained source output (ownership is re-verified server-side). */
  experimentId: string;
  sourceSha256: string;
  /** Optional subset; omitted means every governed profile matching the source media type. */
  profileIds?: readonly string[];
}>;

export type MediaDerivativeQueryV1 = Readonly<{ derivativeId: string }>;
export type MediaDerivativeListQueryV1 = Readonly<{
  sourceSha256?: string;
  state?: MediaDerivativeStateV1;
  limit?: number;
}>;
export type MediaDerivativePageV1 = Readonly<{
  schemaVersion: '1';
  items: readonly MediaDerivativeRecordV1[];
}>;

/** `original` or an exact `profileId@profileVersion`. Nothing else is representable. */
export type MediaRepresentationV1 = string;

export type MintMediaTicketQueryV1 = Readonly<{
  experimentId: string;
  sourceSha256: string;
  representation: MediaRepresentationV1;
  disposition?: 'inline' | 'attachment';
}>;

export type MediaTicketDescriptorV1 = Readonly<{
  schemaVersion: '1';
  ticket: string;
  expiresAt: string;
  /** Same-origin gateway path the browser can use directly as a media element src. */
  path: string;
  outputMime: string;
}>;
