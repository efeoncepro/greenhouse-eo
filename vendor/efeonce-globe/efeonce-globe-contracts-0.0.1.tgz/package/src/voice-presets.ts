import type { GlobeCapability, LabAuthorizedInputV1, LabInputRights } from './index.ts';

// --- Voice preset registry contract (TASK-1504) --------------------------------
// A reusable voice: the thing an operator picks once and then applies to every run,
// instead of re-describing a voice on each one.
//
// Three identities stay deliberately separate, for the same reason they do in the route
// catalog — and here the stakes are higher, because one of them identifies a PERSON:
//
//   1. `presetId`    — the workspace-scoped key a run declares. Meaningless outside its
//                      workspace, which is what makes cross-tenant reads answerable with
//                      a flat `not_found`.
//   2. `displayName` — client-facing. What a surface shows.
//   3. vendor voice id — the provider's own identifier. It lives ONLY inside the provider
//                      adapter's voice map, and is not representable in this contract.
//
// `catalogVoice` is the fourth, and the one that makes the separation work: Efeonce's OWN
// curated key ("nexa-es-neutral"), which the adapter maps to a vendor id. It is what the
// platform threads to the seam, so a tenant-scoped preset id never reaches a provider and a
// vendor id never reaches the domain.

/** The capability grant required to operate the voice preset registry. */
export const GLOBE_VOICE_PRESET_CAPABILITY = 'globe.voice.preset.manage' satisfies GlobeCapability;

export const GLOBE_VOICE_PRESET_COMMANDS = {
  register: 'globe.voice.preset.register',
} as const;

export const GLOBE_VOICE_PRESET_READERS = {
  list: 'globe.voice.preset.list',
  get: 'globe.voice.preset.get',
} as const;

/**
 * How a preset came to exist.
 *
 * `catalog` points at a curated voice the platform already offers. `cloned` is built from a
 * recording of a real person, which is why it is modelled separately rather than as a flag:
 * its rights posture is not optional, and the two will never share a lifecycle.
 */
export type VoicePresetKind = 'catalog' | 'cloned';
export type VoicePresetStatus = 'ready' | 'pending-external-confirmation';

/**
 * A registered voice, as every surface sees it.
 *
 * Append-only by design: a voice is never edited in place, because a preset id already used by
 * past runs is part of their evidence — silently repointing it would rewrite what those runs
 * were made with. A changed voice is a NEW preset.
 */
export type VoicePresetV1 = Readonly<{
  schemaVersion: '1';
  presetId: string;
  workspaceId: string;
  /** Client-facing name. Never a vendor voice id. */
  displayName: string;
  kind: VoicePresetKind;
  status: VoicePresetStatus;
  /**
   * Efeonce's curated voice key, for a `catalog` preset. Deliberately not the provider's id:
   * the vendor identifier is resolved from this inside the adapter and never leaves it.
   */
  catalogVoice?: string;
  /**
   * The rights posture of the recording a `cloned` preset was built from. Required for a clone
   * and absent otherwise — a cloned voice is a person's voice, so "we did not say" is not an
   * acceptable state for it to exist in.
   */
  sourceRights?: LabInputRights;
  createdAt: string;
}>;

/**
 * Registering a voice. A clone declares its source the same way every other input crosses this
 * API: as a content hash plus a rights posture, never as bytes.
 */
export type RegisterVoicePresetPayloadV1 = Readonly<{
  displayName: string;
  kind: VoicePresetKind;
  /** Required for `catalog`: which curated voice this preset points at. */
  catalogVoice?: string;
  /** Required for `cloned`: the source recording, by hash + declared rights. */
  source?: LabAuthorizedInputV1;
}>;

export type VoicePresetListDataV1 = Readonly<{
  schemaVersion: '1';
  presets: readonly VoicePresetV1[];
}>;

export type VoicePresetGetQueryV1 = Readonly<{ presetId: string }>;

export type VoicePresetGetDataV1 = Readonly<{
  schemaVersion: '1';
  preset: VoicePresetV1;
}>;
