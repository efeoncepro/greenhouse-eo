import type { CreativeCapability } from './index.js';
import type { GlobeCapability } from './capabilities.js';
import type { ProductionCompletionDriverV1 } from './production-routing-control.js';

export const GLOBE_PRODUCTION_PROMOTION_CAPABILITIES = {
  read: 'globe.production-promotion.read' as GlobeCapability,
  planStage: 'globe.production-promotion.plan-stage' as GlobeCapability,
  promote: 'globe.production-promotion.promote' as GlobeCapability,
  activate: 'globe.production-promotion.activate' as GlobeCapability,
  canaryAttest: 'globe.production-promotion.canary-attest' as GlobeCapability,
  rollback: 'globe.production-promotion.rollback' as GlobeCapability,
  recover: 'globe.production-promotion.recover' as GlobeCapability,
} as const;

export const GLOBE_PRODUCTION_PROMOTION_COMMANDS = {
  start: 'globe.production-promotion.operation.start',
  stage: 'globe.production-promotion.operation.stage',
  promote: 'globe.production-promotion.operation.promote',
  activate: 'globe.production-promotion.operation.activate',
  canaryConfirm: 'globe.production-promotion.operation.canary-confirm',
  fail: 'globe.production-promotion.operation.fail',
  rollback: 'globe.production-promotion.operation.rollback',
  recover: 'globe.production-promotion.operation.recover',
} as const;

export const GLOBE_PRODUCTION_PROMOTION_READERS = {
  get: 'globe.production-promotion.operation.get',
  list: 'globe.production-promotion.operation.list',
  history: 'globe.production-promotion.operation.history',
  stalled: 'globe.production-promotion.operation.stalled',
} as const;

export const PRODUCTION_PROMOTION_OPERATION_STATES = [
  'planned',
  'staging_controls',
  'controls_staged',
  'promoting_readiness',
  'readiness_promoted',
  'activating',
  'activated',
  'verifying_canary',
  'canary_passed',
  'rolling_back',
  'rolled_back',
  'failed',
  'rollback_failed',
] as const;

export type ProductionPromotionOperationStateV1 = (typeof PRODUCTION_PROMOTION_OPERATION_STATES)[number];

export type ProductionPromotionIdentityV1 = Readonly<{
  routeId: string;
  providerId: string;
  modelId: string;
  modelVersion: string;
  capability: CreativeCapability;
  fidelityContract: string;
  endpointId: string;
  region: string;
  completionDriver: ProductionCompletionDriverV1;
}>;

export type ProductionPromotionRightsEvidenceV1 = Readonly<{
  evidenceId: string;
  policyId: string;
  policyVersion: string;
  providerTermsRef: string;
  providerTermsDigest: string;
  appliesTo: 'generated' | 'derived' | 'both';
  effectiveRestrictions: readonly string[];
  validFrom: string;
  expiresAt: string;
}>;

export type ProductionPromotionReviewEvidenceV1 = Readonly<{
  reviewId: string;
  proposalId: string;
  makerId: string;
  reviewerId: string;
  readinessRevision: number;
  reviewAttestationDigest: string;
}>;

export type ProductionPromotionControlEvidenceV1 = Readonly<{
  rightsPolicyId: string;
  rightsPolicyVersion: string;
  rightsPolicyDigest: string;
  bindingRevision: number;
  bindingEnabled: boolean;
  circuitRevision: number;
  circuitState: 'open' | 'closed' | 'half-open';
}>;

export type ProductionPromotionReadinessEvidenceV1 = Readonly<{
  revision: number;
  reviewId: string;
  proposalId: string;
}>;

export type ProductionPromotionCanaryEvidenceV1 = Readonly<{
  runId: string;
  attemptId: string;
  outputSha256: string;
  governanceRevision: number;
  governanceState: 'eligible';
  activatedAt: string;
  completedAt: string;
  evidenceDigest: string;
}>;

export type ProductionPromotionRollbackEvidenceV1 = Readonly<{
  circuitRevision: number;
  circuitState: 'open';
  bindingRevision: number;
  bindingEnabled: false;
  completedAt: string;
}>;

export type ProductionPromotionEvidenceV1 = Readonly<{
  rights?: ProductionPromotionRightsEvidenceV1;
  review?: ProductionPromotionReviewEvidenceV1;
  controls?: ProductionPromotionControlEvidenceV1;
  readiness?: ProductionPromotionReadinessEvidenceV1;
  canary?: ProductionPromotionCanaryEvidenceV1;
  rollback?: ProductionPromotionRollbackEvidenceV1;
}>;

export type ProductionPromotionOperationV1 = Readonly<{
  schemaVersion: '1';
  workspaceId: string;
  operationId: string;
  identity: ProductionPromotionIdentityV1;
  state: ProductionPromotionOperationStateV1;
  revision: number;
  evidence: ProductionPromotionEvidenceV1;
  deadlineAt: string;
  nextAttemptAt?: string;
  lastSafeErrorCode?: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}>;

export type ProductionPromotionOperationRevisionV1 = Readonly<{
  schemaVersion: '1';
  workspaceId: string;
  operationId: string;
  revision: number;
  fromState?: ProductionPromotionOperationStateV1;
  toState: ProductionPromotionOperationStateV1;
  initiatedBy: string;
  executedBy: string;
  capability: GlobeCapability;
  correlationId: string;
  evidence: ProductionPromotionEvidenceV1;
  safeCode?: string;
  createdAt: string;
}>;

export type StartProductionPromotionPayloadV1 = Readonly<{
  identity: ProductionPromotionIdentityV1;
  deadlineAt: string;
}>;

export type StageProductionPromotionPayloadV1 = Readonly<{
  operationId: string;
  expectedRevision: number;
  rightsEvidenceId: string;
}>;

export type PromoteProductionPromotionPayloadV1 = Readonly<{
  operationId: string;
  expectedRevision: number;
  reviewId: string;
  proposalId: string;
}>;

export type AdvanceProductionPromotionPayloadV1 = Readonly<{
  operationId: string;
  expectedRevision: number;
}>;

export type ConfirmProductionPromotionCanaryPayloadV1 = AdvanceProductionPromotionPayloadV1 & Readonly<{
  runId: string;
}>;

export type FailProductionPromotionPayloadV1 = AdvanceProductionPromotionPayloadV1 & Readonly<{
  reasonCode: string;
}>;

export type RollbackProductionPromotionPayloadV1 = FailProductionPromotionPayloadV1;

export type RecoverProductionPromotionPayloadV1 = AdvanceProductionPromotionPayloadV1 & Readonly<{
  fencingToken: number;
}>;

export type ProductionPromotionOperationQueryV1 = Readonly<{ operationId: string }>;
export type ProductionPromotionOperationListQueryV1 = Readonly<{
  routeId?: string;
  modelVersion?: string;
  state?: ProductionPromotionOperationStateV1;
  limit?: number;
  cursor?: string;
}>;
export type ProductionPromotionOperationPageV1 = Readonly<{
  schemaVersion: '1';
  items: readonly ProductionPromotionOperationV1[];
  nextCursor?: string;
}>;
export type ProductionPromotionOperationHistoryV1 = Readonly<{
  schemaVersion: '1';
  revisions: readonly ProductionPromotionOperationRevisionV1[];
}>;
export type ProductionPromotionStalledQueryV1 = Readonly<{ limit?: number }>;
export type ProductionPromotionStalledPageV1 = Readonly<{
  schemaVersion: '1';
  items: readonly ProductionPromotionOperationV1[];
}>;
