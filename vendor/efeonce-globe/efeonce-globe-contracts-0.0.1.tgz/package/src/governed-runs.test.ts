import assert from 'node:assert/strict';
import { describe, it } from 'node:test';

import {
  GLOBE_GOVERNED_RUN_COMMANDS,
  GLOBE_GOVERNED_RUN_READERS,
  type GovernedRunViewV1,
} from './governed-runs.ts';

describe('governed run contracts', () => {
  it('publishes explicit control commands and status readers', () => {
    assert.deepEqual(GLOBE_GOVERNED_RUN_COMMANDS, {
      cancel: 'globe.run.cancel',
      retry: 'globe.run.retry',
      setPriority: 'globe.run.priority.set',
      reconcile: 'globe.run.reconcile',
    });
    assert.deepEqual(GLOBE_GOVERNED_RUN_READERS, {
      get: 'globe.run.get', list: 'globe.run.list', status: 'globe.run.status', retryEstimate: 'globe.run.retry.estimate',
    });
  });

  it('keeps the public projection coarse and free of provider wire evidence', () => {
    const view: GovernedRunViewV1 = {
      schemaVersion: '1', workspaceId: 'ws-a', runId: 'run-a', jobId: 'job-a',
      experimentId: 'experiment-a', state: 'cancellation_requested', coarseProgress: 'cancelling',
      priority: 50, revision: 3, currentAttempt: 1, correlationId: 'corr-a',
      cancellationRequestedAt: '2026-07-22T12:00:00.000Z', cancellationReason: 'operator_requested',
      attempts: [{ attemptId: 'attempt-a', attempt: 1, state: 'cancellation_requested',
        cancellationState: 'requested', providerAccepted: true,
        createdAt: '2026-07-22T11:59:00.000Z', updatedAt: '2026-07-22T12:00:00.000Z' }],
      createdAt: '2026-07-22T11:59:00.000Z', updatedAt: '2026-07-22T12:00:00.000Z',
    };
    const serialized = JSON.stringify(view);
    assert.doesNotMatch(serialized, /statusUrl|responseUrl|providerOperationId|vendorCost|rawError/);
  });
});
