/** Transport-neutral, client-safe contract for the asynchronous asset-governance kernel. */

export const ASSET_GOVERNANCE_STATES = [
  'pending',
  'inspecting',
  'malware_scan',
  'c2pa_verify',
  'rights_reconcile',
  'eligible',
  'rejected',
  'failed',
] as const;

export type AssetGovernanceStateV1 = (typeof ASSET_GOVERNANCE_STATES)[number];
export type AssetGovernanceStageV1 = Extract<
  AssetGovernanceStateV1,
  'inspecting' | 'malware_scan' | 'c2pa_verify' | 'rights_reconcile'
>;

export type AssetGovernanceEvidenceKindV1 = 'inspection' | 'malware' | 'c2pa' | 'rights';
export type AssetGovernanceEvidenceVerdictV1 =
  | 'accepted'
  | 'clean'
  | 'infected'
  | 'verified'
  | 'unverified'
  | 'unsupported'
  | 'authorized'
  | 'rejected'
  | 'retryable_failure'
  | 'permanent_failure';

/**
 * Sanitized evidence only. Raw scanner/provider responses, object coordinates, credentials and
 * signatures are intentionally absent. IDs are opaque references to evidence held server-side.
 */
export type AssetGovernanceEvidenceV1 = Readonly<{
  schemaVersion: '1';
  evidenceId: string;
  kind: AssetGovernanceEvidenceKindV1;
  verdict: AssetGovernanceEvidenceVerdictV1;
  engine: Readonly<{
    id: string;
    version: string;
    signatureSet?: string;
  }>;
  trustPolicy: Readonly<{ id: string; version: string }>;
  effectiveRestrictions: readonly string[];
  observedAt: string;
  safeCode?: string;
  /** Server-derived linkage for generated/derived rights decisions. Never caller supplied. */
  rightsAuthority?: Readonly<{
    policyId: string;
    policyVersion: string;
    routeSnapshotDigest: string;
    parentRightsDigest: string;
    providerTermsDigest: string;
  }>;
  /** Purpose-bound mask certification; populated only by the regional-mask engine. */
  regionalEditMask?: Readonly<{
    maskId: string;
    targetExperimentId: string;
    targetAttemptId: string;
    targetOutputSha256: string;
    normalizedSha256: string;
    width: number;
    height: number;
    nonEmpty: true;
  }>;
}>;

export type GeneratedRightsPolicyV1 = Readonly<{
  schemaVersion: '1';
  /** Derived from trusted server context; never accepted from command payloads. */
  workspaceId: string;
  policyId: string;
  policyVersion: string;
  routeId: string;
  providerId: string;
  modelId: string;
  modelVersion: string;
  /** Closed purpose boundary: evaluation authority never implies commercial production rights. */
  purpose: 'evaluation' | 'production';
  appliesTo: 'generated' | 'derived' | 'both';
  providerTermsRef: string;
  providerTermsDigest: string;
  effectiveRestrictions: readonly string[];
  validFrom: string;
  expiresAt: string;
  recordedBy: string;
  correlationId: string;
  recordedAt: string;
}>;

export const GLOBE_GENERATED_RIGHTS_POLICY_CAPABILITIES = {
  manage: 'globe.asset-rights-policy.manage', read: 'globe.asset-rights-policy.read',
} as const;
export const GLOBE_GENERATED_RIGHTS_POLICY_COMMANDS = { publish: 'globe.asset-rights-policy.publish' } as const;
export const GLOBE_GENERATED_RIGHTS_POLICY_READERS = {
  get: 'globe.asset-rights-policy.get', list: 'globe.asset-rights-policy.list',
} as const;
export type PublishGeneratedRightsPolicyPayloadV1 = Omit<
  GeneratedRightsPolicyV1,
  'schemaVersion' | 'workspaceId' | 'recordedBy' | 'correlationId' | 'recordedAt'
>;
export type GeneratedRightsPolicyQueryV1 = Readonly<{policyId:string;policyVersion:string}>;
export type GeneratedRightsPolicyListQueryV1 = Readonly<{routeId?:string;providerId?:string;limit?:number;cursor?:string}>;
export type GeneratedRightsPolicyPageV1 = Readonly<{schemaVersion:'1';items:readonly GeneratedRightsPolicyV1[];nextCursor?:string}>;

export type GeneratedParentRightsSnapshotV1 = Readonly<{
  assetId: string;
  sha256: string;
  rightsClass: string;
  consent: string;
  evidenceId: string;
  verifiedAt: string;
  snapshotDigest: string;
}>;

/** Immutable server-side authority captured from the exact executable run snapshot. */
export type GeneratedAssetRightsAuthorityV1 = Readonly<{
  schemaVersion: '1';
  workspaceId: string;
  assetId: string;
  sourceKind: 'generated' | 'derived';
  runId: string;
  attemptId: string;
  outputIndex: number;
  routeId: string;
  providerId: string;
  modelId: string;
  modelVersion: string;
  rightsPolicyPurpose: GeneratedRightsPolicyV1['purpose'];
  readinessRightsPolicyVersion: string;
  routeSnapshotDigest: string;
  parentRightsDigest: string;
  parents: readonly GeneratedParentRightsSnapshotV1[];
  recordedAt: string;
}>;

export type AssetGovernanceRetentionIntentV1 = Readonly<{
  schemaVersion: '1';
  intentId: string;
  workspaceId: string;
  jobId: string;
  assetId: string;
  kind: 'retain-until' | 'expire-after' | 'legal-hold-place' | 'legal-hold-release';
  effectiveAt: string;
  retainUntil?: string;
  policyRef: string;
  reasonCode: string;
  actorId: string;
  correlationId: string;
  recordedAt: string;
}>;

export type AssetGovernanceJobV1 = Readonly<{
  schemaVersion: '1';
  workspaceId: string;
  jobId: string;
  assetId: string;
  state: AssetGovernanceStateV1;
  correlationId: string;
  /** Monotonic rights authority revision captured when this job was created. */
  rightsRevision: number;
  /** Attempts consumed by the current stage; reset only after a durable successful transition. */
  attempts: number;
  maxAttempts: number;
  nextAttemptAt: string;
  lastSafeErrorCode?: string;
  legalHoldActive: boolean;
  createdAt: string;
  updatedAt: string;
  terminalAt?: string;
}>;

export type AssetGovernanceJobStatusV1 = Readonly<{
  schemaVersion: '1';
  job: AssetGovernanceJobV1;
  evidence: readonly AssetGovernanceEvidenceV1[];
  retentionIntents: readonly AssetGovernanceRetentionIntentV1[];
}>;
