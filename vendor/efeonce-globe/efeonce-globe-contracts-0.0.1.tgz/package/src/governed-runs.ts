/** Canonical Producer/Model-Lab durable run controls (TASK-1469/TASK-1505). */
export const GLOBE_GOVERNED_RUN_COMMANDS = {
  cancel: 'globe.run.cancel',
  retry: 'globe.run.retry',
  setPriority: 'globe.run.priority.set',
  reconcile: 'globe.run.reconcile',
} as const;

export const GLOBE_GOVERNED_RUN_READERS = {
  get: 'globe.run.get',
  list: 'globe.run.list',
  status: 'globe.run.status',
  retryEstimate: 'globe.run.retry.estimate',
} as const;

export type GovernedRunStateV1 =
  | 'approved'
  | 'submitting'
  | 'submission_unknown'
  | 'queued'
  | 'running'
  | 'completion_received'
  | 'reconciling'
  | 'cancellation_requested'
  | 'completed'
  | 'failed'
  | 'cancelled'
  | 'timed_out';

export type GovernedRunCancellationStateV1 = 'none' | 'requested' | 'confirmed' | 'unsupported';

export type GovernedRunAttemptSummaryV1 = Readonly<{
  attemptId: string;
  attempt: number;
  state: GovernedRunStateV1;
  cancellationState: GovernedRunCancellationStateV1;
  providerAccepted: boolean;
  createdAt: string;
  updatedAt: string;
}>;

/** Browser-safe projection. Provider identifiers, URLs, errors and vendor economics are omitted. */
export type GovernedRunViewV1 = Readonly<{
  schemaVersion: '1';
  workspaceId: string;
  runId: string;
  jobId: string;
  experimentId: string;
  state: GovernedRunStateV1;
  coarseProgress: 'waiting' | 'submitting' | 'provider-running' | 'finalizing' | 'cancelling' | 'terminal';
  priority: number;
  revision: number;
  currentAttempt: number;
  correlationId: string;
  cancellationRequestedAt?: string;
  cancellationReason?: string;
  attempts: readonly GovernedRunAttemptSummaryV1[];
  createdAt: string;
  updatedAt: string;
}>;

export type CancelGovernedRunPayloadV1 = Readonly<{
  runId: string;
  expectedRevision: number;
  reason: string;
}>;

/**
 * A retry never accepts budget, provider, route or reservation claims from the caller. The
 * server-side retry authorizer revalidates them and creates a fresh reservation before enqueue.
 */
export type RetryGovernedRunPayloadV1 = Readonly<{
  runId: string;
  expectedRevision: number;
  expectedAttempt: number;
  approvalToken: string;
}>;

export type SetGovernedRunPriorityPayloadV1 = Readonly<{
  runId: string;
  expectedRevision: number;
  expectedPriority: number;
  priority: number;
}>;

export type ReconcileGovernedRunPayloadV1 = Readonly<{
  runId: string;
  expectedRevision: number;
  reason: string;
}>;

export type GovernedRunQueryV1 = Readonly<{ runId: string }>;

export type GovernedRunRetryEstimateQueryV1 = Readonly<{
  runId: string;
  expectedRevision: number;
  expectedAttempt: number;
}>;

export type GovernedRunRetryEstimateV1 = Readonly<{
  schemaVersion: '1';
  sourceRunId: string;
  sourceRevision: number;
  sourceAttempt: number;
  credits: number;
  expiresAt: string;
  approvalToken: string;
}>;

export type GovernedRunListQueryV1 = Readonly<{
  limit?: number;
  states?: readonly GovernedRunStateV1[];
  cursor?: Readonly<{ updatedAt: string; runId: string }>;
}>;

export type GovernedRunPageV1 = Readonly<{
  schemaVersion: '1';
  items: readonly GovernedRunViewV1[];
  nextCursor?: Readonly<{ updatedAt: string; runId: string }>;
}>;
