import assert from 'node:assert/strict';
import { it } from 'node:test';

import { GLOBE_MODEL_READINESS_COMMANDS, type ModelReadinessRevisionV1 } from './model-readiness.ts';

it('keeps signed evidence separate from provider availability and exact by model version', () => {
  const revision: ModelReadinessRevisionV1 = {
    schemaVersion: '1', workspaceId: 'ws-a', revision: 2, state: 'promoted',
    route: { routeId: 'image-pro', capability: 'image-generate', fidelityContract: 'flexible-style', providerId: 'vertex', modelId: 'imagen-4', modelVersion: '2026-07' },
    evidence: {
      evaluationReportId: 'report-a', reviewId: 'review-a', attemptId: 'attempt-a',
      evaluationReportDigest: 'a'.repeat(64), provenanceDigest: 'b'.repeat(64),
      rightsPolicyVersion: 'rights-v1', rightsEvidenceDigest: 'c'.repeat(64),
      reviewAttestationDigest: 'd'.repeat(64),
    },
    reasonCode: 'internal_pilot', changedBy: { principalId: 'promoter-a', principalType: 'human' }, correlationId: 'corr-a', createdAt: '2026-07-22T00:00:00.000Z',
  };
  assert.equal(revision.route.modelVersion, '2026-07');
  assert.notEqual(GLOBE_MODEL_READINESS_COMMANDS.review, GLOBE_MODEL_READINESS_COMMANDS.promote);
});
