import type { LabExperimentV1, PrepareExperimentPayloadV1 } from './index.js';

export const GLOBE_GENERATION_RECIPE_COMMANDS = {
  relaunch: 'globe.lab.experiment.relaunch',
  variate: 'globe.lab.experiment.variate',
} as const;

export type LabGenerationRecipeV1 = Readonly<{
  seed?: number;
  guidanceScale?: number;
  inferenceSteps?: number;
  sampler?: string;
}>;

export type LabGenerationRecipeKnobV1 = keyof LabGenerationRecipeV1;

/** Immutable evidence returned by the provider seam, not caller assertion. */
export type LabEffectiveGenerationRecipeV1 = Readonly<{
  recipe: LabGenerationRecipeV1;
  unsupportedKnobs: readonly LabGenerationRecipeKnobV1[];
}>;

export type LabReproductionFidelityV1 = 'exact' | 'best-effort';

export type RelaunchExperimentPayloadV1 = Readonly<{
  experimentId: string;
  hardCapCredits: number;
}>;

export type RelaunchExperimentOutcomeV1 = Readonly<{
  schemaVersion: '1';
  sourceExperimentId: string;
  experiment: LabExperimentV1;
  fidelity: LabReproductionFidelityV1;
  effectiveRecipe?: LabGenerationRecipeV1;
  unsupportedKnobs: readonly LabGenerationRecipeKnobV1[];
}>;

export type LabVariationStrategyV1 =
  | Readonly<{ kind: 'seed-sweep'; seedStep: number }>
  | Readonly<{ kind: 'guidance-jitter'; delta: number }>;

export type VariateExperimentPayloadV1 = Readonly<{
  experimentId: string;
  count: number;
  strategy: LabVariationStrategyV1;
  hardCapCreditsPerVariant: number;
  aggregateHardCapCredits: number;
}>;

export type LabVariationItemV1 = Readonly<{
  index: number;
  experimentId?: string;
  state: 'candidate-ready' | 'failed' | 'not-started';
  recipe: LabGenerationRecipeV1;
  failureCode?: 'aggregate-cap-exceeded' | 'run-failed' | 'dependency-unavailable';
  retryable: boolean;
}>;

export type VariateExperimentOutcomeV1 = Readonly<{
  schemaVersion: '1';
  sourceExperimentId: string;
  requested: number;
  completed: number;
  failed: number;
  aggregateHardCapCredits: number;
  items: readonly LabVariationItemV1[];
}>;

/** Server-derived child request. Never accepted directly from a caller. */
export type DerivedGenerationChildV1 = Readonly<{
  request: PrepareExperimentPayloadV1 & Readonly<{ recipe?: LabGenerationRecipeV1 }>;
  sourceExperimentId: string;
  sourceLineage: readonly string[];
  reproductionKind: 'relaunch' | 'variation';
  reproductionFidelity: LabReproductionFidelityV1;
}>;
