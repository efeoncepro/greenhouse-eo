import assert from 'node:assert/strict';
import { describe, it } from 'node:test';

import { GLOBE_CAPABILITIES } from './capabilities.ts';
import {
  GLOBE_PRODUCER_LIVE_FEED_CAPABILITY,
  GLOBE_PRODUCER_LIVE_FEED_READERS,
  type UnifiedProducerFeedItemV1,
} from './producer-live-feed.ts';

describe('producer live feed contract', () => {
  it('reuses the governed library read grant instead of inventing a browser authority', () => {
    assert.ok(GLOBE_CAPABILITIES.includes(GLOBE_PRODUCER_LIVE_FEED_CAPABILITY));
    assert.equal(GLOBE_PRODUCER_LIVE_FEED_CAPABILITY, 'globe.producer.library.read');
  });

  it('declares dedicated list and changes readers', () => {
    assert.equal(GLOBE_PRODUCER_LIVE_FEED_READERS.list, 'globe.producer.feed.live.list');
    assert.equal(GLOBE_PRODUCER_LIVE_FEED_READERS.changes, 'globe.producer.feed.live.changes');
    assert.notEqual(GLOBE_PRODUCER_LIVE_FEED_READERS.list, GLOBE_PRODUCER_LIVE_FEED_READERS.changes);
  });

  it('keeps retained assets as a discriminated feed item', () => {
    const item: UnifiedProducerFeedItemV1 = {
      schemaVersion: '1',
      kind: 'retained-asset',
      stableKey: 'asset:run-a:sha256:a',
      workspaceId: 'ws-a',
      runId: 'run-a',
      experimentId: 'exp-a',
      revision: 1,
      createdAt: '2026-07-23T00:00:00.000Z',
      updatedAt: '2026-07-23T00:00:01.000Z',
      displayTitle: 'Seedream · 5 Pro',
      capability: 'image-generate',
      modality: 'image',
      route: { routeId: 'ref/still/rrss-v1', model: { name: 'Seedream', version: '5 Pro' } },
      spentCredits: 10,
      state: 'retained',
      coarseProgress: 'terminal',
      runState: 'completed',
      runRevision: 2,
      output: {
        item: { experimentId: 'exp-a', sha256: 'sha256:a' },
        sha256: 'sha256:a',
        mediaType: 'image',
        favorite: false,
        containerIds: [],
      },
    };
    assert.equal(item.kind, 'retained-asset');
    assert.equal(item.output.item.experimentId, item.experimentId);
  });
});
